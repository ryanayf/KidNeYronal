function varargout = plot4d(varargin)
    % created on 2016-03-02 by Stephan Düwel

    % Last Modified by GUIDE v2.5 17-Feb-2021 17:03:28

    % Begin initialization code - DO NOT EDIT
    gui_Singleton = 1;
    gui_State = struct('gui_Name',       mfilename, ...
                       'gui_Singleton',  gui_Singleton, ...
                       'gui_OpeningFcn', @plot4d_OpeningFcn, ...
                       'gui_OutputFcn',  @plot4d_OutputFcn, ...
                       'gui_LayoutFcn',  [], ...
                       'gui_Callback',   []);
    if nargin && ischar(varargin{1})
      gui_State.gui_Callback = str2func(varargin{1});
    end

    if nargout
      [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
      gui_mainfcn(gui_State, varargin{:});
    end
    % End initialization code - DO NOT EDIT


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Executes just before plot4d is made visible.                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
function plot4d_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<*INUSL>
    handles.p = RefValue();

    % set default shift of carbon image in x- and y-directions and intensity
    handles.p.addprop('carbon_shift_x');
    handles.p.addprop('carbon_shift_y');
    handles.p.addprop('intensity_offset');
    handles.p.addprop('spectrum_phase0');
    handles.p.addprop('spectrum_phase1');
    handles.p.carbon_shift_x = 0.0;
    handles.p.carbon_shift_y = 0.0;
    handles.p.intensity_offset = 0.0;
    handles.p.spectrum_phase0 = 0.0;
    handles.p.spectrum_phase1 = 0.0;
    handles.p.addprop('xshift');
    handles.p.xshift = 0;
    handles.p.addprop('yshift');
    handles.p.yshift = 0;

    handles.p.addprop('do_spatial_fft');
    handles.p.addprop('do_freq_fft');
    handles.p.do_spatial_fft = 1;
    handles.p.do_freq_fft = 1;
    
    handles.p.addprop('autophase');
    handles.p.autophase = 0;
    handles.p.addprop('fix_click_phase');
    handles.p.fix_click_phase = 0;

    % set default waveform file for GE reconstruction
    handles.p.addprop('trajectoryfile');
    handles.p.trajectoryfile = 'epsi_res12_recon';

    % set default frequency information to show in carbon slice
    handles.p.addprop('freq_val');
    handles.p.addprop('freq_length');
    handles.p.freq_val = 100;
    handles.p.freq_length = 1;

    handles.p.addprop('freq_min');
    handles.p.addprop('freq_max');
    handles.p.freq_min = -1200;
    handles.p.freq_max = 1200;

    % set default T1 for metabolite
    handles.p.addprop('t1_metabolite');
    handles.p.t1_metabolite = 14;

    % set default carbon reconstruction resolution
    handles.p.addprop('carbon_recon_point_low');    % start of window for data to include in recon
    handles.p.addprop('carbon_recon_point_high');   % end of window
    handles.p.carbon_recon_point_low = 1;
    handles.p.carbon_recon_point_high = 1;

    % default line broadening
    handles.p.addprop('carbon_line_broadening');
    handles.p.carbon_line_broadening = 15; % default from fid2spec

    % reconstruction zoom
    handles.p.addprop('carbon_recon_zoom');
    handles.p.carbon_recon_zoom = 1;
    
    % define factor to downscale pyruvate when plotting (to allow much higher
    % f1 and much lower f2-f4 plots on the same axis)
    handles.p.addprop('downscale_f1');
    handles.p.downscale_f1 = 1;

    % set background color
    set(hObject,'Color',[.94 .94 .94]);

    % define colors that are used repetitively
    handles.p.addprop('color_lightgrey');
    handles.p.addprop('color_lightgreen');
    handles.p.color_lightgrey  = [0.94 0.94 0.94];
    handles.p.color_lightgreen = [0.60 1.00 0.60];

    % set default Hz axes
    handles.p.addprop('hz');
    handles.p.hz = [-75.5 0 75.5];
    handles.p.addprop('reference_freq');    % central frequency of functional data image in MHz
    handles.p.reference_freq = 75.5;        % default for carbon, MHz
    handles.p.addprop('working_freq_ppm');  % offset ppm for 0 Hz centre frequency
    handles.p.working_freq_ppm = 0.0;
    handles.p.addprop('ppm');
    handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;



    % set default metabolite information
    handles.p.addprop('f1_val');
    handles.p.addprop('f2_val');
    handles.p.addprop('f3_val');
    handles.p.addprop('f4_val');
    handles.p.addprop('option_show_f1');
    handles.p.addprop('option_show_f2');
    handles.p.addprop('option_show_f3');
    handles.p.addprop('option_show_f4');
    handles.p.f1_val = -291;   	% pyruvate          
    handles.p.f2_val = 139;     % alanine           
    handles.p.f3_val = 367;     % pyruvate hydrate  
    handles.p.f4_val = 646;     % lactate 
    handles.p.option_show_f1 = 1;
    handles.p.option_show_f2 = 1;
    handles.p.option_show_f3 = 1;
    handles.p.option_show_f4 = 1;

    handles.p.addprop('auto_fit_threshold');
    handles.p.addprop('auto_fit_separation');
    handles.p.auto_fit_threshold = -1;
    handles.p.auto_fit_separation = 120;

    handles.p.addprop('freq_plot_min');
    handles.p.addprop('freq_plot_max');
    handles.p.freq_plot_min = -1200;
    handles.p.freq_plot_max =  1200;

    % define output
    handles.p.addprop('output');
    handles.output = hObject;

    % create id for figure where to plot the images and spectra
    handles.p.addprop('figid_display');
    handles.p.figid_display = figure('Name','CSI Display Window','NumberTitle','off');

    % set options for checkboxes
    handles.p.addprop('window_auto');
    handles.p.addprop('flipangle_correction_desired');
    handles.p.addprop('lorentz_fit_desired');
    handles.p.addprop('lorentz_fit_params');
    handles.p.addprop('t1_fit_desired');
    handles.p.addprop('carbon_load_figures_extra');
    handles.p.addprop('carbon_recon_figures_extra');
    handles.p.window_auto = 1;
    handles.p.flipangle_correction_desired = 0;
    handles.p.lorentz_fit_desired = 0;
    handles.p.lorentz_fit_params = [0 1 1 1];
    handles.p.t1_fit_desired = 0;
    handles.p.carbon_load_figures_extra = 0;
    handles.p.carbon_recon_figures_extra = 0;

    % proton data
    handles.p.addprop('proton_file');
    handles.p.addprop('proton_fov');
    handles.p.proton_file = '';
    handles.p.proton_fov = [32 32]; % mm

    % carbon data
    handles.p.addprop('carbon_file');
    handles.p.addprop('carbon_resolution');         % matrix size of carbon raw data
    handles.p.addprop('carbon_recon_resolution');   % matrix size of carbon reconstruction
    handles.p.addprop('carbon_fov');                % carbon field of view
    handles.p.carbon_file = '';
    handles.p.carbon_resolution = [20 20] ;
    handles.p.carbon_recon_resolution = [20 20];
    handles.p.carbon_fov = [32 32];                 % acquired size of FOV

    handles.p.addprop('carbon_header');
    handles.p.carbon_header = [];

    handles.p.addprop('timeaxis');
    handles.p.timeaxis = 0;
    handles.p.addprop('nExcitationsPerTimestep');
    handles.p.nExcitationsPerTimestep = 1;

    % set maximum signal information
    handles.p.addprop('window_val');
    handles.p.addprop('window_length');
    handles.p.window_val = 0;
    handles.p.window_length = 1;

    % set timestep information
    handles.p.addprop('timestep_val');
    handles.p.addprop('timestep_length');
    handles.p.timestep_val = 1;
    handles.p.timestep_length = 1;

    % set carbon slice information
    handles.p.addprop('slice_carbon_val');
    handles.p.slice_carbon_val = 1;

    % set carbon coil information
    handles.p.addprop('coil_carbon_val');
    handles.p.addprop('option_carbon_rms');
    handles.p.coil_carbon_val = 1;
    handles.p.option_carbon_rms = 0;

    % set proton slice information
    handles.p.addprop('slice_proton_val');
    handles.p.slice_proton_val = 1;

    % define to display single voxel data when opening the figure
    handles.p.addprop('specandtime_roi');
    handles.p.addprop('roi_mask');
    handles.p.addprop('roi_xi');
    handles.p.addprop('roi_yi');
    handles.p.specandtime_roi   = 0;
    handles.p.roi_mask          = [];
    handles.p.roi_xi            = [];
    handles.p.roi_yi            = [];
    handles.p.addprop('roi_mask_cut');
    handles.p.addprop('roi_xi_cut');
    handles.p.addprop('roi_yi_cut');
    handles.p.roi_mask_cut = [];
    handles.p.addprop('roi_mask_1H');
    handles.p.roi_mask_1H          = [];
    
    
    % the "draw ROI" button is not pressed when the figure is opened at first
    handles.p.addprop('roi_draw');
    handles.p.roi_draw           = 0;
    handles.p.addprop('roi_draw_cut');
    handles.p.roi_draw_cut       = 0;
 

    % summing up the time and frequency, and plotting phase images, is disabled at startup
    handles.p.addprop('option_freq_sum');
    handles.p.addprop('option_timestep_sum');
    handles.p.addprop('option_plot_surface');
    handles.p.option_freq_sum       = 0;
    handles.p.option_timestep_sum   = 0;
    handles.p.option_plot_surface   = 0;

    handles.p.addprop('option_cumsum');
    handles.p.option_cumsum = 0;
    
    handles.p.addprop('option_plot_intensity');
    handles.p.addprop('option_plot_complex');
    handles.p.addprop('option_plot_real');
    handles.p.addprop('option_plot_phase');
    handles.p.addprop('option_plot_lac_pyr');
    handles.p.addprop('option_plot_ala_pyr');
    handles.p.addprop('option_plot_diff_norm');
    handles.p.addprop('option_plot_lac_allfreqs');
    handles.p.addprop('option_plot_ala_allfreqs');

    handles.p.addprop('option_plot_freq1_offset');
    handles.p.addprop('option_plot_freq4_offset');

    handles.p.option_plot_intensity    = 1;
    handles.p.option_plot_complex      = 0;
    handles.p.option_plot_real         = 0;
    handles.p.option_plot_phase        = 0;
    handles.p.option_plot_lac_pyr      = 0;
    handles.p.option_plot_ala_pyr      = 0;
    handles.p.option_plot_diff_norm    = 0;
    handles.p.option_plot_lac_allfreqs = 0;
    handles.p.option_plot_ala_allfreqs = 0;

    handles.p.option_plot_freq1_offset = 0;
    handles.p.option_plot_freq4_offset = 0;

    handles.p.addprop('option_offset_correction');
    handles.p.option_offset_correction = 0;
    handles.p.addprop('option_freq_as_ppm');
    handles.p.option_freq_as_ppm = 1;

    handles.p.addprop('option_overlay_alpha');
    handles.p.option_overlay_alpha = 0.5;
    handles.p.addprop('option_alpha_threshold');
    handles.p.option_alpha_threshold = 1;
    handles.p.addprop('option_total_signal_threshold');
    handles.p.option_total_signal_threshold = -Inf;


    handles.p.addprop('option_colourmap');
    handles.p.option_colourmap = 'default';
    
    handles.p.addprop('plot_spectral_data');
    handles.p.plot_spectral_data = 0;
    
    handles.p.addprop('za_b');
    handles.p.za_b = [12.5704 8.5162 2.5706 5.1304 6.9033];
   
    handles.p.addprop('pHmap65');
    handles.p.pHmap65 = zeros([6 6]);
    handles.p.addprop('pHmap70');
    handles.p.pHmap70 = zeros([6 6]);
    handles.p.addprop('pHmap74');
    handles.p.pHmap74 = zeros([6 6]);
    handles.p.addprop('pHmapMean');
    handles.p.pHmapMean = zeros([6 6]);
    handles.p.addprop('pHmap');
    handles.p.pHmap = zeros([6 6]);
    handles.p.addprop('pHmapMain');
    handles.p.pHmapMain = zeros([6 6]);
    handles.p.addprop('pHspectrum65');
    handles.p.pHspectrum65 = 0;
    handles.p.addprop('pHspectrum70');
    handles.p.pHspectrum70 = 0;
    handles.p.addprop('pHspectrum74');
    handles.p.pHspectrum74 = 0;
    handles.p.addprop('pHspectrumDiff');
    handles.p.pHspectrumDiff = 0;
    handles.p.addprop('pHspectrumMean');
    handles.p.pHspectrumMean = 0;
    
    handles.p.addprop('pHDiffZA15_spectrum65');
    handles.p.pHDiffZA15_spectrum65 = 0;
    handles.p.addprop('pHDiffZA15_65');
    handles.p.pHDiffZA15_65 = zeros([6 6]);
    handles.p.addprop('pHDiffZA15_spectrum70');
    handles.p.pHDiffZA15_spectrum70 = 0;
    handles.p.addprop('pHDiffZA15_70');
    handles.p.pHDiffZA15_70 = zeros([6 6]);
    handles.p.addprop('pHDiffZA15_spectrum74');
    handles.p.pHDiffZA15_spectrum74 = 0;
    handles.p.addprop('pHDiffZA15_74');
    handles.p.pHDiffZA15_74 = zeros([6 6]);
  
    
    handles.p.addprop('spec_fillfactor');
    handles.p.spec_fillfactor = 1;
    handles.p.addprop('pH_fit_threshold');
    handles.p.pH_fit_threshold = 4;
    handles.p.addprop('pH_fit_prominence');
    handles.p.pH_fit_prominence = 1;
    handles.p.addprop('option_plot_pH_map');
    handles.p.option_plot_pH_map = 0;
    handles.p.addprop('option_plot_pH_map_mean');
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.addprop('option_plot_pH_map_main');
    handles.p.option_plot_pH_map_main = 0;
    handles.p.addprop('option_plot_pH_map_compartment');
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.addprop('option_show_pHmap65');
    handles.p.option_show_pHmap65 = 0;
    handles.p.addprop('option_show_pHmap70');
    handles.p.option_show_pHmap70 = 0;
    handles.p.addprop('option_show_pHmap74');
    handles.p.option_show_pHmap74 = 0;
    handles.p.addprop('option_overlay_alpha_74');
    handles.p.option_overlay_alpha_74 = 0.5;
    handles.p.addprop('option_overlay_alpha_70');
    handles.p.option_overlay_alpha_70 = 0.5;
    handles.p.addprop('option_overlay_alpha_65');
    handles.p.option_overlay_alpha_65 = 0.5;
    handles.p.addprop('invert_colormap');
    handles.p.invert_colormap = 0;
    handles.p.addprop('cut_pH_map');
    handles.p.cut_pH_map = 0;
    handles.p.addprop('proton_cut_threshold');
    handles.p.proton_cut_threshold = 0.05;
    handles.p.addprop('cut_roi_loaded');
    handles.p.cut_roi_loaded = 0;
    handles.p.addprop('pHmeanWeighted');
    handles.p.pHmeanWeighted = 1;
    handles.p.addprop('pHmeanWeighted_signal');
    handles.p.pHmeanWeighted_signal = 0;
    
    handles.p.addprop('peak_fnd');
    handles.p.peak_fnd      = 0;        
    handles.p.addprop('peak_fit_amp');
    handles.p.peak_fit_amp  = 0;        
    handles.p.addprop('peak_fit_fwhm');
    handles.p.peak_fit_fwhm = 0;       
    handles.p.addprop('peak_fit_pos');
    handles.p.peak_fit_pos  = 0;        
    handles.p.addprop('peak_fit_yoff');
    handles.p.peak_fit_yoff = 0; 
    handles.p.addprop('peak_fit_spectrum');
    handles.p.peak_fit_spectrum = 0;
    handles.p.addprop('peak_pos');
    handles.p.peak_pos = 0;
    handles.p.addprop('peak_val');
    handles.p.peak_val = 0;
    handles.p.addprop('peak_wid');
    handles.p.peak_wid = 0;
    handles.p.addprop('peak_prm');
    handles.p.peak_prm = 0;
    handles.p.addprop('spec_peak_pos');
    handles.p.spec_peak_pos = 0;
    handles.p.addprop('spec_peak_val');
    handles.p.spec_peak_val = 0;
    handles.p.addprop('spec_peak_wid');
    handles.p.spec_peak_wid = 0;
    handles.p.addprop('spec_peak_prm');
    handles.p.spec_peak_prm = 0;
    handles.p.addprop('spec_peak_fnd');
    handles.p.spec_peak_fnd = 0;
    handles.p.addprop('spec_peak_fit_amp');
    handles.p.spec_peak_fit_amp  = 0;
    handles.p.addprop('spec_peak_fit_fwhm');
    handles.p.spec_peak_fit_fwhm = 0;
    handles.p.addprop('spec_peak_fit_pos');
    handles.p.spec_peak_fit_pos  = 0;
    handles.p.addprop('spec_peak_fit_yoff');
    handles.p.spec_peak_fit_yoff = 0;
    handles.p.addprop('spec_peak_fit_spectrum');
    handles.p.spec_peak_fit_spectrum = 0;
    handles.p.addprop('noise');
    handles.p.noise = zeros([6 6]);
    
    
    handles.p.addprop('pH_window_auto');
    handles.p.pH_window_auto = 1;
    handles.p.addprop('pH_window_length');
    handles.p.pH_window_length = 3;
    handles.p.addprop('pH_window_val');
    handles.p.pH_window_val = 5;
    handles.p.addprop('fit_current_spectrum');
    handles.p.fit_current_spectrum = 0;
    
    handles.p.addprop('fig_ppt');
    handles.p.fig_ppt = 0;
    handles.p.addprop('pHmap_roi_draw');
    handles.p.pHmap_roi_draw = 0;
    handles.p.addprop('Vox_Sz');
    handles.p.Vox_Sz = 2;
    

    % update variable handles and display spectra
    guidata(hObject, handles);
    plot4d_plot(handles);

function varargout = plot4d_OutputFcn(hObject, eventdata, handles)
    varargout{1} = handles.output;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% slider functions                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function slider_timestep_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    timestep_start = hObject.Value;

    % record initial start and length of timestep
    timestep_length = handles.p.timestep_length;

    % require positive timestep
    if (timestep_length < 1)
        timestep_length = 1;
    end

    % limit timestep length to available size of data
    max_timestep_length = size(handles.d.carbon_recon.image, 6);
    if (timestep_length > max_timestep_length)
        timestep_length = max_timestep_length;
    end

    % limit start time based on available space and timestep length
    max_start = max_timestep_length - timestep_length + 1;
    if (max_start < 1)
        max_start = 1;
    end
    if (timestep_start > max_start)
        timestep_start = max_start;
    end

    if (timestep_start < 1)
        timestep_start = 1;
    end

    handles.p.timestep_val = timestep_start;
    handles.p.timestep_length = timestep_length;

    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_window_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    val = hObject.Value;
    if (val > hObject.Max)
        val = hObject.Max;
    end
    handles.p.window_length = val;
    handles.p.window_auto = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_slice_carbon_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    val = hObject.Value;
    if (val < hObject.Min)
        val = hObject.Min;
    elseif (val > hObject.Max)
        val = hObject.Max;
    end
    handles.p.slice_carbon_val = val;
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_coil_carbon_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    val = hObject.Value;
    if (val < hObject.Min)
        val = hObject.Min;
    elseif (val > hObject.Max)
        val = hObject.Max;
    end
    handles.p.coil_carbon_val = val;
    handles.p.option_carbon_rms = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_slice_proton_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    val = hObject.Value;
    if (val < hObject.Min)
        val = hObject.Min;
    elseif (val > hObject.Max)
        val = hObject.Max;
    end
    handles.p.slice_proton_val = val;
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_freq_Callback(hObject, eventdata, handles)
    val = round(hObject.Value);

    if val > length(handles.p.hz)
        val = length(handles.p.hz);
    end
    if val < 1
        val = 1;
    end

    handles.p.freq_val = handles.p.hz(val) - handles.p.freq_length / 2;

    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_f1_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    handles.p.f1_val = handles.p.hz(hObject.Value);
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_f2_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    handles.p.f2_val = handles.p.hz(hObject.Value);
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_f3_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    handles.p.f3_val = handles.p.hz(hObject.Value);
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_f4_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value);
    handles.p.f4_val = handles.p.hz(hObject.Value);
    guidata(hObject,handles);
    plot4d_plot(handles);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pushbutton functions                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pushbutton_proton_select_Callback(hObject, eventdata, handles)
    if isprop(handles.p,'proton_file')  
        [defaultname, ~, ~] = fileparts(handles.p.proton_file);
    else
        defaultname = '';
    end

    if (isempty(defaultname))
        % if a carbon file is already selected, default to that directory
        if (isprop(handles.p, 'carbon_file'))
            [defaultname, ~, ~] = fileparts(handles.p.carbon_file) ;
        end
    end

    % define which filetypes can be selected as raw files
    filterspec = {'*.7;*.dcm;*.IMA;*.dat;2dseq', 'GE P-File, Siemens DAT File, Siemens IMA File, Bruker Raw File, or DICOM'};
    file_prompt = 'Please select the proton raw data file';

    [filename,pathname] = uigetfile(filterspec, file_prompt, defaultname);
    if isequal(filename,0)
        disp('No filename selected or filename could not be located.')
        handles.pushbutton_proton_select.BackgroundColor = handles.p.color_lightgrey;
    else 
        file = [pathname,filename];
        handles.p.proton_file = file;
        handles.edit_proton_file.String = file;
        handles.pushbutton_proton_select.BackgroundColor = handles.p.color_lightgreen;
    end
    guidata(hObject,handles);


function pushbutton_proton_load_and_recon_Callback(hObject, eventdata, handles)
    if exist(handles.p.proton_file, 'file')
        proton_load(hObject,handles)
        handles.pushbutton_proton_load_and_recon.BackgroundColor = handles.p.color_lightgreen;
    else
        disp(['Proton file could not be found: ', handles.p.proton_file])
        handles.pushbutton_proton_load_and_recon.BackgroundColor = handles.p.color_lightgrey;
    end


function pushbutton_carbon_select_Callback(hObject, eventdata, handles)
    if isprop(handles.p,'carbon_file')  
        [defaultname, ~, ~] = fileparts(handles.p.carbon_file);
    else
        defaultname = '';
    end

    if (isempty(defaultname))
        % if a proton file is already selected, default to that directory
        if (isprop(handles.p, 'proton_file'))
            [defaultname, ~, ~] = fileparts(handles.p.proton_file) ;
        end
    end

    % define which filetypes can be selected as raw files
    filterspec = {'*.7;*.dat;2dseq;fid;ser;*.job*;*.bf', 'GE P-File, Siemens DAT File, Siemens Binary File(bf), Bruker FID or SER file, or Bruker Job file'};
    file_prompt = 'Please select the CSI raw or semi-processed data file';

    [filename,pathname] = uigetfile(filterspec, file_prompt, defaultname);
    if isequal(filename,0)
        disp('No filename selected or filename could not be located.')
        handles.pushbutton_carbon_select.BackgroundColor = handles.p.color_lightgrey;
    else
        file = [pathname,filename];
        handles.p.carbon_file = file;
        handles.edit_carbon_file.String = file;
        handles.pushbutton_carbon_select.BackgroundColor = handles.p.color_lightgreen;
        handles.pushbutton_carbon_load.BackgroundColor = handles.p.color_lightgrey;
        handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;
    end
    guidata(hObject,handles);


function pushbutton_carbon_load_Callback(hObject, eventdata, handles)
    ext = '';
    if exist(handles.p.carbon_file,'file')
        [~,base,ext] = fileparts(handles.p.carbon_file);
    end

    % check for known data formats before passing to main carbon load function
    if ((exist(handles.p.carbon_file,'file') && strcmp(ext,'.7') == 1) || ...
        (exist(handles.p.carbon_file,'file') && strcmp(ext,'.dat') == 1) || ...
        (exist(handles.p.carbon_file,'file') && strcmp(ext,'.bf') == 1) || ...
        (exist(handles.p.carbon_file,'file') && strcmp(ext,'') == 1 && strcmp(base,'2dseq') == 1) || ...
        (exist(handles.p.carbon_file,'file') && strcmp(ext,'') == 1 && (strcmp(base,'fid') == 1) || strcmp(base,'ser') == 1) || ...
        (exist(handles.p.carbon_file,'file') && length(ext) == 5 && strcmp(ext(1:4),'.job') == 1))

        handles.pushbutton_carbon_select.BackgroundColor = handles.p.color_lightgreen;
        handles.pushbutton_carbon_load.BackgroundColor = handles.p.color_lightgrey;
        handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;
        drawnow
        carbon_load(hObject,handles);
        handles.pushbutton_carbon_load.BackgroundColor = handles.p.color_lightgreen;

    else
        disp(['Carbon file could not be found: ', handles.p.carbon_file])
        handles.pushbutton_carbon_load.BackgroundColor = handles.p.color_lightgrey;
    end


function pushbutton_carbon_recon_Callback(hObject, eventdata, handles)
    if isfield(handles.d,'carbon_recon') %&& isfield(handles.d,'proton_image')
        handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;
        drawnow
        carbon_recon(hObject, handles)
        handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgreen;
    else
        disp('Please first load carbon data.')
        handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;
    end


function pushbutton_roi_draw_Callback(hObject, eventdata, handles)
    handles.p.roi_draw = 1;
    guidata(hObject,handles);
    plot4d_plot(handles);


function pushbutton_roi_save_Callback(hObject, eventdata, handles)
    if isempty(handles.p.roi_xi)
        disp('no ROIs to save')
    end

    defaultname = '';
    if ~isempty(handles.p.proton_file)
        [defaultname, ~, ~] = fileparts(handles.p.proton_file);
    elseif ~isempty(handles.p.carbon_file)
        [defaultname, ~, ~] = fileparts(handles.p.carbon_file);
    end
    
    if ~isempty(defaultname)
        % move up to folder containing multiple scans from the locatino of
        % 2dseq file
        defaultname = fullfile(defaultname, '../../../c13tool_rois.mat');
    end
    
    % define which filetypes can be selected as raw files
    filterspec = {'.mat', 'MatLab Matrix File'};
    file_prompt = 'Please select the ROI Save File';    
    
    [filename, pathname] = uiputfile(filterspec, file_prompt, defaultname);
    if isempty(filename)
        disp('no save file selected...')
        return
    end
    
    mask = handles.p.roi_mask;  %#ok<NASGU>
    xi = handles.p.roi_xi;      %#ok<NASGU>
    yi = handles.p.roi_yi;      %#ok<NASGU>
    
    save([pathname filename], 'mask', 'xi', 'yi');
    
    disp(['ROIs saved to: ' pathname filename])


function pushbutton_roi_load_Callback(hObject, eventdata, handles)
    defaultname = '';
    if ~isempty(handles.p.proton_file)
        [defaultname, ~, ~] = fileparts(handles.p.proton_file);
    elseif ~isempty(handles.p.carbon_file)
        [defaultname, ~, ~] = fileparts(handles.p.carbon_file);
    end
    
    if ~isempty(defaultname)
        % move up to folder containing multiple scans from the location of
        % 2dseq file
        % todo: check if it's an fid or a 2dseq and appropriately move up
        % just one or a full three directories
        defaultname = fullfile(defaultname, '../../../*.mat');
    end
    
    % define which filetypes can be selected as raw files
    filterspec = {'.mat', 'MatLab Matrix File'};
    file_prompt = 'Please select the ROI File';    
    
    [filename, pathname] = uigetfile(filterspec, file_prompt, defaultname);
    if isempty(filename)
        disp('no file selected...')
        return
    end

    
    % load saved ROI file, and assign anything present to ROI fields
    loaded_rois = load([pathname filename]);
    
    if isfield(loaded_rois, 'mask')
        handles.p.roi_mask = loaded_rois.mask;
    end
    if isfield(loaded_rois, 'xi')
        handles.p.roi_xi = loaded_rois.xi;
    end
    if isfield(loaded_rois, 'yi')
        handles.p.roi_yi = loaded_rois.yi;
    end    
    
    handles.p.specandtime_roi = 1;  % enable use of averaging within ROI
    guidata(hObject,handles);
    plot4d_plot(handles);


function peaksearchbutton_Callback(hObject, eventdata, handles)
    if ~isfield(handles.d, 'carbon_recon') || ~isfield(handles.d.carbon_recon, 'image')
        return
    end
    metab_data = handles.d.carbon_recon.image;


    % is there a defined ROI and is averaging over it enabled?
    average_over_roi = handles.p.specandtime_roi && ~isempty(handles.p,'roi_xi') && ...
                       isempty(handles.p,'roi_yi');

    if (average_over_roi)
        volume_mask = zeros(size(metab_data));
        for freq = 1:size(volume_mask,3)
            for slice = 1:size(volume_mask,4)
                for coil = 1:size(volume_mask,5)
                    for time = 1:size(volume_mask,6)
                        volume_mask(:,:,freq,slice,coil,time) = handles.p.roi_mask;
                    end
                end
            end
        end


        metab_data = volume_mask .* metab_data;
        metab_data = sum(sum(metab_data,2),1) ./ sum(sum(volume_mask,2),1);

    else
        % just index by cursor position
        idx1 = min(max(1, handles.p.pointer2d(1)), size(metab_data,1));
        idx2 = min(max(1, handles.p.pointer2d(2)), size(metab_data,2));
        metab_data = metab_data(idx1, idx2, :, :, :, :);
    end


    % average / index over time
    if (handles.p.timestep_length > 1 || handles.p.option_timestep_sum)
        disp('averaging over time')

        if ~handles.p.option_timestep_sum
            time_idx_low = handles.p.timestep_val;
            time_idx_high = time_idx_low + handles.p.timestep_length - 1;        
        else
            time_idx_low = 1;
            time_idx_high = size(metab_data, 6);
        end        

        timestep_range = time_idx_low:time_idx_high;
        if (length(timestep_range) > 1)
            metab_data = mean(metab_data(:,:,:,:,:,timestep_range),6);
        else
            metab_data = metab_data(:,:,:,:,:,timestep_range);
        end

    else
        disp('taking single timepoint')
        metab_data = metab_data(:,:,:,:,:,handles.p.timestep_val);
    end


    % average over coils and slices
    pixel_spectrum = squeeze(mean(mean(abs(metab_data),5),4));


    [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(pixel_spectrum, handles);

    [centres, ~, widths] = FitPeakNear(pixel_spectrum, [pyr_idx, ala_idx, prh_idx, lac_idx], 10, handles);

    disp(' ');
    disp('Fit peaks:')
    dHzdbin = (handles.p.hz(end) - handles.p.hz(1)) / (length(handles.p.hz)-1);

    for n = 1:length(centres)
        centre = handles.p.hz(1) + dHzdbin*(centres(n)-1);
        width = dHzdbin*widths(n);
        disp(['Peak at ' num2str(floor(centre+0.5)) ' Hz  is ' num2str(floor(width+0.5)) ' Hz wide'])
    end
    disp(' ');

    handles.p.f1_val = handles.p.hz(pyr_idx);
    handles.p.f2_val = handles.p.hz(ala_idx);
    handles.p.f3_val = handles.p.hz(prh_idx);
    handles.p.f4_val = handles.p.hz(lac_idx);

    guidata(hObject,handles);
    plot4d_plot(handles);


function [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(pixel_spectrum, handles)
    if ((HaveGEData(handles) && (handles.p.carbon_header.image.user3 == 2 || handles.p.carbon_header.image.user3 == 27)))
        % don't attempt to find peak for selective-frequency reconstructions
        pyr_idx = 1;
        ala_idx = 2;
        prh_idx = 3;
        lac_idx = 4;
        return
    end

    df = handles.p.hz(2) - handles.p.hz(1);
    min_peak_dist_in_hz = handles.p.auto_fit_separation;
    min_peak_dist_in_bins = 1;
    if (df > 0)
        min_peak_dist_in_bins = ceil(min_peak_dist_in_hz / df);
        disp(['searching for peaks at least ' num2str(min_peak_dist_in_hz) ' Hz or ' ...
              num2str(min_peak_dist_in_bins) ' spectrum bins apart']);
    end

    median_level = handles.p.auto_fit_threshold;
    if (median_level < 0)
        median_level = median(pixel_spectrum);
    end
    disp(['Fitting for peaks above threshold: ' num2str(round(median_level))]);

    [~, locs, ~, p] = findpeaks(pixel_spectrum,       ...
                                'MinPeakDistance',    min_peak_dist_in_bins, ...
                                'MinPeakHeight',      median_level);

    % find most prominent peaks in data
    peaks_bins = [];
    [~, ind] = sort(p, 'Descend');
    for n = 1:4
        if (length(ind) >= n)
            peaks_bins(n) = locs(ind(n));                   %#ok<AGROW>
        end
    end
    peaks_bins = sort(peaks_bins);
    peaks_freq = handles.p.hz(peaks_bins);


    % from prominences, sort and assign to metabolite labels
    if (length(peaks_freq) > 0) %#ok<ISMT>
        pyr_freq = peaks_freq(1);
        lac_freq = peaks_freq(end);
    else
        pyr_freq = 0;
        lac_freq = 0;
    end
    if (length(peaks_freq) > 3)
        ala_freq = peaks_freq(2);
        prh_freq = peaks_freq(3);
    elseif (length(peaks_freq) == 3)
        prh_freq = peaks_freq(2);
        ala_freq = mean([prh_freq lac_freq]);
    else
        ala_freq = mean([pyr_freq lac_freq]);
        prh_freq = mean([ala_freq lac_freq]);
    end

    % find frequency bins for each freq and set sliders...
    [~, pyr_idx] = min(abs(pyr_freq - handles.p.hz));
    [~, ala_idx] = min(abs(ala_freq - handles.p.hz));
    [~, prh_idx] = min(abs(prh_freq - handles.p.hz));
    [~, lac_idx] = min(abs(lac_freq - handles.p.hz));


function [centres, heights, widths] = FitPeakNear(pixel_spectrum, peak_search_centres, peak_search_ranges, handles)
    orig_pixel_spectrum = pixel_spectrum;
    centres = [];
    heights = [];
    widths = [];

    % enforce range limits on fit location
    if (length(pixel_spectrum) < 2)
        return
    end
    if (length(peak_search_centres) < 1)
        return
    end
    if (length(peak_search_ranges) < 1)
        peak_search_ranges = 10*ones(size(peak_search_centres));
    elseif (length(peak_search_ranges) == 1)
        peak_search_ranges = peak_search_ranges*ones(size(peak_search_centres));
    end


    % fit peaks individuall in order specified, storing semi-independent best
    % position / width for each
    for peak_id = 1:length(peak_search_centres)
        peak_pos_low = peak_search_centres(peak_id) - peak_search_ranges(peak_id);
        peak_pos_high = peak_search_centres(peak_id) + peak_search_ranges(peak_id);
        if (peak_pos_low < 1)
            peak_pos_low = 1;
        end
        if (peak_pos_high > length(pixel_spectrum))
            peak_pos_high = length(pixel_spectrum);
        end
        best_R2 = Inf;
        best_peak_pos = 1;
        best_width = 0;
        best_fit = ones(size(pixel_spectrum));

        step = 0.2;

        for test_pos = peak_pos_low:step:peak_pos_high
            for caucy_test_width = 1:step:20
                test_shape2= Cauchy(test_pos, caucy_test_width, length(pixel_spectrum));

                fit_input = [test_shape2' ones(size(test_shape2))'];

                params = fit_input \ pixel_spectrum;

                fit_func = fit_input*params;
                R2 = sum(abs(fit_func - pixel_spectrum).^2);
                if (R2 < best_R2)
                    best_R2 = R2;
                    best_peak_pos = test_pos;
                    best_width = caucy_test_width;
                    best_fit = fit_func;
                end
            end
        end


        dHzdbin = (handles.p.hz(end) - handles.p.hz(1))/(length(handles.p.hz)-1);
        peak_centre_hz = handles.p.hz(1) + dHzdbin*(best_peak_pos-1);
        peak_width_hz = dHzdbin*best_width;

        figure(82353)
        plot(handles.p.hz,  best_fit, '-k', ...
             handles.p.hz,  abs(pixel_spectrum), '-r');
        title(['log(R2): ' num2str(round(log(R2)*10)/10) ...
               '  at: '    num2str(round(peak_centre_hz*10)/10) ...
               '  width: ' num2str(round(peak_width_hz*10)/10) '  (Hz)'])
        drawnow
    %     pause

        centres(peak_id) = best_peak_pos;
        widths(peak_id) = best_width;

        pixel_spectrum = pixel_spectrum - best_fit;
    end

    pixel_spectrum = orig_pixel_spectrum;

    % fit all peaks and background level simultaneously
    fit_input = ones(length(centres) + 1, length(pixel_spectrum));

    return

    for peak_id = 1:length(centres)
        fit_input(peak_id, :) = Cauchy(centres(peak_id), widths(peak_id), length(pixel_spectrum))';
    end
    params = fit_input \ pixel_spectrum;

    fit_func = fit_input*params;
    R2 = sum(abs(fit_func - pixel_spectrum).^2);

    figure(82353)
    plot(1:length(best_fit),        best_fit, '-k', ...
         1:length(pixel_spectrum),  abs(pixel_spectrum), '-r');
    title(['R2: ' num2str(R2) '  pos: ' num2str(best_peak_pos) '  width: ' num2str(best_width) '  (bins)'])
    drawnow


function autophasebutton_Callback(hObject, eventdata, handles)
    if ~isfield(handles, 'd') || ~isfield(handles.d, 'carbon_recon') || ~isfield(handles.d.carbon_recon, 'image')
        handles.p.autophase = 0;
        return
    end
    handles.p.autophase = 1;

    guidata(hObject,handles);
    plot4d_plot(handles);

    
function checkbox_fix_click_phase_Callback(hObject, eventdata, handles)
    handles.p.fix_click_phase = handles.checkbox_fix_click_phase.Value;

    guidata(hObject,handles);
    plot4d_plot(handles);  

function pushbutton_spec_range_Callback(hObject, eventdata, handles)
    handles.p.freq_min = min(handles.p.hz);
    handles.p.freq_max = max(handles.p.hz);

    guidata(hObject,handles);
    plot4d_plot(handles);
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% checkbox functions                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function checkbox_signalmax_auto_Callback(hObject, eventdata, handles)
    handles.p.window_auto = handles.checkbox_signalmax_auto.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_flipanglecorrection_Callback(hObject, eventdata, handles)
    handles.p.flipangle_correction_desired = handles.checkbox_flipanglecorrection.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_lorentz_fit_Callback(hObject, eventdata, handles)
    handles.p.lorentz_fit_desired = handles.checkbox_lorentz_fit.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_t1_fit_Callback(hObject, eventdata, handles)
    handles.p.t1_fit_desired = handles.checkbox_t1_fit.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_display_spec_data_Callback(hObject, eventdata, handles)
    handles.p.plot_spectral_data = handles.checkbox_display_spec_data.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_carbon_load_figures_extra_Callback(hObject, eventdata, handles)
    handles.p.carbon_load_figures_extra = handles.checkbox_carbon_load_figures_extra.Value;
    guidata(hObject,handles);

function checkbox_carbon_recon_figures_extra_Callback(hObject, eventdata, handles)
    handles.p.carbon_recon_figures_extra = handles.checkbox_carbon_recon_figures_extra.Value;
    guidata(hObject,handles);

function checkbox_cumsum_Callback(hObject, eventdata, handles)
    handles.p.option_cumsum = handles.checkbox_cumsum.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);   
    
function checkbox_timestep_sum_Callback(hObject, eventdata, handles)
    handles.p.option_timestep_sum = handles.checkbox_timestep_sum.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_freq_sum_Callback(hObject, eventdata, handles)
    handles.p.option_freq_sum = handles.checkbox_freq_sum.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_offset_correction_Callback(hObject, eventdata, handles)
    handles.p.option_offset_correction = handles.checkbox_offset_correction.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_carbon_plot_surface_Callback(hObject, eventdata, handles)
    handles.p.option_plot_surface = handles.checkbox_carbon_plot_surface.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function check_f1_Callback(hObject, eventdata, handles)
    handles.p.option_show_f1 = handles.check_f1.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function check_f2_Callback(hObject, eventdata, handles)
    handles.p.option_show_f2 = handles.check_f2.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function check_f3_Callback(hObject, eventdata, handles)
    handles.p.option_show_f3 = handles.check_f3.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function check_f4_Callback(hObject, eventdata, handles)
    handles.p.option_show_f4 = handles.check_f4.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_carbon_rms_Callback(hObject, eventdata, handles)
    handles.p.option_carbon_rms = handles.checkbox_carbon_rms.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_show_ppm_scale_Callback(hObject, eventdata, handles)
    handles.p.option_freq_as_ppm = handles.checkbox_show_ppm_scale.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_spatial_fft_Callback(hObject, eventdata, handles)
    handles.p.do_spatial_fft = handles.checkbox_spatial_fft.Value;
    guidata(hObject,handles);
    % redo recon for update
    
function checkbox_freq_fft_Callback(hObject, eventdata, handles)
    handles.p.do_freq_fft = handles.checkbox_freq_fft.Value;
    guidata(hObject,handles);
    % redo recon for update


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% radiobuttons                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function radiobutton_specandtime_singlevoxel_Callback(hObject, eventdata, handles)
    handles.p.specandtime_roi = 0;
    handles.p.fit_current_spectrum = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_specandtime_roi_Callback(hObject, eventdata, handles)
    handles.p.specandtime_roi = 1;
    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_no_cursor_Callback(hObject, eventdata, handles)
    handles.p.specandtime_roi = 2;
    guidata(hObject,handles);
    plot4d_plot(handles);

function show_peak_radio_Callback(hObject, eventdata, handles)
    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_intensity_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_intensity = 1;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = 0;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_complex_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_complex = 1;
    handles.p.option_carbon_rms = 0;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = 0;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_real_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_real = 1;
    handles.p.option_carbon_rms = 0;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = 0;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_phase_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_phase = 1;
    handles.p.option_carbon_rms = 0;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = 0;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_lac_pyr_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_lac_pyr = 1;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = 0;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_ala_pyr_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_ala_pyr = 1;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.fit_current_spectrum = 0;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_diff_norm_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_diff_norm = 1;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = 0;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_lac_allfreq_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_lac_allfreqs = 1;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_freq1_offset_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_freq1_offset = 1;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_plot_freq4_offset_Callback(hObject, eventdata, handles)
    PlotNothing(handles);
    handles.p.option_plot_freq4_offset = 1;

    guidata(hObject,handles);
    plot4d_plot(handles);

function PlotNothing(handles)
    handles.p.option_plot_intensity = 0;
    handles.p.option_plot_complex = 0;
    handles.p.option_plot_real = 0;
    handles.p.option_plot_phase = 0;
    handles.p.option_plot_lac_pyr = 0;
    handles.p.option_plot_ala_pyr = 0;
    handles.p.option_plot_diff_norm = 0;
    handles.p.option_plot_lac_allfreqs = 0;
    handles.p.option_plot_ala_allfreqs = 0;

    handles.p.option_plot_freq1_offset = 0;
    handles.p.option_plot_freq4_offset = 0;
    
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = 0;
    
function radiobutton_default_colourmap_Callback(hObject, eventdata, handles)
    handles.p.option_colourmap = 'default';
    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_hot_colourmap_Callback(hObject, eventdata, handles)
    handles.p.option_colourmap = 'hot';
    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_jet_colourmap_Callback(hObject, eventdata, handles)
    handles.p.option_colourmap = 'jet';
    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_gray_colourmap_Callback(hObject, eventdata, handles)
    handles.p.option_colourmap = 'gray';
    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_zoom_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;
    
    % uncheck all
    handles.radiobutton_zoom1.Value = 0;
    handles.radiobutton_zoom2.Value = 0;
    handles.radiobutton_zoom3.Value = 0;
    handles.radiobutton_zoom4.Value = 0;
    
    % recheck whichever was clicked, record selected zoom level
    if (strcmp('radiobutton_zoom1', hObject.Tag))
        handles.p.carbon_recon_zoom = 1;
        handles.radiobutton_zoom1.Value = 1;
    elseif (strcmp('radiobutton_zoom2', hObject.Tag))
        handles.p.carbon_recon_zoom = 2;
        handles.radiobutton_zoom2.Value = 1;
    elseif (strcmp('radiobutton_zoom3', hObject.Tag))
        handles.p.carbon_recon_zoom = 3;
        handles.radiobutton_zoom3.Value = 1;
    elseif (strcmp('radiobutton_zoom4', hObject.Tag))
        handles.p.carbon_recon_zoom = 4;
        handles.radiobutton_zoom4.Value = 1;
    end
    
    guidata(hObject,handles);    
%     plot4d_plot(handles); % no GUI response until recon button pushed


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% edit fields                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function edit_resolution_Callback(hObject, eventdata, handles)
    % not used...

function edit_resolution2_Callback(hObject, eventdata, handles)
    % not used

function edit_t1_metabolite_Callback(hObject, eventdata, handles)
    val = str2double(get(hObject,'String'));
    if isempty(val)
        val = 14;   % default value;
    end
    handles.p.t1_metabolite = val;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_window_low_Callback(hObject, eventdata, handles)
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        guidata(hObject,handles);
        plot4d_plot(handles);

        return
    end

    % changing low value should not change the high value unless the new low
    % value is equal or greater than the old high value. so, adjust the window
    % length based on the difference in the old and new window (low) values
    window_val_shift = edit_num - handles.p.window_val;
    new_window_length = handles.p.window_length - window_val_shift;
    handles.p.window_length = new_window_length; % may be negative, but may be overwritten by checks in plot function

    handles.p.window_val = edit_num;

    handles.p.window_auto = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_window_high_Callback(hObject, eventdata, handles)
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        guidata(hObject,handles);
        plot4d_plot(handles);

        return
    end

    % changing high value should not change the low value unless the new high
    % value is less than or equal to old low value. so, adjust the window
    % length based on the difference in the old and new window (high) values,
    % and change the low value only if the high value is set too low
    if edit_num <= handles.p.window_val
        handles.p.window_val = edit_num - 1;
    end

    handles.p.window_length = edit_num - handles.p.window_val;

    handles.p.window_auto = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_proton_file_Callback(hObject, eventdata, handles) %#ok<*INUSD,*DEFNU>
    handles.pushbutton_proton_select.BackgroundColor = handles.p.color_lightgrey;
    handles.pushbutton_proton_load_and_recon.BackgroundColor = handles.p.color_lightgrey;


function edit_carbon_file_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_select.BackgroundColor = handles.p.color_lightgrey;
    handles.pushbutton_carbon_load.BackgroundColor = handles.p.color_lightgrey;
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;


function edit_scalingfactor_f1_Callback(hObject, eventdata, handles)
    val = str2double(get(hObject,'String'));
    if isempty(val), val = handles.p.downscale_f1; end
    handles.p.downscale_f1 = val;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_carbon_shift_x_Callback(hObject, eventdata, handles)
    val = str2double(get(hObject,'String'));
    if isempty(val), val = handles.p.carbon_shift_x; end
    handles.p.carbon_shift_x = val;
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;
    guidata(hObject,handles);


function edit_carbon_shift_y_Callback(hObject, eventdata, handles)
    val = str2double(get(hObject,'String'));
    if isempty(val), val = handles.p.carbon_shift_y; end
    handles.p.carbon_shift_y = val;
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;
    guidata(hObject,handles);


function edit_f1_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end
    
    [~, idxs] = min(abs(handles.p.hz - edit_num));
    idx = idxs(1);
    
    handles.p.f1_val = handles.p.hz(idx);

    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_f2_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end

    [~, idxs] = min(abs(handles.p.hz - edit_num));
    idx = idxs(1);
    
    handles.p.f2_val = handles.p.hz(idx);

    guidata(hObject,handles);
    plot4d_plot(handles);

    
function edit_f3_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end

    [~, idxs] = min(abs(handles.p.hz - edit_num));
    idx = idxs(1);
    
    handles.p.f3_val = handles.p.hz(idx);

    guidata(hObject,handles);
    plot4d_plot(handles);

    
function edit_f4_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end

    [~, idxs] = min(abs(handles.p.hz - edit_num));
    idx = idxs(1);
    
    handles.p.f4_val = handles.p.hz(idx);

    guidata(hObject,handles);
    plot4d_plot(handles);

    
function edit_f1_ppm_Callback(hObject, eventdata, handles)
    % convert to Hz
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end
    freq_desired = (edit_num - handles.p.working_freq_ppm) * handles.p.reference_freq;
    
    % set Hz freq edit to that value, then update as if it had been typed
    % in directly
    handles.edit_f1.String = num2str(freq_desired);
    edit_f1_Callback(handles.edit_f1, eventdata, handles);

    
function edit_f2_ppm_Callback(hObject, eventdata, handles)
    % convert to Hz
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end
    freq_desired = (edit_num - handles.p.working_freq_ppm) * handles.p.reference_freq;
    
    % set Hz freq edit to that value, then update as if it had been typed
    % in directly
    handles.edit_f2.String = num2str(freq_desired);
    edit_f2_Callback(handles.edit_f2, eventdata, handles);

    
function edit_f3_ppm_Callback(hObject, eventdata, handles)
    % convert to Hz
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end
    freq_desired = (edit_num - handles.p.working_freq_ppm) * handles.p.reference_freq;
    
    % set Hz freq edit to that value, then update as if it had been typed
    % in directly
    handles.edit_f3.String = num2str(freq_desired);
    edit_f3_Callback(handles.edit_f3, eventdata, handles);

    
function edit_f4_ppm_Callback(hObject, eventdata, handles)
    % convert to Hz
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end
    freq_desired = (edit_num - handles.p.working_freq_ppm) * handles.p.reference_freq;
    
    % set Hz freq edit to that value, then update as if it had been typed
    % in directly
    handles.edit_f4.String = num2str(freq_desired);
    edit_f4_Callback(handles.edit_f4, eventdata, handles);


function edit_freq_low_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        guidata(hObject,handles);
        plot4d_plot(handles);

        return
    end

    slider_max_idx = max(1, min(handles.slider_freq.Max, length(handles.p.hz)));
    slider_max_freq = handles.p.hz(slider_max_idx);
    slider_min_idx = max(1, min(handles.slider_freq.Min, length(handles.p.hz)));
    slider_min_freq = handles.p.hz(slider_min_idx);

    if (edit_num < slider_min_freq)
        edit_num = slider_min_freq;
    elseif (edit_num > slider_max_freq)
        edit_num = slider_max_freq;
    end


    % changing low value should not change the high value unless the new low
    % value is equal or greater than the old high value. so, adjust the window
    % length based on the difference in the old and new frequency (low) values
    freq_val_shift = edit_num - handles.p.freq_val;
    new_freq_length = handles.p.freq_length - freq_val_shift;
    handles.p.freq_length = new_freq_length; % may be negative, but may be overwritten by checks in plot function
    handles.p.freq_val = edit_num;

    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_freq_high_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        guidata(hObject,handles);
        plot4d_plot(handles);

        return
    end

    slider_max_idx = max(1, min(handles.slider_freq.Max, length(handles.p.hz)));
    slider_max_freq = handles.p.hz(slider_max_idx);
    slider_min_idx = max(1, min(handles.slider_freq.Min, length(handles.p.hz)));
    slider_min_freq = handles.p.hz(slider_min_idx);

    if (edit_num < slider_min_freq)
        edit_num = slider_min_freq + 1;
    elseif (edit_num > slider_max_freq)
        edit_num = slider_max_freq;
    end

    % changing high value should not change the low value unless the new high
    % value is less than or equal to old low value. so, adjust the window
    % length based on the difference in the old and new window (high) values,
    % and change the low value only if the high value is set too low
    if edit_num <= handles.p.freq_val
        handles.p.freq_val = edit_num - 1;
    end
    handles.p.freq_length = edit_num - handles.p.freq_val;

    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_fit_threshold_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = -1;  % auto decide
    end
    handles.p.auto_fit_threshold = edit_num;
    if (edit_num < 0)
        hObject.String = 'median';
    end
    guidata(hObject,handles);


function edit_fit_separation_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 120;  % auto decide
    end
    handles.p.auto_fit_separation = edit_num;
    guidata(hObject,handles);


function edit_plot_freq_min_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = min(handles.p.hz);
    end

    handles.p.freq_min = edit_num;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_plot_freq_max_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = max(handles.p.hz);
    end

    handles.p.freq_max = edit_num;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_phase0_Callback(hObject, eventdata, handles)
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end

    handles.p.spectrum_phase0 = edit_num;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_phase1_Callback(hObject, eventdata, handles)
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        edit_num = 0;
    end

    if (~handles.p.fix_click_phase)
        handles.p.spectrum_phase1 = edit_num;
    else
        % determine phase at middle click frequency before changing linear
        % phase factor
        middle_freq = (handles.p.freq_val + handles.p.freq_length / 2);
        old_middle_freq_phase = handles.p.spectrum_phase0 + middle_freq * handles.p.spectrum_phase1 / 1000;
        old_middle_freq_phase = mod(old_middle_freq_phase + 180, 360) - 180;
        
        %disp(['Initial phase: ' num2str(old_middle_freq_phase) ' deg   at: ' num2str(middle_freq) ' Hz'])
        
        % set linear phase factor...
        handles.p.spectrum_phase1 = edit_num;
        
        % adjust 0th order phase to restore middle click freq phase
        new_base_middle_freq_phase = middle_freq * handles.p.spectrum_phase1 / 1000;
        new_base_middle_freq_phase = mod(new_base_middle_freq_phase + 180, 360) - 180;
        
        phase_diff = old_middle_freq_phase - new_base_middle_freq_phase;
        phase_diff = mod(phase_diff + 180, 360) - 180;
        
        handles.p.spectrum_phase0 = phase_diff;
        
    end
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_fid_window_low_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0 || nnz(size(edit_num)) > 2
        edit_num = 1;
    end
    if (edit_num < 1)
        edit_num = 1;
    end

    if (HaveSiemensData(handles))
        num_fid_samples = size(handles.d.carbon_data_raw,1);
    else
        num_fid_samples = size(handles.d.carbon_data_raw,2);
    end
    if (edit_num > num_fid_samples)
        edit_num = num_fid_samples;
    end

    if (edit_num > handles.p.carbon_recon_point_high)
        handles.p.carbon_recon_point_high = edit_num;
        handles.edit_fid_window_high.String = edit_num;
    end

    handles.edit_fid_window_low.String = edit_num;
    handles.p.carbon_recon_point_low = edit_num;


function edit_fid_window_high_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>

    if (HaveSiemensData(handles) || HaveBrukerData(handles))
        num_fid_samples = size(handles.d.carbon_data_raw,1);
    else
        num_fid_samples = size(handles.d.carbon_data_raw,2);
    end

    if nnz(size(edit_num)) == 0 || nnz(size(edit_num)) > 2
        edit_num = num_fid_samples;
    end
    if (edit_num < 1)
        edit_num = 1;
    end
    if (edit_num > num_fid_samples)
        edit_num = num_fid_samples;
    end

    if (edit_num < handles.p.carbon_recon_point_low)
        handles.p.carbon_recon_point_low = edit_num;
        handles.edit_fid_window_low.String = edit_num;
    end

    handles.edit_fid_window_high.String = edit_num;
    handles.p.carbon_recon_point_high = edit_num;

    guidata(hObject,handles);
    plot4d_plot(handles);
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;


function edit_broadening_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0 || nnz(size(edit_num)) > 2
        edit_num = 0;
    end
    if (edit_num < 0)
        edit_num = 0;
    end

    handles.edit_broadening.String = edit_num;
    handles.p.carbon_line_broadening = edit_num;

    guidata(hObject,handles);
%     plot4d_plot(handles); % no GUI response until recon button pushed


function edit_timestep_low_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        guidata(hObject,handles);
        plot4d_plot(handles);

        return
    end

    if (edit_num < 1)
        edit_num = 1;
    end
    if (isfield(handles.d,'carbon_recon') && edit_num > max(1, size(handles.d.carbon_recon.image,6)))
        edit_num = max(1, size(handles.d.carbon_recon.image,6));
    end

    % changing low value should not change the high value unless the new low
    % value is equal or greater than the old high value. so, adjust the window
    % length based on the difference in the old and new frequency (low) values
    time_shift = edit_num - handles.p.timestep_val;
    new_timestep_length = handles.p.timestep_length - time_shift;
    handles.p.timestep_length = new_timestep_length; % may be negative, but may be overwritten by checks in plot function

    handles.p.timestep_val = edit_num;

    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_timestep_high_Callback(hObject, eventdata, handles)
    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0 || nnz(size(edit_num)) > 2
        edit_num = 0;
    end
    if (edit_num < 0)
        edit_num = 0;
    end
    if (isfield(handles, 'd') && isfield(handles.d,'carbon_recon') && edit_num > max(1, size(handles.d.carbon_recon.image,6)))
        edit_num = max(1, size(handles.d.carbon_recon.image,6));
    end

    % changing high value should not change the low value unless the new high
    % value is less than the old low value. so, adjust the window
    % length based on the difference in the old and new window (high) values,
    % and change the low value only if the high value is set too low
    if edit_num <= handles.p.timestep_val
        handles.p.timestep_val = edit_num;
    end
    handles.p.timestep_length = edit_num - handles.p.timestep_val + 1;

    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_intensity_shift_Callback(hObject, eventdata, handles)
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0 || nnz(size(edit_num)) > 2
        edit_num = 0;
    end

    handles.p.intensity_offset = edit_num;

    guidata(hObject,handles);
    plot4d_plot(handles);


function slider_proton_overlay_alpha_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha = hObject.Value;

    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_alpha_threshold_Callback(hObject, eventdata, handles)
    handles.p.option_alpha_threshold = str2double(hObject.String);

    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_total_signal_threshold_Callback(hObject, eventdata, handles)
    handles.p.option_total_signal_threshold = str2double(hObject.String);

    guidata(hObject,handles);
    plot4d_plot(handles);

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% functions related to reconstruction etc.                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function proton_load(hObject,handles)
    [~,base,ext] = fileparts(handles.p.proton_file);

    if (strcmp(ext,'.7') == 1)
        proton_load_ge_pfile(hObject,handles);
    elseif (strcmp(ext,'.dcm') == 1 || strcmp(ext,'.IMA') == 1)
        proton_load_dicom(hObject,handles);
    elseif (strcmp(ext,'.dat') == 1)
        proton_load_siemens_dat(hObject,handles);
    elseif (strcmp(ext,'') == 1 && strcmp(base,'2dseq') == 1)
        proton_load_bruker(hObject,handles);
    end    
    
    
function proton_load_dicom(hObject,handles)
    handles.d.proton_image = dicomread(handles.p.proton_file);
    
    sz = size(handles.d.proton_image);
    if (length(sz) < 3)
        sz(3) = 1;
    end
    temp_rotated_image = zeros(sz(2), sz(1), sz(3));
    for slice = 1:size(handles.d.proton_image,3)
        temp_rotated_image(:,:,slice) = rot90(handles.d.proton_image(:,:,slice),3);
    end
    handles.d.proton_image = temp_rotated_image;

    
    dcm_info = dicominfo(handles.p.proton_file);
    handles.p.proton_fov = dcm_info.PixelSpacing .* [size(handles.d.proton_image,1) size(handles.d.proton_image,2)]';
    
    % todo: handle non-square pixel sizes
    
    handles.p.slice_proton_val = floor((size(handles.d.proton_image,3) + 1)/2);
    
    % update handles and display proton image
    guidata(hObject,handles);
    plot4d_plot(handles);    
    
    
function proton_load_ge_pfile(hObject,handles)
    % load and reconstruct proton image
    [proton_data, proton_header] = read_MR_rawdata(handles.p.proton_file);
    
    if (strcmp(proton_header.image.psd_iname, 'FSE') == 1)
        handles.d.proton_image = squeeze(fsexl(proton_data,proton_header)); % part of Stephans recon files
    elseif (strcmp(proton_header.image.psd_iname, 'FGRE') == 1)
        handles.d.proton_image = squeeze(fspgr(proton_data,proton_header)); % modified from Stephan's code by Geoff
    else
        error('unrecognized proton pulse sequence!')
    end   
    handles.p.proton_fov = [proton_header.image.dfov proton_header.image.dfov];
    
    disp('Loading and reconstruction of proton data finished.');

    % pick middle slice by default
    handles.p.slice_proton_val = floor((size(handles.d.proton_image,3) + 1)/2);
    
    % update handles and display proton image
    guidata(hObject,handles);
    plot4d_plot(handles);
    
    
function proton_load_siemens_dat(hObject,handles)
    raw = mapVBVD(handles.p.proton_file, 'removeOS'); % remove OS removes frequency-encode over sampling, or so says the comments...

    % reconstruct k-space data in 2 dimensions
    kspace_anat = raw.image{''};
    proton_image = fftshift(fft( ...
                                fftshift(fft(kspace_anat, [], 1) ,1), ...
                                [], 2) ,2);
                            
    % average together multiple acquisitions
    handles.d.proton_image = abs(mean(proton_image, 3));
    
    % pick middle slice by default (or the only slice...)
    handles.p.slice_proton_val = floor((size(handles.d.proton_image,3) + 1)/2);
    handles.p.proton_fov = [raw.hdr.Config.ReadFoV raw.hdr.Config.PhaseFoV];
    
    % update handles and display proton image
    guidata(hObject,handles);
    plot4d_plot(handles)
    
    
function proton_load_bruker(hObject,handles)
    imageObj = ImageDataObject(handles.p.proton_file);
    imageObj = imageObj.readReco;
    imageObj = imageObj.readMethod;
    
    handles.d.proton_image = flip(squeeze(imageObj.data),2);

    % pick middle slice by default (or the only slice...)
    handles.p.slice_proton_val = floor((size(handles.d.proton_image,3) + 1)/2);
    handles.p.proton_fov = imageObj.Reco.RECO_fov * 10;
    
    % swap FOV dimensions as required to be correctly displayed
    if (length(handles.p.proton_fov) > 1)
        if iscell(imageObj.Method.PVM_SPackArrSliceOrient) && (max(size(imageObj.Method.PVM_SPackArrSliceOrient)) > 1)
            if (strcmp(imageObj.Method.PVM_SPackArrSliceOrient{1}, 'coronal'))
                handles.p.proton_fov([1 2]) = handles.p.proton_fov([2 1]);
            end
        else
            if (strcmp(imageObj.Method.PVM_SPackArrSliceOrient, 'coronal'))
                handles.p.proton_fov([1 2]) = handles.p.proton_fov([2 1]);
            end
        end
    end
    %inserted section(2020.04.20, Martin G. - get voxel resolution of proton image and save in Vox_Sz)
    mat_sz = size(handles.d.proton_image);
    Vox_Sz = handles.p.proton_fov / mat_sz(1:2);
    if size(Vox_Sz) > 1
        if Vox_Sz(1) == Vox_Sz(2)
            handles.p.Vox_Sz = Vox_Sz(1);
        else
            handles.p.Vox_Sz = mean(Vox_Sz);
            disp('Warning!! Proton Image has anisotropic Voxels')
        end
    else
        handles.p.Vox_Sz = Vox_Sz;
    end
    %End inserted section
    
    % update handles and display proton image
    guidata(hObject,handles);
    plot4d_plot(handles)    
    
    
function carbon_load_common(handles)
    % clear storage for per-pixel peak frequencies
    if (isfield(handles, 'd') && isfield(handles.d, 'carbon_image_freq1_idx'))
        handles.d = rmfield(handles.d, 'carbon_image_freq1_idx');
    end
    if (isfield(handles, 'd') && isfield(handles.d, 'carbon_image_freq4_idx'))
        handles.d = rmfield(handles.d, 'carbon_image_freq4_idx');
    end
    
    if ~isprop(handles.p, 'apply_checkerboard_phase')
        handles.p.addprop('apply_checkerboard_phase');
    end
    handles.p.apply_checkerboard_phase = 1; % unless set otherwise...    
    
    handles.d.carbon_data_raw = zeros(1,1);
    if ~isprop(handles.p, 'carbon_header')
        handles.p.addprop('carbon_header');
    end
    if ~isprop(handles.p, 'carbon_data_raw')
        handles.p.addprop('carbon_data_raw');
    end  
    handles.p.carbon_data_raw = [];
    
    handles.p.reference_freq = 75.5; % may be overriden by subsequent load functions
    handles.p.working_freq_ppm = 0.0;
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_intensity = 1;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.fit_current_spectrum = 0;
    
    
function carbon_load(hObject,handles)
    [~,base,ext] = fileparts(handles.p.carbon_file);
    
    if (strcmp(ext,'.7') == 1)
        carbon_load_ge_pfile(hObject, handles);
        
    elseif (strcmp(ext,'.dat') == 1)
        carbon_load_siemens_dat(hObject, handles);
        
    elseif (strcmp(ext,'.bf') == 1)
        carbon_load_siemens_bf(hObject, handles);
        
    elseif (strcmp(ext,'') == 1 && strcmp(base,'2dseq') == 1)
        carbon_load_bruker_2dseq(hObject, handles);
        
    elseif (strcmp(ext,'') == 1 && (strcmp(base,'fid') == 1) || (strcmp(base,'ser') == 1))
        carbon_load_bruker_fid(hObject, handles);
        
    elseif (length(ext) == 5 && strcmp(ext(1:4),'.job') == 1)
        carbon_load_bruker_job(hObject, handles);
        
    end    
 
    
function carbon_load_siemens_bf(hObject,handles)
    carbon_load_common(handles)
    handles.d.carbon_recon = [];
    
    handles.p.apply_checkerboard_phase = 1;
    
    params.lb = handles.p.carbon_line_broadening;
    params.xshift = handles.p.carbon_shift_x;
    params.yshift = handles.p.carbon_shift_y;
    
    % load and reconstruct carbon data
    [dirname,filename,~] = fileparts(handles.p.carbon_file);
    
    fname_dcm = [dirname '\' filename '.dcm'];
    fname_bf = [dirname '\' filename '.bf'];
    file = fileread(fname_dcm);
    name_loc = strfind(file,'tProtocolName');
    handles.p.carbon_header.method = file(name_loc + 20:name_loc + 38);
    handles.p.carbon_header.is_Siemens_bf_data = 1;
    workfreq_loc = strfind(file,'ImagedNucleus');       % Frequency
    handles.p.reference_freq = str2double(file(workfreq_loc-92:workfreq_loc-92+8));

    % OBS! Sometimes FOV(1) and (2) has to be changed - if the voxels are
    % anisotrope: 
    change_dim = 0;
    if change_dim == 1
        FOV_loc1 = strfind(file,'VoiReadoutFoV');       % FOV location
        FOV_loc2 = strfind(file,'VoiOrientation');  
    else
        FOV_loc1 =  strfind(file,'VoiOrientation');     % FOV location
        FOV_loc2 =  strfind(file,'VoiReadoutFoV'); 
    end 
    handles.p.carbon_fov(1) = str2double(file(FOV_loc1-96:FOV_loc1-96+5)); % FOV
    handles.p.carbon_fov(2) = str2double(file(FOV_loc2-96:FOV_loc2-96+5)); % FOV

    N_loc = strfind(file,'VectorSize');             % Vector size
    handles.p.carbon_header.N = sscanf(file(N_loc+13:N_loc+30),'%f');
    Dwell_loc = strfind(file,'RealDwellTime');      % Dwell time
    handles.p.carbon_header.dwell_time = str2double(file(Dwell_loc+100:Dwell_loc+105))*10^(-9);
    handles.p.carbon_header.specw = 1/handles.p.carbon_header.dwell_time;
    TE_loc = strfind(file,'EchoTime');              % Echo time
    handles.p.carbon_header.TE = str2double(file(TE_loc+100:TE_loc+105))*10^(-6); % Variable curently not in use
    TR_loc = strfind(file,'alTR[0]');   % Repetition time
    TR_search_region = file(TR_loc+10:TR_loc+18);
    handles.p.carbon_header.tr = sscanf(TR_search_region,'%f')*10^(-9);
    %handles.p.reference_freq = 32.118348;            %frequency of MeSi4 (0ppm) at 3T. changed compared to other reco-functions since PET-MR operates at 3T
   
    % read slice position of CSI data   
    str = {'dSag', 'dCor', 'dTra'};
    for s = 1:numel(str)
    pos_loc = strfind(file, ...
        ['sSliceArray.asSlice[0].sPosition.' str{s}]);
        if isempty(pos_loc)
            pos_CSI(s) = 0;    
        else
            pos_search_region = file(pos_loc+40:pos_loc+70);
            pos_CSI(s) = sscanf(pos_search_region,'%f');
        end
    end
    handles.p.carbon_header.slicePositions(1,:) = pos_CSI; % in mm
    
% determine slice normal direction
    for s = 1:numel(str)
        norm_loc = strfind(file,...
            ['sSliceArray.asSlice[0].sNormal.' str{s}]);
        if ~isempty(norm_loc)
            norm_search_region = file(norm_loc+38:norm_loc+60);
            sNormal_CSI(s) = sscanf(norm_search_region,'%f');
        else
            sNormal_CSI(s) = 0;
        end
    end
    
    switch find(sNormal_CSI)    % determine slice orientation from previously determined normal vector of slice
        case  1
           handles.p.carbon_header.sliceOrient = 'sagittal';
        case  2
           handles.p.carbon_header.sliceOrient = 'coronal';
        case  3
           handles.p.carbon_header.sliceOrient = 'axial';
    end
    
    %determine read orientation from definition of FOV previously
    if change_dim == 0
        handles.p.carbon_header.readOrient = '-Y_+Y';
    else
        handles.p.carbon_header.readOrient = '-X_+X';
    end
    handles.p.carbon_header.loaded_data_from = '.bf-file'; % (was "fid" in bruker case) -> determine how to do recon later
    
    
    %Actual loading of raw data from .bf-file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fileInfo=dir(fname_bf);          % File information
    fileSize=fileInfo.bytes;         % File size in bytes    
    matrix_size=sqrt(fileSize/handles.p.carbon_header.N/8);  % Size of matrix

    % Reading of data
    csi = fopen(fname_bf);
    rawdata = fread(csi,[matrix_size^2*handles.p.carbon_header.N*2 1],'*single');

    % Complex FID --> combine the values from array to complex-pair values 
    raw = rawdata(1:2:end)+1i*rawdata(2:2:end);
    raw = double(raw);
    % Spectra sorted in matrix
    handles.d.carbon_data_raw = reshape(raw,[handles.p.carbon_header.N matrix_size matrix_size]);
    %End of loading-section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    
    dwell_time_scale_factor = 1; % may be overwritten later
    disp(['CSI Data Acquired with Method: ' handles.p.carbon_header.method])
    if (strcmp(handles.p.carbon_header.method, 'Head_csi_thin_slice'))             
        
        xsz_loc = strfind(file,'sSpecPara.lFinalMatrixSizePhase');	
        xsz_search_region = file(xsz_loc+34:xsz_loc+45);
        xsz = sscanf(xsz_search_region,'%f');
        ysz_loc = strfind(file,'sSpecPara.lFinalMatrixSizeRead');	
        ysz_search_region = file(ysz_loc+33:ysz_loc+45);
        ysz = sscanf(ysz_search_region,'%f');
        if ndims(handles.d.carbon_data_raw) > 3
            disp('Apparent usage of multislice-csi or several coils, please modify code accordingly')
        else
            zsz = 1;
        end
        
        %if (strcmp(imageObj.Method.Method, '<User:geoffCSI_MS>') || ...          some codepiece to set zsz to #slices of multislice method is applied
        %    strcmp(imageObj.Method.Method, '<User:csi_multislice_1>'))
        %    % todo: maybe need to handle if each slice pack has multiple
        %    % slices?
        %    zsz = imageObj.Acqp.NSLICES;
        %end
        
        tsz = 1;
        disp('NR set to 1, for multiframe-CSI, please update "tsz" accordingly in load data-function')
        fidsz = size(handles.d.carbon_data_raw, 1);
        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, fidsz, xsz, ysz, zsz, tsz, []); %%%%%%continue coding here
    else
        error('Unrecognized Siemens CSI-Method! Dont know how to process bf-data...')
    end
    
    % carbon_data_raw should now by a 3+D matrix indexed by:
    % (Samples in FID), (spatial dim 1), (spatial dim 2), (spatial dim 3), (timepoint), (coils)
    handles.p.carbon_resolution = [xsz ysz];
    
    %ExtractBrukerHeaderInfo(imageObj, handles);        %-> needs a modified version of this function which extracts parameters from Siemens bf-file

    
    handles.d.carbon_recon.hz = linspace(0.5, -0.5, size(handles.d.carbon_data_raw,1)) .* handles.p.carbon_header.specw / dwell_time_scale_factor;

    handles.p.carbon_recon_point_low = 1;
    handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,1);
    
    if (handles.p.carbon_load_figures_extra == 1)
        % show raw data...
        
        centre_x = ceil(size(handles.d.carbon_data_raw,2)/2 + 0.1); % index 5 for an 8x8 or 9x9 matrix
        centre_y = ceil(size(handles.d.carbon_data_raw,3)/2 + 0.1);
        num_pts = size(handles.d.carbon_data_raw,1);
        disp(['Centre kspace coords: ' num2str([centre_x centre_y])])
        

        peak_frame_idx = 1; % may be modified...
        
        if (size(handles.d.carbon_data_raw,5) > 1)
            figure(823584)
            
            compressed_data = abs(handles.d.carbon_data_raw(:,centre_x,centre_y,:,:));
            compressed_data = mean(compressed_data,4);
            compressed_data = mean(compressed_data,1);
            
            plot(squeeze(compressed_data))
            title('Centre K-Space Mean FID Magnitude vs. Frame')
            ylabel('Signal [AU] magnitude')
            xlabel('Frame Number')
            
            [~, peak_frame_idx] = max(compressed_data);
        end
        
    
        acquisition_time = handles.p.carbon_header.dwell_time * 1000 * dwell_time_scale_factor * 2; %check here that acquisition time is calculated correctly
  
        
        
        figure(823532)
        xaxisvals = (1:num_pts) * acquisition_time / num_pts;
        plot(xaxisvals, real(handles.d.carbon_data_raw(:,centre_x,centre_y,peak_frame_idx)), ...
             xaxisvals, imag(handles.d.carbon_data_raw(:,centre_x,centre_y,peak_frame_idx)));
        title('Centre K-Space Peak FID')
        ylabel('Signal [AU] magnitude')
        xlabel('Sampling Time (ms)')     
        
        if (size(handles.d.carbon_data_raw,2) > 1 || size(handles.d.carbon_data_raw,3) > 1)
            figure(8254327)
        
            compressed_data = abs(handles.d.carbon_data_raw);
            compressed_data = mean(mean(mean(compressed_data,5),4),1);
        
            imagesc(squeeze(compressed_data));
            title('Mean Magnitude of FIDs (Averaged Over Time)')
            axis image
            colorbar
            colormap jet
        end
    end
    

    % do FID / k-space to image recon ----------------------------------> Make sure that all parameters here can be properly obtained from siemens file
    params.dwell_time = handles.p.carbon_header.dwell_time;
    params.read_fov =   handles.p.carbon_fov(1);
    params.phase_fov =  handles.p.carbon_fov(2);
    params.method =     handles.p.carbon_header.method;
    params.readOrient = handles.p.carbon_header.readOrient;
    params.sliceOrient= handles.p.carbon_header.sliceOrient;
    params.zoom =       handles.p.carbon_recon_zoom;
    params.freq_fft =   handles.p.do_freq_fft;
    params.spat_fft =   handles.p.do_spatial_fft;

    handles.d.carbon_recon.image = bruker_kspace_fid_recon(handles.d.carbon_data_raw, params);   
    handles.d.carbon_recon.image = fliplr(handles.d.carbon_recon.image); %%%%%%% check here for rotation
    
    handles.p.carbon_recon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
    
    
    % the following is common for all sequences
    disp(['Loading of carbon data finished. Size: ' num2str(size(handles.d.carbon_recon.image)) ...
          ' [X Y freqencies slices coils timesteps]']);

    
    % extract frequency axis
    if (isfield(handles.d.carbon_recon, 'hz'))
        handles.p.hz = handles.d.carbon_recon.hz;
    else
        handles.p.hz = [];
    end
    handles.p.ppm = handles.p.hz / handles.p.reference_freq - handles.p.working_freq_ppm;

    
    if (exist('findpeaks')) %#ok<EXIST>                              -------------> no modification as data is already loaded, just generall preprocessing...
        % intialize display frequencies by summing over whole image
        % find overall image mean highest peak in spectrum
        spec_data = permute(abs(handles.d.carbon_recon.image), [1 2 4 5 6 3]);
        spec_data = squeeze(sum(sum(sum(sum(sum(spec_data,5),4),3),2),1));
        
        [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(spec_data, handles);
        handles.p.f1_val = handles.p.hz(pyr_idx);
        handles.p.f2_val = handles.p.hz(ala_idx);
        handles.p.f3_val = handles.p.hz(prh_idx);
        handles.p.f4_val = handles.p.hz(lac_idx);
        
        idxs = [pyr_idx ala_idx prh_idx lac_idx];
        biggest_idx = 1;
        for n = 1:length(idxs)
            if (spec_data(idxs(n)) > spec_data(biggest_idx))
                biggest_idx = idxs(n);
            end
        end
        handles.p.freq_val = handles.p.hz(biggest_idx);
    end
    

    % set the pointer to the center of the image
    if ~isprop(handles.p, 'pointer2d')
        handles.p.addprop('pointer2d');
    end
    handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
    handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
    
    
    handles.p.slice_carbon_val = 1;
    handles.p.coil_carbon_val = 1;
    handles.p.timestep_val = 1;

    
    % use number of sampled points and time per sampled point (TR) to get
    % the total frame TR
    handles.p.nExcitationsPerTimestep = xsz * ysz; 
    disp('nExcitationsPerTimestep = MxN matrix size (provided no multislice CSI is used here (in this case please modify code accordingly!')
    total_frame_TR = handles.p.nExcitationsPerTimestep(1) * handles.p.carbon_header.tr / 1000;
    handles.edit_repetitiontime.String = num2str(total_frame_TR);
    
    
  
    num_frames = max(1, size(handles.d.carbon_recon.image, 6));
    if total_frame_TR > 0
        handles.p.timeaxis = total_frame_TR * (1:num_frames);
    else
        handles.p.timeaxis = 1:num_frames;
        warning('time axis is labelled incorrectly, since TR is not defined. Shown are the number of steps, not the time in seconds.');
    end
  

    guidata(hObject,handles);
    plot4d_plot(handles)    
    
        
function carbon_load_siemens_dat(hObject,handles)
    carbon_load_common(handles)
    handles.d.carbon_recon = [];
    
    handles.p.apply_checkerboard_phase = 0;
    
    params.lb = handles.p.carbon_line_broadening;
    params.xshift = handles.p.carbon_shift_x;
    params.yshift = handles.p.carbon_shift_y;
    
    
    % load and reconstruct carbon data
    if ~isprop(handles.p, 'carbon_header')
        handles.p.addprop('carbon_header');
    end
    handles.p.carbon_header = [];
    
    raw = mapVBVD_github_20190610(handles.p.carbon_file);
    handles.p.working_freq_ppm = 165.5; %calibration is always done on urea!!!
    handles.p.reference_freq = 32.1252; %Data can only be from 3T PET-MR at nuclear medicine!!
    disp('Reference Frequency adjusted for 3T! (32.1252 MHz)')
    
    % load and reconstruct carbon data
    handles.d.carbon_data_raw = raw.image{''};
    handles.p.carbon_header = raw.hdr;
    handles.p.reference_freq = handles.p.carbon_header.Config.Frequency / 1e6;
    B1amplitude = handles.p.carbon_header.Spice.TransmitterReferenceAmplitude;
    disp(['B1 amplitude: ' num2str(B1amplitude) ' Hz'])
    
     if length(size(handles.d.carbon_data_raw)) == 5                                    
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw,[1 5 2 4 3]);     
        handles.d.carbon_data_raw = squeeze(mean(handles.d.carbon_data_raw,5));         
    elseif length(size(handles.d.carbon_data_raw)) == 4                                 
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw,[1 4 2 3]);       
    elseif length(size(handles.d.carbon_data_raw)) == 3                                 
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw,[1 3 2]);         
    end                                                                                 
    
    % carbon_data_raw should now by a 3+D matrix indexed by:
    % (Samples in FID), (k-space dimension 1), (k-space dim 2), (timepoint)

    % some header info of potential use:
    params.dwell_time = handles.p.carbon_header.Config.DwellTime * 10^(-9); % dwell time in s
    handles.d.carbon_recon.hz = linspace(-0.5, 0.5, size(handles.d.carbon_data_raw,1)) .* 1/params.dwell_time;
    
    %For pH-calculation (2020.04.26, section added by Martin G.,)
    %interpolate the spectral axis by a the filling factor
    handles.d.carbon_recon.hz_padded = linspace(-0.5,0.5,(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) .* 1/params.dwell_time;
    handles.d.carbon_recon.hz_padded(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor) = handles.d.carbon_recon.hz_padded((size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) + (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
    %section end

    handles.p.carbon_recon_point_low = 1;
    handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,1);
    
    if (handles.p.carbon_load_figures_extra == 1)
        % show raw data...
        
        centre_x = ceil(size(handles.d.carbon_data_raw,2)/2 + 0.1); % index 5 for an 8x8 or 9x9 matrix
        centre_y = ceil(size(handles.d.carbon_data_raw,3)/2 + 0.1);
        num_pts = size(handles.d.carbon_data_raw,1);
        
        figure(823532)
        plot((1:num_pts)*dwell_time*1000, real(handles.d.carbon_data_raw(:,centre_x,centre_y,1)), ...
             (1:num_pts)*dwell_time*1000, imag(handles.d.carbon_data_raw(:,centre_x,centre_y,1)));
        title('Centre K-Space First FID')
        ylabel('Signal [AU] magnitude')
        xlabel('Sampling Time (ms)')
                
        if (size(handles.d.carbon_data_raw,4) > 1)
            figure(823584)
            plot(squeeze(mean(abs(handles.d.carbon_data_raw(:,centre_x,centre_y,:)),1)))
            title('Centre K-Space mean FID magnitude vs. frame')
            ylabel('Signal [AU] magnitude')
            xlabel('Frame Number')
        end
        
        figure(8254327)
        imagesc(squeeze(mean(mean(abs(handles.d.carbon_data_raw),4),1)));
        title('mean magnitude of FIDs (averaged over time)')
        axis image
        colorbar
        colormap jet
    end    
    
    
    % do FID / k-space to image recon
    params.read_fov = handles.p.carbon_header.Config.ReadFoV;
    params.phase_fov = handles.p.carbon_header.Config.PhaseFoV;
    params.zoom =       handles.p.carbon_recon_zoom;
    params.freq_fft =   handles.p.do_freq_fft;
    params.spat_fft =   handles.p.do_spatial_fft;
    params.spec_fillfactor =    handles.p.spec_fillfactor; %Added as spectral fillfactor (2020.04.26: Martin G.)
    handles.d.carbon_recon.image = siemens_kspace_fid_recon(handles.d.carbon_data_raw, params);
    if isfield(handles.p.carbon_header.MeasYaps.sSliceArray.asSlice{1}.sNormal,'dCor')
        handles.d.carbon_recon.image = rot90(handles.d.carbon_recon.image);
    end    
    handles.p.carbon_recon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
    
    % the following is common for all sequences
    disp(['Loading of carbon data finished. Size: ' num2str(size(handles.d.carbon_recon.image)) ...
          ' [X Y freqencies slices coils timesteps]']);

    disp(' ')
    disp(['centre frequency: ' num2str(handles.p.carbon_header.Config.Frequency) ' Hz'])
    disp(['nucleus: ' handles.p.carbon_header.Config.Nucleus])
    disp(['TR: ' num2str(handles.p.carbon_header.Config.TR / 1000) ' ms'])
    disp(['Coil: ' handles.p.carbon_header.Config.CoilElementID]) 
    disp(' ')
    
    % extract frequency axis
    if (isfield(handles.d.carbon_recon, 'hz_padded')) %2020.04.27, Martin G.: variable name modified accordingly
        handles.p.hz = handles.d.carbon_recon.hz_padded; %2020.04.27, Martin G.: Replaced by the more general term including the spectral filling factor
    else
        handles.p.hz = [];
    end
    handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;
    
    %---inserted section for adjusting FID window size after possible
    %zeropadding initially
    szimg = size(handles.d.carbon_recon.image);
    if handles.p.carbon_recon_point_high ~= szimg(3)
        handles.p.carbon_recon_point_high = szimg(3);
    end
    %---end inserted section
    
    
    if (exist('findpeaks')) %#ok<EXIST>
        % intialize display frequencies by summing over whole image
        % find overall image mean highest peak in spectrum
        spec_data = permute(abs(handles.d.carbon_recon.image), [1 2 4 5 6 3]);
        spec_data = squeeze(sum(sum(sum(sum(sum(spec_data,5),4),3),2),1));
        
        [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(spec_data, handles);
        handles.p.f1_val = handles.p.hz(pyr_idx);
        handles.p.f2_val = handles.p.hz(ala_idx);
        handles.p.f3_val = handles.p.hz(prh_idx);
        handles.p.f4_val = handles.p.hz(lac_idx);
        
        idxs = [pyr_idx ala_idx prh_idx lac_idx];
        biggest_idx = 1;
        for n = 1:length(idxs)
            if (spec_data(idxs(n)) > spec_data(biggest_idx))
                biggest_idx = idxs(n);
            end
        end
        handles.p.freq_val = handles.p.hz(biggest_idx);
    end
    

    % set the pointer to the center of the image
    if ~isprop(handles.p, 'pointer2d')
        handles.p.addprop('pointer2d');
    end
    handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
    handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
    
    handles.p.carbon_recon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
    handles.p.carbon_fov = [handles.p.carbon_header.Config.ReadFoV handles.p.carbon_header.Config.PhaseFoV];
 
        
    handles.p.slice_carbon_val          = 1;
    handles.p.coil_carbon_val           = 1;
    handles.p.timestep_val              = 1;

    % calculate time axis
    num_frames = max(1, size(handles.d.carbon_recon.image, 6));
    
    % determine how many k-space points were actually sampled, by counting
    % how many have nonzero values in them.
    % apparently there's no way to get this from the header?
    kspace_sum_over_time_samples = squeeze(sum(sum(abs(handles.d.carbon_data_raw),4),1));
    nonzero_kspace_points = kspace_sum_over_time_samples > 0;
    handles.p.nExcitationsPerTimestep = sum(sum(nonzero_kspace_points));
    
    
    % use number of sampled points and time per sampled point (TR) to get
    % the total frame TR
    total_frame_TR = handles.p.nExcitationsPerTimestep * handles.p.carbon_header.Config.TR / 1d6;
    handles.edit_repetitiontime.String  = num2str(total_frame_TR);
    
    % flip angle...
    handles.edit_flipangle.String       = num2str(handles.p.carbon_header.Dicom.adFlipAngleDegree);
    
    if ~isprop(handles.p, 'timeaxis')
        handles.p.addprop('timeaxis')
    end
    if total_frame_TR > 0
        handles.p.timeaxis = total_frame_TR * (1:num_frames);
    else
        handles.p.timeaxis = 1:num_frames;
        warning('time axis is labelled incorrectly, since TR is not defined. Shown are the number of steps, not the time in seconds.');
    end

    guidata(hObject,handles);
    plot4d_plot(handles)    
    
  
function ExtractBrukerHeaderInfo(imageObj, handles)
    % some header info of potential use:
    
    disp(' ')
    disp(['ACQ_method: ' imageObj.Acqp.ACQ_method])
    
    if isfield(imageObj.Method, 'PVM_Nucleus1Enum')
        disp(['nucleus: ' imageObj.Method.PVM_Nucleus1Enum])
    elseif isfield(imageObj.Acqp, 'NUCLEUS')
        disp(['nucleus: ' imageObj.Acqp.NUCLEUS])
    end
    
    if isfield(imageObj.Method, 'PVM_FrqRef')
        disp(['reference frequency: ' num2str(imageObj.Method.PVM_FrqRef(1)) ' MHz'])
        handles.p.reference_freq = imageObj.Method.PVM_FrqRef(1);
    end
    
    if isfield(imageObj.Method, 'PVM_FrqWorkPpm')
        disp(['working freq: ' num2str(imageObj.Method.PVM_FrqWorkPpm(1)) ' ppm'])
        handles.p.working_freq_ppm = imageObj.Method.PVM_FrqWorkPpm(1);
    else
        handles.p.working_freq_ppm = 0.0;
    end
    
    if isfield(imageObj.Method, 'PVM_RepetitionTime')
        disp(['TR: ' num2str(imageObj.Method.PVM_RepetitionTime) ' ms'])
        handles.p.carbon_header.tr = imageObj.Method.PVM_RepetitionTime;
    elseif isfield(imageObj.Acqp, 'ACQ_repetition_time')
        disp(['TR: ' num2str(imageObj.Acqp.ACQ_repetition_time) ' ms'])
        handles.p.carbon_header.tr = imageObj.Acqp.ACQ_repetition_time;
    else
        handles.p.carbon_header.tr = 1;
    end
    
    if isfield(imageObj.Method, 'PVM_SpecSWH')
        disp(['Spectral width: ' num2str(imageObj.Method.PVM_SpecSWH)])
        handles.p.carbon_header.specw = imageObj.Method.PVM_SpecSWH;
        
    elseif isfield(imageObj.Method, 'SpecBand')
        disp(['Spectral Bandwidth: ' num2str(imageObj.Method.SpecBand)])
        handles.p.carbon_header.specw = imageObj.Method.SpecBand;
        
    elseif (isfield(imageObj.Method, 'EchoSpacing') && imageObj.Method.EchoSpacing > 0 && ...
            (contains(imageObj.Method.Method, 'MGE', 'IgnoreCase', true)) ...
    )
        disp(['Multi Gradient-Echo spacing: ' num2str(imageObj.Method.EchoSpacing) ' ms'])
        handles.p.carbon_header.dwell_time = imageObj.Method.EchoSpacing / 1000;    % s -> workaround for later time that assumes dwell time is spacing between samples of spectrum
        handles.p.carbon_header.specw = 1000 / imageObj.Method.EchoSpacing;
        disp(['Spectral Bandwidth: ' num2str(handles.p.carbon_header.specw) ' Hz'])
        disp(['Using echo time as effective dwell time: ' num2str(handles.p.carbon_header.dwell_time) ' s'])
    end
        
    if isfield(imageObj.Method, 'PVM_SpecDwellTime')
        disp(['Dwell time: ' num2str(imageObj.Method.PVM_SpecDwellTime) ' us'])
        handles.p.carbon_header.dwell_time = imageObj.Method.PVM_SpecDwellTime * 10^(-6);
        
    elseif isfield(imageObj.Method, 'PVM_EpiGradDwellTime')
        disp(['Gradient Shape Dwell time: ' num2str(imageObj.Method.PVM_EpiGradDwellTime) ' us'])
        handles.p.carbon_header.dwell_time = imageObj.Method.PVM_EpiGradDwellTime * 10^(-6);
        
    elseif isfield(handles.p.carbon_header, 'dwell_time')
        
    else
        disp('Unable to estimate dwel time. Using 1 ms')
        handles.p.carbon_header.dwell_time = 0.001; % s
    end    
    
    
    if isfield(imageObj.Method, 'PVM_Fov')
        disp(['FOV: ' num2str(imageObj.Method.PVM_Fov)])
        if length(imageObj.Method.PVM_Fov) > 1
            handles.p.carbon_header.FOV = imageObj.Method.PVM_Fov;
        elseif length(imageObj.Method.PVM_Fov) == 1
            handles.p.carbon_header.FOV = [imageObj.Method.PVM_Fov imageObj.Method.PVM_Fov];
        else
            handles.p.carbon_header.FOV = [2 2];
        end
        handles.p.carbon_fov = handles.p.carbon_header.FOV;
        
    elseif isfield(imageObj.Acqp, 'ACQ_fov')
        disp(['FOV: ' num2str(imageObj.Acqp.ACQ_fov * 10)])
        if length(imageObj.Acqp.ACQ_fov) > 2
            handles.p.carbon_header.FOV = imageObj.Acqp.ACQ_fov(2:3) * 10;
        elseif length(imageObj.Acqp.ACQ_fov) == 2
            handles.p.carbon_header.FOV = imageObj.Acqp.ACQ_fov * 10;
        elseif length(imageObj.Acqp.ACQ_fov) == 1
            handles.p.carbon_header.FOV = [imageObj.Acqp.ACQ_fov imageObj.Acqp.ACQ_fov] * 10;
        else
            handles.p.carbon_header.FOV = [1 1];
        end
        if (length(handles.p.carbon_header.FOV) > 2)
            handles.p.carbon_fov = handles.p.carbon_header.FOV(2:3);
        else
            handles.p.carbon_fov = handles.p.carbon_header.FOV;
        end
    end
    
    if isfield(imageObj.Acqp, 'ACQ_flip_angle')
        disp(['Flip Angle: ' num2str(imageObj.Acqp.ACQ_flip_angle)])
        handles.edit_flipangle.String = num2str(imageObj.Acqp.ACQ_flip_angle);
    end
    
    disp(['Slice Orientation: ' handles.p.carbon_header.sliceOrient])
    disp(['Read Orientation: ' handles.p.carbon_header.readOrient])
    disp(['Receivers: ' num2str(imageObj.Method.PVM_EncNReceivers)])
    
    disp(' ')    
    
    
function excitations = GetBrukerNumExcitationsPerTimeStep(handles, imageObj)
    % determine how many excitations per timestep for various acquisition methods
    
    if (strcmp(imageObj.Method.Method, '<Bruker:SINGLEPULSE>') || ...
        strcmp(imageObj.Method.Method, '<User:geoffSINGLEPULSE>') || ...
        strcmp(imageObj.Method.Method, '<Bruker:PRESS>') || ...
        strcmp(imageObj.Method.Method, '<User:geoffTestCSI_10>') || ...
        strcmp(imageObj.Method.Method, '<User:geoffTestCSI_11>') || ...
        strcmp(imageObj.Method.Method, '<User:geoffSinPulMulFrq_6>') || ...
        strcmp(imageObj.Method.Method, '<User:geoffSinPulMulFrq_7>') || ...
        strcmp(imageObj.Method.Method, '<Bruker:CPMG>') || ...
        strcmp(imageObj.Method.Method, '<User:gCPMG>') ...
    )
    
        excitations = imageObj.Method.PVM_NAverages;
        
    elseif (strcmp(imageObj.Method.Method, '<Bruker:EPSI>') || strcmp(imageObj.Method.Method, '<User:epsi_combined_1>'))
        data_sz = size(handles.d.carbon_recon.image);
        avgs = imageObj.Method.PVM_NAverages;
        shots = imageObj.Method.PVM_EpiNShots;
        phase_encodes = data_sz(1);
        slices = 1;
        if (length(data_sz) >= 4)
            slices = data_sz(4);
        end
        
        excitations = avgs * shots * phase_encodes * slices;
        
       
    elseif (strcmp(imageObj.Method.Method, '<Bruker:CSI>') || ...
            strcmp(imageObj.Method.Method, '<User:csi_multislice_1>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffCSI>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffCSI_MulFrq_1>'))
        
        excitations = imageObj.Method.AverageListSum;
        
    else
        excitations = 1;
    end

    
function carbon_load_bruker_2dseq(hObject,handles)
    carbon_load_common(handles)
    handles.d.carbon_recon = [];
    
    handles.p.apply_checkerboard_phase = 0;
    
    params.lb = handles.p.carbon_line_broadening;
    params.xshift = handles.p.carbon_shift_x;
    params.yshift = handles.p.carbon_shift_y;
    
    
    % load and reconstruct carbon data
    if ~isprop(handles.p, 'carbon_header')
        handles.p.addprop('carbon_header');
    end
    
    imageObj = ImageDataObject(handles.p.carbon_file);
    imageObj = imageObj.readAcqp;
    imageObj = imageObj.readMethod;
    handles.p.carbon_header = imageObj.Acqp;
    handles.p.carbon_header.method = imageObj.Method.Method;
    if (isfield(imageObj.Method, 'PVM_SPackArrSliceOrient'))
        handles.p.carbon_header.sliceOrient = imageObj.Method.PVM_SPackArrSliceOrient(1,:);
    else
        handles.p.carbon_header.sliceOrient = '';
    end
    if (isfield(imageObj.Method, 'PVM_SPackArrReadOrient'))
        handles.p.carbon_header.readOrient = imageObj.Method.PVM_SPackArrReadOrient(1,:);
    else
        handles.p.carbon_header.readOrient = '';
    end    
    
    handles.p.carbon_header.loaded_data_from = '2dseq'; % determine how to do recon later
    
    % load and reconstruct carbon data
    handles.d.carbon_data_raw = imageObj.data;
    
    % swap dimension order for EPSI since it is inconsistent with other
    % encoding orders in 2dseq
    if (contains(imageObj.Method.Method, 'EPSI', 'IgnoreCase', true))
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [2 1 3 4 5 6]);
    end
        
    % carbon_data_raw should now by a 3+D matrix indexed by:
    % (Samples in FID), (k-space dimension 1), (k-space dim 2), (k-space dim 3 / slice), (timepoint)
    
    % want data in form [samples KSD1 KSD2 slices coils timesteps]
    handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [1 2 3 4 6 5]);
    
    
    ExtractBrukerHeaderInfo(imageObj, handles);
    
    
    if (contains(imageObj.Method.Method, 'MGE', 'IgnoreCase', true))
        error('Load fid for multi-gradient-echo data')
    
    elseif (contains(imageObj.Method.Method, 'CEST', 'IgnoreCase', true))
        handles.p.working_freq_ppm = 0.0;   % force spectrum centre to 0 ppm
        % easier that updating all the click freq to ppm conversion stuff
        % later that would need to know whether to use the central or the
        % working ppm as 0. For CEST, 0 should be the working freq centre.
        
        disp(['Saturation offset frequencies: ' num2str(imageObj.Acqp.ACQ_O2_list)])
        handles.d.carbon_recon.hz = imageObj.Acqp.ACQ_O2_list;
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [1 2 6 3 4 5]);
        handles.d.carbon_data_raw = flip(handles.d.carbon_data_raw,2);
        
        % sort offset frequencies
        % use indices to reorder images in frequency axis to match
        [handles.d.carbon_recon.hz, sorted_indices] = sort(handles.d.carbon_recon.hz);
        handles.d.carbon_data_raw = handles.d.carbon_data_raw(:,:,sorted_indices,:,:,:);
        
    elseif (contains(imageObj.Method.Method, 'FLASH', 'IgnoreCase', true))
        handles.d.carbon_recon.hz = 0;
        
        
    elseif (contains(imageObj.Method.Method, 'jgs', 'IgnoreCase', true) && ...
            contains(imageObj.Method.Method, 'FISP', 'IgnoreCase', true))
        
        handles.d.carbon_recon.hz = imageObj.Method.SatFreqList;
        disp(['Using JGS FISP sat freq list: ' num2str(handles.d.carbon_recon.hz)])


        % reshape and reorder dimensions for compatibility with standard
        % recon code
        
        
        % dimension 6 is a mix of repetitions and frequency cycles
        num_freqs = length(handles.d.carbon_recon.hz);
        
        % separate freqs from reps
        sz = size(handles.d.carbon_data_raw);
        if (length(sz) < 6)
            sz_temp = sz;
            sz = [1 1 1 1 1 1];
            sz(1:length(sz_temp)) = sz_temp;
        end
        
        % if number of reps doesn't divide evenly by number of freqs, need
        % to padd reps with zero-value images
        if (floor(sz(6) / num_freqs) ~= sz(6) / num_freqs)
            error(['Have ' num2str(sz(6)) ' repetitions and ' num2str(num_freqs) ' frequencies... TODO: pad with zeroes']);
        end
        
        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, [sz(1:5) num_freqs floor(sz(6)/num_freqs)]);

        % reorder dimensions from:
        % space / space / space / coil = singleton / singleton / freqs / time
        % to:
        % freq  / space / space / space / coil = singleton / time
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [6 1 2 3 4 7 5]);
        
        
    elseif (contains(imageObj.Method.Method, 'VarFreq', 'IgnoreCase', true) && ...
            contains(imageObj.Method.Method, 'BSSFP', 'IgnoreCase', true))
        
        error('Still need to implement loading Geoffs version of variable freq bSSFP...');
        
        
    elseif (contains(imageObj.Method.Method, 'CSI', 'IgnoreCase', true))
        % CSI scanner recons have opposite frequency order from what the
        % rest of this tool expects...
        handles.d.carbon_data_raw = flip(handles.d.carbon_data_raw, 1);
        
    else
        handles.d.carbon_recon.hz = linspace(-0.5, 0.5, size(handles.d.carbon_data_raw,1)) .* handles.p.carbon_header.specw;
    end

    handles.p.carbon_recon_point_low = 1;
    handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,1);
    
    if (handles.p.carbon_load_figures_extra)
        % show raw data...
        
        centre_x = ceil(size(handles.d.carbon_data_raw,2)/2 + 0.1); % index 5 for an 8x8 or 9x9 matrix
        centre_y = ceil(size(handles.d.carbon_data_raw,3)/2 + 0.1);
%         num_pts = size(handles.d.carbon_data_raw,1);
        
        figure(823532)
        xaxisvals = handles.d.carbon_recon.hz;
        plot(xaxisvals, (handles.d.carbon_data_raw(:,centre_x,centre_y,1)), ...
             xaxisvals, imag(handles.d.carbon_data_raw(:,centre_x,centre_y,1)));
        title('Centre K-Space Spectrum')
        ylabel('Signal [AU] magnitude')
        xlabel('Frequency Axis [Hz]')
                
        if (size(handles.d.carbon_data_raw,6) > 1)
            figure(823584)
            
            compressed_data = abs(handles.d.carbon_data_raw(:,centre_x,centre_y,:,:));
            compressed_data = mean(compressed_data,4);
            compressed_data = mean(compressed_data,1);
            
            plot(squeeze(compressed_data))
            title('Centre K-Space mean Spectral magnitude vs. frame')
            ylabel('Signal [AU] magnitude')
            xlabel('Frame Number')
        end
        
    end    
    
    
    % do FID / k-space to image recon
    params.read_fov = handles.p.carbon_fov(1);
    if isfield(handles.p, 'carbon_fov') && (length(heandles.p.carbon_fov) > 1)
        params.phase_fov = handles.p.carbon_fov(2);
    else
        params.phase_fov = params.read_fov;
    end        
    params.method = handles.p.carbon_header.ACQ_method;
    params.readOrient = '';
    if (isfield(handles.p.carbon_header, 'readOrient'))
        params.readOrient = handles.p.carbon_header.readOrient;
    end
    params.zoom =       handles.p.carbon_recon_zoom;
    params.freq_fft =   handles.p.do_freq_fft;
    params.spat_fft =   handles.p.do_spatial_fft;    
    
    if (contains(imageObj.Method.Method, 'CEST', 'IgnoreCase', true))
        handles.d.carbon_recon.image = handles.d.carbon_data_raw;
        
    else
        handles.d.carbon_recon.image = bruker_kspace_2dseq_recon(handles.d.carbon_data_raw, params);
    end
    handles.p.carbon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
    handles.p.carbon_recon_resolution = handles.p.carbon_resolution;
    
    % the following is common for all sequences
    disp(['Loading of carbon data finished. Size: ' num2str(size(handles.d.carbon_recon.image)) ...
          ' [X Y freqencies slices coils timesteps]']);

    
    % extract frequency axis
    if (isfield(handles.d.carbon_recon, 'hz'))
        handles.p.hz = handles.d.carbon_recon.hz;
    else
        handles.p.hz = [];
    end
    handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;
    
    
    if (exist('findpeaks') && length(handles.p.hz) > 10) %#ok<EXIST>
        % intialize display frequencies by summing over whole image
        % find overall image mean highest peak in spectrum
        spec_data = permute(abs(handles.d.carbon_data_raw), [2 3 4 5 6 1]);
        spec_data = squeeze(sum(sum(sum(sum(sum(spec_data,5),4),3),2),1));
        
        [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(spec_data, handles);
        handles.p.f1_val = handles.p.hz(pyr_idx);
        handles.p.f2_val = handles.p.hz(ala_idx);
        handles.p.f3_val = handles.p.hz(prh_idx);
        handles.p.f4_val = handles.p.hz(lac_idx);
        
        idxs = [pyr_idx ala_idx prh_idx lac_idx];
        biggest_idx = 1;
        for n = 1:length(idxs)
            if (spec_data(idxs(n)) > spec_data(biggest_idx))
                biggest_idx = idxs(n);
            end
        end
        handles.p.freq_val = handles.p.hz(biggest_idx);
    end
    

    % set the pointer to the center of the image
    if ~isprop(handles.p, 'pointer2d')
        handles.p.addprop('pointer2d');
    end
    handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
    handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
    
%     handles.p.carbon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
        
    handles.p.slice_carbon_val          = 1;
    handles.p.coil_carbon_val           = 1;
    handles.p.timestep_val              = 1;

    % calculate time axis
    num_frames = max(1, size(handles.d.carbon_recon.image, 6));
    
    
    handles.p.nExcitationsPerTimestep = GetBrukerNumExcitationsPerTimeStep(handles, imageObj);
    
    
    % use number of sampled points and time per sampled point (TR) to get
    % the total frame TR
    total_frame_TR = handles.p.nExcitationsPerTimestep(1) * handles.p.carbon_header.tr(1) / 1000;
    handles.edit_repetitiontime.String = num2str(total_frame_TR);
    
    if ~isprop(handles.p, 'timeaxis')
        handles.p.addprop('timeaxis')
    end
    if total_frame_TR > 0
        handles.p.timeaxis = total_frame_TR * (1:num_frames);
    else
        handles.p.timeaxis = 1:num_frames;
        warning('time axis is labelled incorrectly, since TR is not defined. Shown are the number of steps, not the time in seconds.');
    end

    guidata(hObject,handles);
    plot4d_plot(handles)    
    
    
function carbon_load_bruker_fid(hObject,handles)
    carbon_load_common(handles)
    handles.d.carbon_recon = [];
    
    handles.p.apply_checkerboard_phase = 0;
    
    params.lb = handles.p.carbon_line_broadening;
    params.xshift = handles.p.carbon_shift_x;
    params.yshift = handles.p.carbon_shift_y;
    
    % load and reconstruct carbon data
    [dirname,~,~] = fileparts(handles.p.carbon_file);
    
    imageObj = RawDataObject(dirname, 'specified_Jobs', -1);
    imageObj = imageObj.readAcqp;
    imageObj = imageObj.readMethod;
    handles.p.carbon_header = imageObj.Acqp;
    handles.p.carbon_header.method = imageObj.Method.Method;
    if (isfield(imageObj.Method, 'PVM_SPackArrSliceOrient'))
        handles.p.carbon_header.sliceOrient = imageObj.Method.PVM_SPackArrSliceOrient(1,:);
    else
        handles.p.carbon_header.sliceOrient = '';
    end
    if (isfield(imageObj.Method, 'PVM_SPackArrReadOrient'))
        handles.p.carbon_header.readOrient = imageObj.Method.PVM_SPackArrReadOrient(1,:);
    else
        handles.p.carbon_header.readOrient = '';
    end
    
    handles.p.carbon_header.loaded_data_from = 'fid'; % determine how to do recon later
    
    % load and reconstruct carbon data
    handles.d.carbon_data_raw = cell2mat(imageObj.data);
    
    dwell_time_scale_factor = 1; % may be overwritten later
    disp(['Bruker FID Acquired with Method: ' imageObj.Method.Method])
    if ((contains(imageObj.Method.Method, 'SINGLEPULSE', 'IgnoreCase', true)) || ...
        (contains(imageObj.Method.Method, 'SinPulMulFrq', 'IgnoreCase', true)) || ...
        (contains(imageObj.Method.Method, 'PRESS', 'IgnoreCase', true)) || ...
        (contains(imageObj.Method.Method, 'RfProfile', 'IgnoreCase', true)) || ...
        (contains(imageObj.Method.Method, 'STEAM', 'IgnoreCase', true))...
    )
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [2 1 3]);
        fidsz = size(handles.d.carbon_data_raw, 1);
        tsz = size(handles.d.carbon_data_raw, 3);
        xsz = 1;
        ysz = 1;
        coilsz = 1;
        
        if (contains(imageObj.Method.Method, 'SINGLEPULSE', 'IgnoreCase', true) || ...
            contains(imageObj.Method.Method, 'SinPulMulFrq', 'IgnoreCase', true) ...
        )
            coilsz = imageObj.Method.PVM_EncNReceivers;
        end
        
        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, [fidsz, 1, 1, 1, tsz, coilsz]);
        
        if (contains(imageObj.Method.Method, 'RfProfile', 'IgnoreCase', true))
            handles.p.carbon_header.specw = imageObj.Acqp.SW_h;
        end
        
    elseif (contains(imageObj.Method.Method, 'CPMG', 'IgnoreCase', true))
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [2 1 3]);
        fidsz = size(handles.d.carbon_data_raw, 1);
        tsz = size(handles.d.carbon_data_raw, 3);
        xsz = 1;
        ysz = 1;
        coilsz = 1;%imageObj.Method.PVM_EncNReceivers; already merged in fid file
        
        % data now ordered as (fid samples) (singleton) (echoes)
        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, [fidsz, 1, 1, 1, tsz, coilsz]);
        % data now ordered as (fid samples) (singleton) (singleton) (singleton) (echoes)
        
    elseif (contains(imageObj.Method.Method, 'CSI', 'IgnoreCase', true))
        xsz = handles.p.carbon_header.ACQ_size(2);
        ysz = handles.p.carbon_header.ACQ_size(3);
        if (length(handles.p.carbon_header.ACQ_size) >= 4)
            zsz = handles.p.carbon_header.ACQ_size(4);
        else
            zsz = 1;
        end
        
        if (contains(imageObj.Method.Method, 'MS', 'IgnoreCase', true) || ...
            contains(imageObj.Method.Method, 'multislice', 'IgnoreCase', true) ...
        )            
            % todo: maybe need to handle if each slice pack has multiple
            % slices?
            zsz = imageObj.Acqp.NSLICES;
        end
        
        tsz = handles.p.carbon_header.NR;
        fidsz = size(handles.d.carbon_data_raw, 2);
        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, fidsz, xsz, ysz, zsz, tsz, []);
    
    elseif (contains(imageObj.Method.Method, 'MGE', 'IgnoreCase', true))
        xsz = imageObj.Method.PVM_Matrix(1);
        ysz = imageObj.Method.PVM_Matrix(2);
        zsz = 1;
        
        if (length(handles.p.carbon_header.ACQ_size) >= 3)
            zsz = handles.p.carbon_header.ACQ_size(3);
        else
            % assuming either multiple phase encodes in slice direction, or
            % multiple slices, not both
            zsz = sum(imageObj.Method.PVM_SPackArrNSlices);
            if (length(zsz) > 1)
                zsz = sum(zsz);
            end
        end
        
        fidsz = imageObj.Method.PVM_NEchoImages;
        tsz = imageObj.Method.PVM_NRepetitions;
        
        disp(['MGE expected data size: ' num2str([xsz ysz fidsz zsz tsz]) '  [X Y freqencies slices timesteps]'])
        disp(['MGE raw data size: ' num2str(size(handles.d.carbon_data_raw))])
        
        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, [xsz fidsz zsz ysz tsz]);
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [2 1 4 3 5]);
        % after permuting, should be ordered fid, x, y, z t
        disp(['Data size after permuting: ' num2str(size(handles.d.carbon_data_raw))])

        if (length(imageObj.Method.PVM_EncOrder) >= 1) && ...
            strcmp(imageObj.Method.PVM_EncOrder{1}, 'CENTRIC_ENC')

            % need to reorder data to account for centric encoding in
            % demension 2

            % for 20-sized matrix:
            % PVM_EncSteps0: [0 -1 1 -2 2 -3 3 -4 4 -5 5 -6 6 -7 7 -8 8 -9 9 -10]
            % indices should be which index in the k-space matrix at which
            % each line of the raw data should be stored to unwrap
            % centric encoding
            indices = imageObj.Method.PVM_EncSteps0 + ceil(xsz/2.0) + 1;
            handles.d.carbon_data_raw(:, indices, :, :, :, :, :, :) = handles.d.carbon_data_raw;
%                 figure(6); imagesc(squeeze(max(abs(handles.d.carbon_data_raw)))); axis image;
        end
        if (length(imageObj.Method.PVM_EncOrder) >= 2) && ...
            strcmp(imageObj.Method.PVM_EncOrder{2}, 'CENTRIC_ENC')
            % need to reorder data to account for centric encoding in
            % demension 3

            indices = imageObj.Method.PVM_EncSteps1 + ceil(ysz/2.0) + 1;
            handles.d.carbon_data_raw(:, :, indices, :, :, :, :, :) = handles.d.carbon_data_raw;
        end          
        
    elseif (contains(imageObj.Method.Method, 'EPSI', 'IgnoreCase', true))
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [2 3 1]);
        
        if (handles.p.carbon_header.ACQ_size(3) ~= imageObj.Method.PVM_Matrix(2))
            error('inconsistent Y matrix and ACQ sizes...?')
        end
        ysz = imageObj.Method.PVM_Matrix(2);
        xsz = imageObj.Method.PVM_Matrix(1);
        zsz = imageObj.Method.PVM_SPackArrNSlices(1);
        tsz = handles.p.carbon_header.NR;
        fidsz = size(handles.d.carbon_data_raw, 1);
        per_line_fidsz = fidsz / xsz; % how many readout points per k-space line

        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, [xsz per_line_fidsz ysz zsz tsz]);
        handles.d.carbon_data_raw = permute(handles.d.carbon_data_raw, [2 1 3 4 5]);
        
        
        if (handles.p.carbon_load_figures_extra == 1 && strcmp(imageObj.Method.Method, '<Bruker:EPSI>'))
            % plot even and odd echo images
            figure(8254328)

            subplot(1,2,1)                
            compressed_data_odd = abs(handles.d.carbon_data_raw(1:2:9,:,:,:,:));
            compressed_data_odd = mean(mean(mean(compressed_data_odd,5),4),1);
            imagesc(squeeze(compressed_data_odd));
            title('Mean Magnitude of Odd Echoes (Averaged Over Time)')
            axis image
            colorbar
            colormap jet

            subplot(1,2,2)
            compressed_data_even = abs(handles.d.carbon_data_raw(2:2:10,:,:,:,:));
            compressed_data_even = mean(mean(mean(compressed_data_even,5),4),1);
            imagesc(squeeze(compressed_data_even));
            title('Mean Magnitude of Even Echoes (Averaged Over Time)')
            axis image
            colorbar
            colormap jet
            
            
            % plot even and odd echo central lines together
            figure(253115)
            compressed_data_odd = sum(abs(handles.d.carbon_data_raw([1 3 5 7 9],:,ceil(end/2),1,1)),1);
            compressed_data_even = sum(abs(handles.d.carbon_data_raw([2 4 6 8 10],:,ceil(end/2),1,1)),1);
            title('Initial odd/even EPSI echoes magnitude')
            
            plot(1:length(compressed_data_odd),  compressed_data_odd, ...
                 1:length(compressed_data_even), compressed_data_even);
            legend('odd first echoes magnitude', 'even first echoes magnitude');
        end
        
        % flip even echoes due to reversed gradient readout direction
        even_echoes = handles.d.carbon_data_raw(2:2:end,:,:,:,:);
%         even_echoes = flip(even_echoes,2);
        handles.d.carbon_data_raw(2:2:end,:,:,:,:) = even_echoes;
        
%         alternate recon: half bandwidth, just use odd echoes
        odd_echoes = handles.d.carbon_data_raw(1:2:end,:,:,:,:);
        handles.d.carbon_data_raw = odd_echoes;
        dwell_time_scale_factor = 2;

        
    elseif (strcmp(imageObj.Method.Method, '<User:unito_cestRARE>'))
        error('Load the 2dseq file for CEST data...');
        
    elseif (contains(imageObj.Method.Method, 'jgs', 'IgnoreCase', true) && ...
            contains(imageObj.Method.Method, 'FISP', 'IgnoreCase', true))
        
        error('Load 2dseq for JGS FISP data')    
        
    else
        error('Unrecognized Bruker Method! Dont know how to process FID data...')
    end
    
    
    % carbon_data_raw should now by a 3+D matrix indexed by:
    % (Samples in FID), (spatial dim 1), (spatial dim 2), (spatial dim 3), (timepoint), (coils)
    handles.p.carbon_resolution = [xsz ysz];
    
    ExtractBrukerHeaderInfo(imageObj, handles);

    
    
    handles.d.carbon_recon.hz = linspace(-0.5, 0.5, size(handles.d.carbon_data_raw,1)) .* handles.p.carbon_header.specw / dwell_time_scale_factor;
    
    %For pH-calculation (2020.04.08, section added by Martin G.,)
    %interpolate the spectral axis by a the filling factor
    handles.d.carbon_recon.hz_padded = linspace(-0.5,0.5,(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) .* handles.p.carbon_header.specw / dwell_time_scale_factor;
    handles.d.carbon_recon.hz_padded(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor) = handles.d.carbon_recon.hz_padded((size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) + (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
    %section end
    
    handles.p.carbon_recon_point_low = 1;
    handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,1);
    
    if (handles.p.carbon_load_figures_extra == 1)
        % show raw data...
        
        centre_x = ceil(size(handles.d.carbon_data_raw,2)/2 + 0.1); % index 5 for an 8x8 or 9x9 matrix
        centre_y = ceil(size(handles.d.carbon_data_raw,3)/2 + 0.1);
        num_pts = size(handles.d.carbon_data_raw,1);
        disp(['Centre kspace coords: ' num2str([centre_x centre_y])])

        peak_frame_idx = 1; % may be modified...
        
        if (size(handles.d.carbon_data_raw,5) > 1)
            figure(823584)
            
            compressed_data = abs(handles.d.carbon_data_raw(:,centre_x,centre_y,:,:));
            compressed_data = mean(compressed_data,4);
            compressed_data = mean(compressed_data,1);
            
            plot(squeeze(compressed_data))
            title('Centre K-Space Mean FID Magnitude vs. Frame')
            ylabel('Signal [AU] magnitude')
            xlabel('Frame Number')
            
            if (strcmp(imageObj.Method.Method, '<Bruker:EPSI>'))
                title('Centre K-Space Mean Echo Magnitude vs. Frame')
            end
            
            [~, peak_frame_idx] = max(compressed_data);
        end
        
        if isfield(imageObj.Method, 'PVM_SpecAcquisitionTime')
            acquisition_time = imageObj.Method.PVM_SpecAcquisitionTime;
        else
            acquisition_time = handles.p.carbon_header.dwell_time * 1000 * dwell_time_scale_factor * 2;
        end
        
        
        figure(823532)
        xaxisvals = (1:num_pts) * acquisition_time / num_pts;
        plot(xaxisvals, real(handles.d.carbon_data_raw(:,centre_x,centre_y,peak_frame_idx)), ...
             xaxisvals, imag(handles.d.carbon_data_raw(:,centre_x,centre_y,peak_frame_idx)));
        title('Centre K-Space Peak FID')
        ylabel('Signal [AU] magnitude')
        xlabel('Sampling Time (ms)')
        if (strcmp(imageObj.Method.Method, '<Bruker:EPSI>'))
            title('Centre K-Space Peak-Time Gradient-Echo Train')
        end        
        
        if (size(handles.d.carbon_data_raw,2) > 1 || size(handles.d.carbon_data_raw,3) > 1)
            figure(8254327)
        
            compressed_data = abs(handles.d.carbon_data_raw);
            compressed_data = mean(mean(mean(compressed_data,5),4),1);
        
            imagesc(squeeze(compressed_data));
            title('Mean Magnitude of FIDs (Averaged Over Time)')
            axis image
            colorbar
            colormap jet
        end
    end
    

    % do FID / k-space to image recon
    params.dwell_time =         handles.p.carbon_header.dwell_time;
    params.read_fov =           handles.p.carbon_fov(1);
    params.phase_fov =          handles.p.carbon_fov(2);
    params.method =             handles.p.carbon_header.ACQ_method;
    params.readOrient =         handles.p.carbon_header.readOrient;
    params.sliceOrient=         handles.p.carbon_header.sliceOrient;
    params.zoom =               handles.p.carbon_recon_zoom;
    params.freq_fft =           handles.p.do_freq_fft;
    params.spat_fft =           handles.p.do_spatial_fft;
    params.spec_fillfactor =    handles.p.spec_fillfactor; %Added as spectral fillfactor (2020.04.09: Martin G.)
    
    handles.d.carbon_recon.image = bruker_kspace_fid_recon(handles.d.carbon_data_raw, params);
    handles.p.carbon_recon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
    
    
    % the following is common for all sequences
    disp(['Loading of carbon data finished. Size: ' num2str(size(handles.d.carbon_recon.image)) ...
          ' [X Y freqencies slices coils timesteps]']);

    
    % extract frequency axis
    if (isfield(handles.d.carbon_recon, 'hz_padded')) %2020.04.09, Martin G.: variable name modified accordingly
        %handles.p.hz = handles.d.carbon_recon.hz;
        handles.p.hz = handles.d.carbon_recon.hz_padded; %2020.04.09, Martin G.: Replaced by the more general term including the spectral filling factor
    else
        handles.p.hz = [];
    end
    handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;
    
    %---inserted section for adjusting FID window size after possible
    %zeropadding initially
    szimg = size(handles.d.carbon_recon.image);
    if handles.p.carbon_recon_point_high ~= szimg(3)
        handles.p.carbon_recon_point_high = szimg(3);
    end
    %---end inserted section
    
    if (exist('findpeaks')) %#ok<EXIST>
        % intialize display frequencies by summing over whole image
        % find overall image mean highest peak in spectrum
        spec_data = permute(abs(handles.d.carbon_recon.image), [1 2 4 5 6 3]);
        spec_data = squeeze(sum(sum(sum(sum(sum(spec_data,5),4),3),2),1));
        
        [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(spec_data, handles);
        handles.p.f1_val = handles.p.hz(pyr_idx);
        handles.p.f2_val = handles.p.hz(ala_idx);
        handles.p.f3_val = handles.p.hz(prh_idx);
        handles.p.f4_val = handles.p.hz(lac_idx);
        
        idxs = [pyr_idx ala_idx prh_idx lac_idx];
        biggest_idx = 1;
        for n = 1:length(idxs)
            if (spec_data(idxs(n)) > spec_data(biggest_idx))
                biggest_idx = idxs(n);
            end
        end
        handles.p.freq_val = handles.p.hz(biggest_idx);
    end
    

    % set the pointer to the center of the image
    if ~isprop(handles.p, 'pointer2d')
        handles.p.addprop('pointer2d');
    end
    handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
    handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
    
    
    handles.p.slice_carbon_val = 1;
    handles.p.coil_carbon_val = 1;
    handles.p.timestep_val = 1;

    
    % use number of sampled points and time per sampled point (TR) to get
    % the total frame TR
    handles.p.nExcitationsPerTimestep = GetBrukerNumExcitationsPerTimeStep(handles, imageObj);
    total_frame_TR = handles.p.nExcitationsPerTimestep(1) * handles.p.carbon_header.tr / 1000;
    handles.edit_repetitiontime.String = num2str(total_frame_TR);
    
    
    if (strcmp(imageObj.Method.Method, '<Bruker:CPMG>') || strcmp(imageObj.Method.Method, '<User:gCPMG>'))
        % special case for CPMG: use echo times for time axis
        handles.p.timeaxis = imageObj.Acqp.ACQ_echo_time / 1000;
        
    else
        num_frames = max(1, size(handles.d.carbon_recon.image, 6));
        if total_frame_TR > 0
            handles.p.timeaxis = total_frame_TR * (1:num_frames);
        else
            handles.p.timeaxis = 1:num_frames;
            warning('time axis is labelled incorrectly, since TR is not defined. Shown are the number of steps, not the time in seconds.');
        end
    end

    guidata(hObject,handles);
    plot4d_plot(handles)    
 

function carbon_load_bruker_job(hObject,handles)
    carbon_load_common(handles)
    handles.d.carbon_recon = [];
    
    handles.p.apply_checkerboard_phase = 0;
    
    params.lb = handles.p.carbon_line_broadening;
    params.xshift = handles.p.carbon_shift_x;
    params.yshift = handles.p.carbon_shift_y;
    
    % load and reconstruct carbon data
    if ~isprop(handles.p, 'carbon_header')
        handles.p.addprop('carbon_header');
    end
    
    [dirname,~,~] = fileparts(handles.p.carbon_file);
    
    imageObj = RawDataObject(dirname);
    imageObj = imageObj.readAcqp;
    imageObj = imageObj.readMethod;
    
    if (isfield(imageObj.Method, 'AverageMode') && isfield(imageObj.Method, 'PVM_NAverages'))
        if (strcmp(imageObj.Method.AverageMode, 'Weighted_av') == 1 && ...
            imageObj.Method.PVM_NAverages > 1)
            error('Cant process weighted average job files')
        end
    end
    
    handles.p.carbon_header = imageObj.Acqp;
    handles.p.carbon_header.method = imageObj.Method.Method;
    if (isfield(imageObj.Method, 'PVM_SPackArrSliceOrient'))
        handles.p.carbon_header.sliceOrient = imageObj.Method.PVM_SPackArrSliceOrient(1,:);
    else
        handles.p.carbon_header.sliceOrient = '';
    end
    if (isfield(imageObj.Method, 'PVM_SPackArrReadOrient'))
        handles.p.carbon_header.readOrient = imageObj.Method.PVM_SPackArrReadOrient(1,:);
    else
        handles.p.carbon_header.readOrient = '';
    end
    
    handles.p.carbon_header.loaded_data_from = 'job'; % determine how to do recon later
    
    % load and reconstruct carbon data
    handles.d.carbon_data_raw = cell2mat(imageObj.data);

    disp(['Bruker FID Acquired with Method: ' imageObj.Method.Method])
    
    % (contains(imageObj.Method.Method, 'MGE', 'IgnoreCase', true))
    if (contains(imageObj.Method.Method, 'SINGLEPULSE', 'IgnoreCase', true) || ...
        contains(imageObj.Method.Method, 'PRESS', 'IgnoreCase', true) || ...
        contains(imageObj.Method.Method, 'EPSI', 'IgnoreCase', true) ...
    )
        error(['unexpected method for job files: ' imageObj.Method.Method])
        
        % Geoff: My test scans didn't have job files with these scan
        % methods, so I have not implemented anything to load them
        
    elseif (contains(imageObj.Method.Method, 'CSI', 'IgnoreCase', true) || ...
            contains(imageObj.Method.Method, 'SlcSpec', 'IgnoreCase', true) ...
    )
        % if using weighted averaging, need something more complicated
        
        xsz = handles.p.carbon_header.ACQ_size(2);
        if (strcmp(imageObj.Method.Method, '<User:geoffTestCSI_10>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffTestCSI_11>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffSlcSpec_12>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffSlcSpecFC>'))
            xsz = 1;
        end
        
        if (length(handles.p.carbon_header.ACQ_size) >= 3)
            ysz = handles.p.carbon_header.ACQ_size(3);
        else
            ysz = 1;
        end
        
        if (length(handles.p.carbon_header.ACQ_size) >= 4)
            zsz = handles.p.carbon_header.ACQ_size(4);
        else
            zsz = 1;
        end
        tsz = handles.p.carbon_header.NR;
        fidsz = size(handles.d.carbon_data_raw, 2);
        asz = 1;    % num averages
        csz = 1;    % num channels
        
        
        if (strcmp(imageObj.Method.Method, '<User:geoffSlcSpec_12>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffSlcSpecFC>') || ...
            strcmp(imageObj.Method.Method, '<Bruker:CSI>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffCSI>'))
            
            % assuming either multiple phase encodes in slice direction, or
            % multiple slices, not both
            if (length(imageObj.Method.PVM_SPackArrNSlices) > 1)
                zsz = sum(imageObj.Method.PVM_SPackArrNSlices);
                if (length(zsz) > 1)
                    zsz = sum(zsz);
                end
            end
            tsz = imageObj.Method.PVM_NRepetitions;
            asz = imageObj.Method.PVM_NAverages;
            csz = imageObj.Method.PVM_EncNReceivers;
        end
        
        handles.d.carbon_data_raw = reshape(handles.d.carbon_data_raw, fidsz, xsz, ysz, ...
                                                                       zsz, tsz, csz, asz, []);
        if (asz > 1)
            handles.d.carbon_data_raw = mean(handles.d.carbon_data_raw, 7);
        end
        
        
        % kspace ordering...
        if (strcmp(imageObj.Method.Method, '<Bruker:CSI>') || ...
            strcmp(imageObj.Method.Method, '<User:geoffCSI>'))
            
            if (length(imageObj.Method.PVM_EncOrder) >= 2) && ...
                strcmp(imageObj.Method.PVM_EncOrder{1}, 'CENTRIC_ENC')
            
                % need to reorder data to account for centric encoding in
                % demension 2
                
%                 figure(3); imagesc(squeeze(max(abs(handles.d.carbon_data_raw)))); axis image;
                
                % for 20-sized matrix:
                % PVM_EncSteps0: [0 -1 1 -2 2 -3 3 -4 4 -5 5 -6 6 -7 7 -8 8 -9 9 -10]
                % indices should be which index in the k-space matrix at which
                % each line of the raw data should be stored to unwrap
                % centric encoding
                indices = imageObj.Method.PVM_EncSteps0 + ceil(xsz/2.0) + 1;
                handles.d.carbon_data_raw(:, indices, :, :, :, :, :, :) = handles.d.carbon_data_raw;
%                 figure(6); imagesc(squeeze(max(abs(handles.d.carbon_data_raw)))); axis image;
            end
            if (length(imageObj.Method.PVM_EncOrder) >= 2) && ...
                strcmp(imageObj.Method.PVM_EncOrder{2}, 'CENTRIC_ENC')
                % need to reorder data to account for centric encoding in
                % demension 3
                
                indices = imageObj.Method.PVM_EncSteps1 + ceil(ysz/2.0) + 1;
                handles.d.carbon_data_raw(:, :, indices, :, :, :, :, :) = handles.d.carbon_data_raw;
            end            
        end
        
    else
        error('Unrecognized Bruker Method! Dont know how to process raw data...')
    end
    
    
    % carbon_data_raw should now by a 3+D matrix indexed by:
    % (Samples in FID), (spatial dim 1), (spatial dim 2), (spatial dim 3), (timepoint), (coil/channel)
    disp(['data size after averaging: ' num2str(size(handles.d.carbon_data_raw))])
    
    % raw data resolution is not necessarily equal to reconstructed resolution
    handles.p.carbon_resolution = [xsz ysz];
    

    ExtractBrukerHeaderInfo(imageObj, handles);
    
    
    handles.d.carbon_recon.hz = linspace(-0.5, 0.5, size(handles.d.carbon_data_raw,1)) .* handles.p.carbon_header.specw;

    handles.p.carbon_recon_point_low = 1;
    handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,1);
    
    if (handles.p.carbon_load_figures_extra == 1)
        % show raw data...
        centre_x = ceil(size(handles.d.carbon_data_raw,2)/2 + 0.1); % index 5 for an 8x8 or 9x9 matrix
        centre_y = ceil(size(handles.d.carbon_data_raw,3)/2 + 0.1);
        num_pts = size(handles.d.carbon_data_raw,1);
        
        % find timepoint with largest magnitude FID at centre of k-space
        compressed_data = abs(handles.d.carbon_data_raw(:,centre_x,centre_y,:,:,:));
        compressed_data = squeeze(max(max(max(compressed_data,[],6),[],4),[],1));
        
        [~, max_idx] = max(compressed_data);
        if (max_idx < 1 || max_idx > length(handles.d.carbon_data_raw))
            max_idx = 1;
        end
        
        
        compressed_data = handles.d.carbon_data_raw(:,centre_x,centre_y,:,max_idx,:);
        compressed_data = compressed_data(:,:);
                
        
        figure(823532)
        xaxisvals = (1:num_pts) * handles.p.carbon_header.dwell_time * 1000;
        plot(xaxisvals, real(compressed_data), ...
             xaxisvals, imag(compressed_data));
        title('Centre K-Space Biggest Magnitude FIDs')
        ylabel('Signal [AU] magnitude')
        xlabel('Sampling Time (ms)')
                
        if (size(handles.d.carbon_data_raw,5) > 1)
            figure(823584)
            
            compressed_data = abs(handles.d.carbon_data_raw(:,centre_x,centre_y,:,:));
            compressed_data = mean(compressed_data,4);
            compressed_data = mean(compressed_data,1);
            
            plot(squeeze(compressed_data))
            title('Centre K-Space mean FID magnitude vs. frame')
            ylabel('Signal [AU] magnitude')
            xlabel('Frame Number')
        end
        
        figure(8254327)
        
        compressed_data = abs(handles.d.carbon_data_raw);
        compressed_data = mean(mean(mean(mean(compressed_data,6),5),4),1);
        
        imagesc(squeeze(compressed_data));
        title('mean magnitude of FIDs (averaged over time)')
        axis image
        colorbar
        colormap jet
    end    
    
    
    % do FID / k-space to image recon
    params.dwell_time =     handles.p.carbon_header.dwell_time;
    if isfield(handles.p, 'carbon_fov')
        if length(handles.p.carbon_fov) > 1
            params.read_fov = handles.p.carbon_fov(1);
            params.phase_fov = handles.p.carbon_fov(2);
        else
            params.read_fov = handles.p.carbon_fov;
            params.phase_fov = params.read_fov;
        end
    else
        params.read_fov = [2 2];
        params.phase_fov = [2 2];
    end
    params.method =         handles.p.carbon_header.ACQ_method;
    params.sliceOrient =    handles.p.carbon_header.sliceOrient;
    params.readOrient =     handles.p.carbon_header.readOrient;
    params.zoom =           handles.p.carbon_recon_zoom;
    params.freq_fft =       handles.p.do_freq_fft;
    params.spat_fft =       handles.p.do_spatial_fft;
    
    % if loading job data of image, need to fft in spatial dimensions,
    % since kspace_fid_recon expects image, which is what the fid file
    % contains, while the job file is actually just raw kspace data
    img = handles.d.carbon_data_raw;
%     handles.p.carbon_resolution = [size(handles.d.carbon_data_raw,2) size(handles.d.carbon_data_raw,3)];
    if (xsz > 1)
        img = fftshift(fft(img,[],2),2);
    end
    if (ysz > 1)
        img = fftshift(fft(img,[],3),3);
    end
    
    
    
    handles.d.carbon_recon.image = bruker_kspace_fid_recon(img, params);
    
    % the following is common for all sequences
    disp(['Loading of carbon data finished. Size: ' num2str(size(handles.d.carbon_recon.image)) ...
          ' [X Y freqencies slices coils timesteps]']);

    sz = size(handles.d.carbon_recon.image);
    sz(end+1:6) = 1;
    handles.d.carbon_recon.image = permute(handles.d.carbon_recon.image, [1 2 3 6 4 5]);
    handles.d.carbon_recon.image = reshape(handles.d.carbon_recon.image, [sz(1) sz(2) sz(3) sz(6) sz(5) sz(4)]);
    handles.d.carbon_recon.image = permute(handles.d.carbon_recon.image, [1 2 3 6 5 4]);
 
    % extract frequency axis
    if (isfield(handles.d.carbon_recon, 'hz'))
        handles.p.hz = handles.d.carbon_recon.hz;
    else
        handles.p.hz = [];
    end
    handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;

    
    if (exist('findpeaks')) %#ok<EXIST>
        % intialize display frequencies by summing over whole image
        % find overall image mean highest peak in spectrum
        spec_data = permute(abs(handles.d.carbon_recon.image), [1 2 4 5 6 3]);
        spec_data = squeeze(sum(sum(sum(sum(sum(spec_data,5),4),3),2),1));
        
        [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(spec_data, handles);
        handles.p.f1_val = handles.p.hz(pyr_idx);
        handles.p.f2_val = handles.p.hz(ala_idx);
        handles.p.f3_val = handles.p.hz(prh_idx);
        handles.p.f4_val = handles.p.hz(lac_idx);
        
        idxs = [pyr_idx ala_idx prh_idx lac_idx];
        biggest_idx = 1;
        for n = 1:length(idxs)
            if (spec_data(idxs(n)) > spec_data(biggest_idx))
                biggest_idx = idxs(n);
            end
        end
        handles.p.freq_val = handles.p.hz(biggest_idx);
    end
    

    % set the pointer to the center of the image
    if ~isprop(handles.p, 'pointer2d')
        handles.p.addprop('pointer2d');
    end
    handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
    handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
    
    handles.p.carbon_recon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image, 2)];

    handles.p.slice_carbon_val = 1;
    handles.p.coil_carbon_val = 1;
    handles.p.timestep_val = 1;

    % calculate time axis
    num_frames = max(1, size(handles.d.carbon_recon.image, 6));
    
    
    handles.p.nExcitationsPerTimestep = GetBrukerNumExcitationsPerTimeStep(handles, imageObj);
    

    % use number of sampled points and time per sampled point (TR) to get
    % the total frame TR
    total_frame_TR = handles.p.nExcitationsPerTimestep(1) * handles.p.carbon_header.tr / 1000;
    handles.edit_repetitiontime.String = num2str(total_frame_TR);
    
    if ~isprop(handles.p, 'timeaxis')
        handles.p.addprop('timeaxis');
    end
    if total_frame_TR > 0
        handles.p.timeaxis = total_frame_TR * (1:num_frames);
    else
        handles.p.timeaxis = 1:num_frames;
        warning('time axis is labelled incorrectly, since TR is not defined. Shown are the number of steps, not the time in seconds.');
    end

    guidata(hObject,handles);
    plot4d_plot(handles)    
    
    

function img = siemens_kspace_fid_recon(kspace_fid_data, params)
    disp(['siemens_kspace_fid_recon data size: ' num2str(size(kspace_fid_data))])
    disp(['siemens_kspace_fid_recon requested zoom: ' num2str(params.zoom)])
    disp(['siemens_kspace_fid_recon requested Spectral Filling: ' num2str(params.spec_fillfactor)])

    %inserted Section for spectral zeropadding: (2020.04.26 - Martin G.)
    if params.spec_fillfactor > 0 && params.spec_fillfactor == round(params.spec_fillfactor)
       sz = size(kspace_fid_data);
       temp = zeros([sz(1)*params.spec_fillfactor sz(2:end)]);
       temp(1:sz(1),:,:,:,:) = kspace_fid_data;
       kspace_fid_data = temp;
    else
       error("Spectral Fillfactor is invalid! Please choose an integer value larger than 0, e.g. 1 or 2 ....)")
    end
    %end inserted section
    
    
    % do line broadening, if requested and possible...
    if (params.lb > 0 && params.dwell_time > 0)
        num_fid_samples = size(kspace_fid_data,1);
        t = (0:(num_fid_samples-1)) * params.dwell_time;
        % Gauß filter
        fil = exp(-(pi*params.lb*t).^2/(2*log(2)))';
        sz = size(kspace_fid_data);
        filtered_data = kspace_fid_data .* repmat(fil, [1 sz(2:end)]);
    else
        filtered_data = kspace_fid_data;
    end
         
    
    % fourier transform FIDs to spectra
    if (params.freq_fft)
        img = fftshift(fft(filtered_data,[],1),1);
    else
        img = filtered_data;
    end
    
    
    % reorder to being indexed by pos-X, pos-Y, freq, (singleton/slice), (singleton/coil), time
    img = permute(img, [2 3 1 4]);
    img = reshape(img, [size(img,1) size(img,2) size(img,3) 1 1 size(img,4)]);
    
    % pad data to increase recon resolution, if requested
    if (~isfield(params, 'res'))
        params.res = size(img,1);
    end
    if (params.res < size(img,1))
        params.res = size(img,1);
    end
    if (params.res < size(img,2))
        params.res = size(img,2);
    end    
    npix = params.res;
    mtxres_x = size(img,1);
    mtxres_y = size(img,2);
    img_temp = zeros(mtxres_x, mtxres_y, size(img,3), size(img,4), size(img,5), size(img,6));  
    img_temp = img;


    % 2D spatial fourier transform to image
    img = fftshift(fft(fftshift(fft(img_temp,[],1),1),[],2),2);
    img = 1000*double(img);
    disp('Upscaling of intensity by factor 1000')
    img = flip(img,1);                                         
    img = flip(img,2);          
    
    % apply checkerboard phase offset to compensate for pattern present by default
    if (params.spat_fft)
        for i = 1:size(img,1)
            if mod(i,2)
                start = 2;
            else
                start = 1;
            end
            for j = start:2:size(img,2)
                img(i,j,:,:,:,:) = - img(i,j,:,:,:,:);
            end
        end
    end
    %img = rot90(img, -1); %inserted as workaround for Mio Patient 17 - 15.10.2021
    
    % resample to higher resolution, unless non-imaging spectra or no
    % spatial FFT is applied
    if (params.spat_fft && params.zoom ~= 1 && max(size(img)) > 1)
        upscale_factor = params.zoom;
    
        img_orig = img;
        img_sz = size(img);
    
        % resample single 2D image to determine how big resampled image storage
        % needs to be
        test_img = imresize(squeeze(img_orig(:,:,1,1,1,1,1)), upscale_factor);
        test_img_sz = size(test_img);
        img_sz(1:2) = test_img_sz(1:2);
        img_sz(end+1:6) = 1;
        img = zeros(img_sz);


        for k = 1:img_sz(3)
            for l = 1:img_sz(4)
                for m = 1:img_sz(5)
                    for n = 1:img_sz(6)
                        img(:,:,k,l,m,n) = imresize(squeeze(...
                            img_orig(:,:,k,l,m,n)), upscale_factor, 'bilinear');
                    end
                end
            end
        end
    end
    
    
    
function img = bruker_kspace_2dseq_recon(img_data_in, params)
    img = double(img_data_in);

    % 2dseq data comes in space (not k-space) coords so just need to permute
    %
    % from:
    % freq  / space / space / space / coil = singleton / time
    % to:
    % space / space / freq  / space / coil = singleton / time
    img = permute(img, [2 3 1 4 5 6]);
    img = flip(img, 2);

    if ((strcmp(params.method, 'Bruker:EPSI') || strcmp(params.method, 'User:epsi_combined_1') ) && strcmp(params.readOrient, 'A_P') == 1)
        img = rot90(img, -1);
        img = flip(img, 1);
        disp('rotated 90 degrees and flipped for EPSI 2dseq recon')
    end


    % 2dseq data normally already in magnitude, so undoing FFTs not
    % sensible... 
    % But OK: fourier transform spectral back to FID
    if (~params.freq_fft)
        img = fftshift(fft(img,[],3),3);
    end
    % And/or OK: fourier Tx image to k-space
    if (~params.spat_fft)
        % stored as image in fid, don't need to spatially fft to get image
        img = fftshift(fft(fftshift(fft(img,[],2),2),[],1),1);
        
    elseif (params.zoom ~= 1 && max(size(img)) > 1)
        % resample to higher resolution

        upscale_factor = params.zoom;

        img_orig = img;
        img_sz = size(img);

        % resample single 2D image to determine how big resampled image storage
        % needs to be
        test_img = imresize(squeeze(img_orig(:,:,1,1,1,1,1)), upscale_factor);
        test_img_sz = size(test_img);
        img_sz(1:2) = test_img_sz(1:2);
        img_sz(end+1:6) = 1;
        img = zeros(img_sz);


        for k = 1:img_sz(3)
            for l = 1:img_sz(4)
                for m = 1:img_sz(5)
                    for n = 1:img_sz(6)
                        img(:,:,k,l,m,n) = imresize(squeeze(...
                            img_orig(:,:,k,l,m,n)), upscale_factor, 'bilinear');
                    end
                end
            end
        end
    end        


function img = bruker_kspace_fid_recon(kspace_fid_data, params)
    disp(['bruker_kspace_fid_recon data size: ' num2str(size(kspace_fid_data))])
    disp(['bruker_kspace_fid_recon requested zoom: ' num2str(params.zoom)])
    disp(['bruker_kspace_fid_recon requested Spectral Filling: ' num2str(params.spec_fillfactor)])
    
    % TODO: consider better line broadening if fid data magnitude
    % high from start to end of acquisition window
    
    %inserted Section for spectral zeropadding: (2020.04.09 - Martin G.)
    if params.spec_fillfactor > 0 && params.spec_fillfactor == round(params.spec_fillfactor)
       sz = size(kspace_fid_data);
       temp = zeros([sz(1)*params.spec_fillfactor sz(2:end)]);
       temp(1:sz(1),:,:,:,:) = kspace_fid_data;
       kspace_fid_data = temp;
    else
       error("Spectral Fillfactor is invalid! Please choose an integer value larger than 0, e.g. 1 or 2 ....)")
    end
    %end inserted section
    
    
    % do line broadening, if requested and possible...
    if (params.lb > 0 && params.dwell_time > 0)
        num_fid_samples = size(kspace_fid_data,1);
        t = (0:(num_fid_samples-1)) * params.dwell_time;
        % Gauß filter
        fil = exp(-(pi*params.lb*t).^2/(2*log(2)))';
        sz = size(kspace_fid_data);
        filtered_data = kspace_fid_data .* repmat(fil, [1 sz(2:end)]);
    else
        filtered_data = kspace_fid_data;
    end
    

    % fourier transform FIDs to spectra
    if (params.freq_fft)
        img = fftshift(fft(filtered_data,[],1),1);
    else
        img = filtered_data;
    end
    
    % reorder to being indexed by pos-X, pos-Y, freq, slice, coil, time
    img = permute(img, [2 3 1 4 5 6]);
    img = reshape(img, [size(img,1) size(img,2) size(img,3) size(img,4) size(img,6) size(img,5)]);

    
    if (contains(params.method, 'CSI', 'IgnoreCase', true))
        img = rot90(img, -1);
        disp('rotated 90 degrees CSI recon')
    end
    
    
    if (contains(params.method, 'EPSI', 'IgnoreCase', true))
        if (params.spat_fft)
            % stored k-space in fid
            img = fftshift(fft(fftshift(fft(img,[],1),1),[],2),2);
        end
        
    elseif (contains(params.method, 'MGE', 'IgnoreCase', true))
        if (params.spat_fft)
            % stored k-space in fid
            img = fftshift(fft(fftshift(fft(img,[],1),1),[],2),2);
        end        
        
        % and needs rotation to match anatomical image
        img = rot90(img, 1);
        disp('rotated 90 degrees MGE recon')
    else
        if (~params.spat_fft)
            % stored as image in fid, don't need to spatially fft to get image
            img = ifft(ifftshift(ifft(ifftshift(img,2),[],2),1),[],1);
        end
    end
    
    
    % apply checkerboard phase offset to compensate for pattern present by default
    if ((params.spat_fft) && ...
        (contains(params.method, 'CSI', 'IgnoreCase', true) || ...
         contains(params.method, 'MGE', 'IgnoreCase', true)) ...
    )
        for i = 1:size(img,1)
            if mod(i,2)
                start = 2;
            else
                start = 1;
            end
            for j = start:2:size(img,2)
                img(i,j,:,:,:,:) = - img(i,j,:,:,:,:);
            end
        end
    end
    
    
    % resample to higher resolution, unless non-imaging spectra or no
    % spatial FFT is applied
    if (params.spat_fft && params.zoom ~= 1 && max(size(img)) > 1)
        upscale_factor = params.zoom;
    
        img_orig = img;
        img_sz = size(img);
    
        % resample single 2D image to determine how big resampled image storage
        % needs to be
        test_img = imresize(squeeze(img_orig(:,:,1,1,1,1,1)), upscale_factor);
        test_img_sz = size(test_img);
        img_sz(1:2) = test_img_sz(1:2);
        img_sz(end+1:6) = 1;
        img = zeros(img_sz);


        for k = 1:img_sz(3)
            for l = 1:img_sz(4)
                for m = 1:img_sz(5)
                    for n = 1:img_sz(6)
                        img(:,:,k,l,m,n) = imresize(squeeze(...
                            img_orig(:,:,k,l,m,n)), upscale_factor, 'bilinear');
                    end
                end
            end
        end
    end
    
    
    if (strcmp(params.method, 'Bruker:EPSI') || strcmp(params.method, 'User:epsi_combined_1'))
        img = flip(img, 2);
        img = rot90(img, -1);
        img = flip(img, 2);
    end
    if (strcmp(params.readOrient, 'L_R') == 1)
        disp('readout L_R -> flip / rotating to match anatomical, hopefully')
        img = rot90(img, -1);
        img = flip(img, 1);
    end


function carbon_load_ge_pfile(hObject,handles)
    carbon_load_common(handles)
    handles.d.carbon_recon = [];
    
    params.lb = handles.p.carbon_line_broadening;
    params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally -y
    params.yshift = - handles.p.carbon_shift_x;
    
    
    % load and reconstruct carbon data
    if ~isprop(handles.p, 'carbon_header')
        handles.p.addprop('carbon_header');
    end
    [handles.d.carbon_data_raw, handles.p.carbon_header] = read_MR_rawdata(handles.p.carbon_file);

    % carbon_data_raw should now by a 2D matrix indexed by:
    % (FID Number), (Samples in FID)
    % data will be sorted into k-space matrix by recon code
    
    display_MR_parameters(handles.p.carbon_header)
    
    
    if (handles.p.carbon_load_figures_extra == 1)
        % show raw data...
        figure(823532)
        plot(1:size(handles.d.carbon_data_raw,2), real(handles.d.carbon_data_raw(1,:,1,1,1,1)), ...
             1:size(handles.d.carbon_data_raw,2), imag(handles.d.carbon_data_raw(1,:,1,1,1,1)));
        title('First FID')
        ylabel('Signal [AU] magnitude')
        xlabel('Acquisition Point')
                
        figure(8254327)
        plot(1:size(handles.d.carbon_data_raw,1),   mean(abs(handles.d.carbon_data_raw(:,1:end,1,1,1,1)),2), 'b');
        title('mean magnitude of each FID')
        ylabel('Signal [AU] magnitude')
        xlabel('FID Number')        
    end
    
    % check what trajectory was used to acquire the data
        
    if (handles.p.carbon_header.image.user3 == 98 || handles.p.carbon_header.image.user3 == 53 || handles.p.carbon_header.image.user3 == 65)

        handles.p.trajectoryfile = 'fidcsi_20x20_full_geoff_test';
        
        % define default reconstruction parameters
        params.res = 20;
        params.specfiton = 0;
        
        % FIDCSI with 20x20 acquisition matrix...
        handles.d.carbon_recon = fidcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % extract repetition time, set default reconstruction window
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = sum(wf.fidpos > 0) + length(wf.sort);
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);
    
    elseif (handles.p.carbon_header.image.user3 == 97 || handles.p.carbon_header.image.user3 == 69)

        handles.p.trajectoryfile = 'fidcsi_16x16_full_geoff_test';
        
        % define default reconstruction parameters
        params.res = 16;
        params.specfiton = 0;
       
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % extract repetition time 
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = sum(wf.fidpos > 0) + length(wf.sort);
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);
    
    elseif (handles.p.carbon_header.image.user3 == 68 || handles.p.carbon_header.image.user3 == 64)

        handles.p.trajectoryfile = 'fidcsi_12x12_full_geoff';
        
        % define default reconstruction parameters
        params.res = 12;
        params.specfiton = 0;
       
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % extract repetition time 
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = sum(wf.fidpos > 0) + length(wf.sort);
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);        
        
    elseif (handles.p.carbon_header.image.user3 == 95)
             
        handles.p.trajectoryfile = 'fidcsi_12x12_geoff_test.mat'; % centre circle only
        
        % define default reconstruction parameters
        params.res = 12;
        params.specfiton = 0;
        
        % FIDCSI with 12x12 acquisition matrix...
        handles.d.carbon_recon = fidcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % extract repetition time 
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = sum(wf.fidpos > 0) + length(wf.sort);
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);

    elseif (handles.p.carbon_header.image.user3 == 67 || handles.p.carbon_header.image.user3 == 60 || (handles.p.carbon_header.image.user3 >= 41 && handles.p.carbon_header.image.user3 <= 45))

        handles.p.trajectoryfile = 'fidcsi_8x8_full_geoff';
        
        % define default reconstruction parameters
        params.res = 8;
        params.specfiton = 0;
        params.freq = 0;
        params.bw = handles.p.carbon_header.rdb_hdr.spectral_width;
        
        % FIDCSI with 8x8 acquisition matrix...
        handles.d.carbon_recon = fidcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % extract repetition time 
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = sum(wf.fidpos > 0) + length(wf.sort);
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);
        
    elseif (handles.p.carbon_header.image.user3 == 79)

        handles.p.trajectoryfile = 'fidcsi_16x16_invivo_stephan_v0';

        % define default reconstruction parameters
        params.res = 16;
        params.specfiton = 1;
   
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % extract repetition time 
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = sum(wf.fidpos > 0) + length(wf.sort);
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);

    % check whether the EPSI sequence was used to acquire the data
    elseif (handles.p.carbon_header.image.user3 == 27)
        
        handles.p.trajectoryfile = 'epsi_res12_recon';

        % define default reconstruction parameters
        params.res  = 12; % in pixel
        params.freq = [handles.p.f1_val handles.p.f2_val handles.p.f3_val handles.p.f4_val];

        % EPSI with 12x12 acquisition matrix...
        handles.d.carbon_recon = epsi_sd(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % extract repetition time 
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = sum(wf.fidpos > 0) + wf.necho;
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);
        
        handles.p.apply_checkerboard_phase = 0;

    elseif (handles.p.carbon_header.image.user3 == 2)
        % default recon parameters
        params.res = 16;
        params.freq = [0 -125 -215 -392 -716]*7/3;  % {'Lac', 'Pyr-Hyd', 'Ala', 'Pyr', 'Bi-Carb'};
        
        % Ideal Spiral CSI with 16x16 matrix...
        handles.p.trajectoryfile = 'ideal_spiral_csi_16x16_invivo';
        
        handles.d.carbon_recon = idealspiralcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
        % recon output claims to be ordered [x y timesteps slices frequencies]
        % but actually seems to be ordered [x y frequencies slices/coils timesteps]
        % this tool expects [X Y freqencies slices coils timesteps]
        
        % but for now, just display spectrum as a 1-pixel image, so that
        % image recon freqs can be chosen for recon step
        handles.d.carbon_recon.image = handles.d.carbon_recon.fid.spec;
        handles.d.carbon_recon.image = permute(handles.d.carbon_recon.image, [2 4 3 1]);
        handles.d.carbon_recon.image = reshape(handles.d.carbon_recon.image, [1 1 size(handles.d.carbon_recon.image)]);
        handles.d.carbon_recon.hz = handles.d.carbon_recon.fid.hz;
        
        % extract repetition time 
        wf = load(handles.p.trajectoryfile);
        handles.p.nExcitationsPerTimestep = length(wf.ets) + 1;
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);
        
        handles.p.apply_checkerboard_phase = 0;        
        
    elseif (handles.p.carbon_header.image.user3 == 1)
        
        % non-imaging spectroscopy
        [spec,~,~,hz] = fid2spec(handles.d.carbon_data_raw, handles.p.carbon_header);
        handles.d.carbon_recon.hz = hz;
        
        handles.d.carbon_recon.image = permute(spec, [3 4 2 5 6 1]);
        handles.d.carbon_fov = [handles.p.carbon_header.image.dfov handles.p.carbon_header.image.dfov];
        
        params.res = 1;
        handles.p.nExcitationsPerTimestep = 1;
        handles.p.carbon_recon_point_low = 1;
        handles.p.carbon_recon_point_high = size(handles.d.carbon_data_raw,2);
        
        handles.p.apply_checkerboard_phase = 0;

    else
        % unknown imaging trajectory
        [spec,~,~,hz] = fid2spec(handles.d.carbon_data_raw(:,:,1,1,1,1), handles.p.carbon_header);

        figure(102020)
        plot(hz, abs(spec(1,:)));
        title('First FID Specturm')
        xlabel('Frequency [Hz]')
        disp(' ')
        disp(['Unrecognized carbon trajectory file CV: ' num2str(handles.p.carbon_header.image.user3)])
        disp(['spectral width: ' num2str(handles.p.carbon_header.rdb_hdr.spectral_width) ' Hz'])
        disp(['spectral width CV: ' num2str(handles.p.carbon_header.image.user0) ' Hz'])
        disp(['number of points CV: ' num2str(handles.p.carbon_header.image.user1)])
        disp(['nucleus CV: ' num2str(handles.p.carbon_header.image.user2)])
        disp(['total scans CV: ' num2str(handles.p.carbon_header.image.user4)])
        disp(['RF pulse CV: ' num2str(handles.p.carbon_header.image.user14)])
        disp(['Flip Angle: ' num2str(handles.p.carbon_header.image.mr_flip) ' deg'])
        disp(['Excitation TR: ' num2str(handles.p.carbon_header.image.tr / 1000) ' ms'])
        disp(' ')        
        return
    end
    
    % the following is common for all sequences
    handles.p.carbon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
    disp(['Loading of carbon data finished. Size: ' num2str(size(handles.d.carbon_recon.image)) ...
          ' [X Y freqencies slices coils timesteps]']);

    disp(' ')
    disp(['Known carbon trajectory file CV: ' num2str(handles.p.carbon_header.image.user3)])
    disp(['spectral width: ' num2str(handles.p.carbon_header.rdb_hdr.spectral_width) ' Hz'])
    disp(['spectral width CV: ' num2str(handles.p.carbon_header.image.user0) ' Hz'])
    disp(['number of points CV: ' num2str(handles.p.carbon_header.image.user1)])
    disp(['nucleus CV: ' num2str(handles.p.carbon_header.image.user2)])
    disp(['total scans CV: ' num2str(handles.p.carbon_header.image.user4)])
    disp(['RF pulse CV: ' num2str(handles.p.carbon_header.image.user14)])
    disp(['Flip Angle: ' num2str(handles.p.carbon_header.image.mr_flip) ' deg'])
    disp(['Excitation TR: ' num2str(handles.p.carbon_header.image.tr / 1000) ' ms'])
    disp(' ')
    
    handles.p.reference_freq = 75.5;    % assumed, untested
    
    % extract frequency axis
    if (isfield(handles.d.carbon_recon, 'hz'))
        handles.p.hz = handles.d.carbon_recon.hz;
    else
        handles.p.hz = [];
    end
    handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;

    
    if (exist('findpeaks')) %#ok<EXIST>
        if (HaveGEData(handles) && handles.p.carbon_header.image.user3 == 2 || handles.p.carbon_header.image.user3 == 27)
            spec_data = handles.d.carbon_recon.fid.spec;
            spec_data = sum(spec_data,3);
            spec_data = sum(spec_data,1);
            spec_data = abs(squeeze(spec_data));
        else
            % intialize display frequencies by summing over whole image
            % find overall image mean highest peak in spectrum
            spec_data = permute(abs(handles.d.carbon_recon.image), [1 2 4 5 6 3]);
            spec_data = squeeze(sum(sum(sum(sum(sum(spec_data,5),4),3),2),1));
        end
        
        [pyr_idx, ala_idx, prh_idx, lac_idx] = FindPeakIdxInSpectrum(spec_data, handles);
        handles.p.f1_val = handles.p.hz(pyr_idx);
        handles.p.f2_val = handles.p.hz(ala_idx);
        handles.p.f3_val = handles.p.hz(prh_idx);
        handles.p.f4_val = handles.p.hz(lac_idx);
        
        idxs = [pyr_idx ala_idx prh_idx lac_idx];
        biggest_idx = 1;
        for n = 1:length(idxs)
            if (spec_data(idxs(n)) > spec_data(biggest_idx))
                biggest_idx = idxs(n);
            end
        end
        handles.p.freq_val = handles.p.hz(biggest_idx);
    end
    

    % set the pointer to the center of the image
    if ~isprop(handles.p, 'pointer2d')
        handles.p.addprop('pointer2d');
    end
    handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
    handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
    
    % extract resolution info from trajectory and p-file
    if (handles.p.carbon_header.image.user3 == 1)
        handles.p.carbon_resolution = [1 1];
    else
        handles.p.carbon_resolution = params.res * 2;
    end
    handles.p.carbon_fov = [handles.p.carbon_header.image.dfov handles.p.carbon_header.image.dfov];
        
    handles.p.slice_carbon_val          = 1;
    handles.p.coil_carbon_val           = 1;
    handles.p.timestep_val              = 1;

    % calculate time axis
    num_frames = max(1, size(handles.d.carbon_recon.image, 6));    
    total_frame_TR = handles.p.nExcitationsPerTimestep * handles.p.carbon_header.image.tr / 1d6;
    handles.edit_repetitiontime.String  = num2str(total_frame_TR);
    
    % fli pangle
    handles.edit_flipangle.String       = num2str(handles.p.carbon_header.image.mr_flip);

    
    if ~isprop(handles.p, 'timeaxis')
        handles.p.addprop('timeaxis')
    end
    if total_frame_TR > 0
        handles.p.timeaxis = total_frame_TR * (1:num_frames);
    else
        handles.p.timeaxis = 1:num_frames;
        warning('time axis is labelled incorrectly, since TR is not defined. Shown are the number of steps, not the time in seconds.');
    end

    % show spectra if desired
    if (handles.p.carbon_load_figures_extra == 1 && handles.p.carbon_header.image.user3 == 27)
        % special case for EPSI
        prerecon_epsi(handles.d.carbon_recon, [1 size(handles.d.carbon_recon.image,6)]);    % plots the spectrum (timepoints,slice,coil)
        
    elseif (handles.p.carbon_load_figures_extra == 1)
        % FID CSI
        [spec,~,~,hz] = fid2spec(handles.d.carbon_data_raw(:,:,1,1,1,1), handles.p.carbon_header);

        figure(102020)
        plot(hz, abs(spec(1,:)));
        title('First FID Specturm')
        xlabel('Frequency [Hz]')
    end
            
    % update handles
    guidata(hObject,handles);
    plot4d_plot(handles)


function have_siemens = HaveSiemensData(handles)
    have_siemens = isfield(handles.p.carbon_header, 'Config');


function have_ge = HaveGEData(handles)
    have_ge = isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'fid');

   
function have_bruker = HaveBrukerData(handles)
    have_bruker = isfield(handles.p.carbon_header, 'ACQ_method');


function have_siemens_bf = HaveSiemensBfData(handles)
    have_siemens_bf = isfield(handles.p.carbon_header,'is_Siemens_bf_data');

    
function carbon_recon(hObject, handles)
    % save pointer position so it can be restored, accounting for any
    % change in the resolution of the image, after reconstruction
    handles.p.option_plot_pH_map = 0;
    handles.p.option_plot_intensity = 1;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.fit_current_spectrum = 0;
    saved_old_pointer_pos = 0;
    if (isfield(handles, 'd') && isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'image') && isfield(handles, 'p') && isprop(handles.p, 'pointer2d'))
        old_carbon_res = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
        old_pointer2d = handles.p.pointer2d;
        saved_old_pointer_pos = 1;
    end

    % collect desired reconstruction resolution, frequencies and shift
    params.res =        handles.p.carbon_resolution;
    params.freq =       [handles.p.f1_val handles.p.f2_val handles.p.f3_val handles.p.f4_val]; % may be overridden below
    params.lb =         handles.p.carbon_line_broadening;
    
    params.readOrient = '';
    if (isfield(handles.p.carbon_header, 'readOrient'))
        params.readOrient = handles.p.carbon_header.readOrient;
    end
    params.sliceOrient = '';
    if (isfield(handles.p.carbon_header, 'sliceOrient'))
        params.sliceOrient= handles.p.carbon_header.sliceOrient;
    end
    
    disp(['size of raw data: ' num2str(size(handles.d.carbon_data_raw))])
    disp(['window range: ' num2str([handles.p.carbon_recon_point_low handles.p.carbon_recon_point_high])])
    
    
    % find out if any windowing of the data is needed
    if (HaveSiemensData(handles) || HaveBrukerData(handles) || HaveSiemensBfData(handles))
        % ordered first by FID samples
        windowed_carbon_data = permute(handles.d.carbon_data_raw, [2 1 3 4 5 6]);
        need_to_permute_back = true;
    else
        % GE data... ordered first by which kspace sample, second by FID samples
        windowed_carbon_data = handles.d.carbon_data_raw;
        need_to_permute_back = false;
    end
    total_fid_length = size(windowed_carbon_data,2);
    
    
    % apply window to data?
    if (handles.p.carbon_recon_point_low == 1 && handles.p.carbon_recon_point_high == total_fid_length)
        disp('not windowing, as full range of data requested')
        % windowed carbon data unchanged ...
        
    else
        disp('applying window to data')
        one_dim_window = zeros(1, total_fid_length);
        one_dim_window(handles.p.carbon_recon_point_low:handles.p.carbon_recon_point_high) = 1;
        kernel_width = 8;
        kernel = zeros(1,kernel_width);
        for n = 1:kernel_width
            kernel(n) = exp(-(n - (kernel_width+1)/2)^2 / (kernel_width/8)^2);
        end
        kernel = kernel / sum(kernel);
        one_dim_window = conv(one_dim_window, kernel, 'same');

        window_factors = zeros(size(windowed_carbon_data));
        for n = 1:size(window_factors,2)
            window_factors(:,n,:,:,:,:) = one_dim_window(n);
        end

        windowed_carbon_data = windowed_carbon_data .* window_factors;
    end

    
    if (need_to_permute_back)
        windowed_carbon_data = permute(windowed_carbon_data, [2 1 3 4 5 6]);        
    end
    
     
    if (handles.p.carbon_recon_figures_extra == 1)
        if (HaveSiemensData(handles))
            centre_x = ceil(size(handles.d.carbon_data_raw,2)/2 + 0.1); % index 5 for an 8x8 or 9x9 matrix
            centre_y = ceil(size(handles.d.carbon_data_raw,3)/2 + 0.1);
            num_pts = size(handles.d.carbon_data_raw,1);
            
            figure(8253235)
            plot((1:num_pts), abs(handles.d.carbon_data_raw(:,centre_x,centre_y,1)), '--r', ...
                 (1:num_pts), abs(windowed_carbon_data(:, centre_x,centre_y,1)),     '-b');
            title('Centre K-Space First FID')
            legend('all data', 'windowed data')
            ylabel('Signal [AU] magnitude')
            xlabel('Acquisition Point')
            
        elseif (HaveBrukerData(handles)) || (HaveSiemensBfData(handles))
            % do nothing
            
        else
            figure(8253235)
            plot(1:size(handles.d.carbon_data_raw,2),   abs(handles.d.carbon_data_raw(1,:,1,1,1,1)), '--r', ...
                 1:size(windowed_carbon_data,2),        abs(windowed_carbon_data(1,:,1,1,1,1)),      '-b');
            title('first FID')
            legend('all data', 'windowed data')
            ylabel('Signal [AU] magnitude')
            xlabel('Acquisition Point')
        end
    end
    
    
    % check what scanner type and, if GE, whether the FIDCSI sequence was used to acquire the data
    if (HaveBrukerData(handles) || HaveSiemensBfData(handles))
        % Bruker data...
        params.xshift = handles.p.carbon_shift_x;
        params.yshift = handles.p.carbon_shift_y;

        params.dwell_time =     handles.p.carbon_header.dwell_time;
        if length(handles.p.carbon_fov) > 1
            params.read_fov =   handles.p.carbon_fov(1);
            params.phase_fov =  handles.p.carbon_fov(2);
        else
            params.read_fov =   handles.p.carbon_fov;
            params.phase_fov = params.read_fov;
        end
        if (HaveSiemensBfData(handles))
            params.method =     handles.p.carbon_header.method;
        else
            params.method =     handles.p.carbon_header.ACQ_method;
        end
        params.readOrient =     handles.p.carbon_header.readOrient;
        params.sliceOrient =    handles.p.carbon_header.sliceOrient;
        params.zoom =           handles.p.carbon_recon_zoom;
        params.freq_fft =       handles.p.do_freq_fft;
        params.spat_fft =       handles.p.do_spatial_fft;
        params.spec_fillfactor =    handles.p.spec_fillfactor; %Added as spectral fillfactor (2020.04.14: Martin G.)
        
        if (strcmp(handles.p.carbon_header.loaded_data_from, '2dseq') == 1)
            handles.d.carbon_recon.image = bruker_kspace_2dseq_recon(handles.d.carbon_data_raw, params);
            
        elseif ((strcmp(handles.p.carbon_header.loaded_data_from, 'fid') == 1) || ...
                 strcmp(handles.p.carbon_header.loaded_data_from, 'ser') == 1)
            handles.d.carbon_recon.image = bruker_kspace_fid_recon(windowed_carbon_data, params);
            
        elseif (strcmp(handles.p.carbon_header.loaded_data_from, 'job') == 1)
            handles.d.carbon_recon.image = bruker_kspace_fid_recon(windowed_carbon_data, params);
        
        elseif (strcmp(handles.p.carbon_header.loaded_data_from, '.bf-file') ==1)
            handles.d.carbon_recon.image = bruker_kspace_fid_recon(windowed_carbon_data, params);
        
        else
            error('unable to custom recon process unknown format data');
        end
        
    elseif (HaveSiemensData(handles))
        % Siemens data...
        params.xshift = handles.p.carbon_shift_x;
        params.yshift = handles.p.carbon_shift_y;
    
        % some header info of potential use:
        params.dwell_time = handles.p.carbon_header.Config.DwellTime * 10^(-9); % dwell time in s
        params.read_fov = handles.p.carbon_header.Config.ReadFoV;
        params.phase_fov = handles.p.carbon_header.Config.PhaseFoV;
        params.zoom =           handles.p.carbon_recon_zoom;
        params.freq_fft =       handles.p.do_freq_fft;
        params.spat_fft =       handles.p.do_spatial_fft;
        params.spec_fillfactor =    handles.p.spec_fillfactor; %Added as spectral fillfactor (2020.04.27: Martin G.)
        
        % do FID / k-space to image recon
        handles.d.carbon_recon.image = siemens_kspace_fid_recon(windowed_carbon_data, params);
    
        % else, GE data
    elseif (handles.p.carbon_header.image.user3 == 98 || handles.p.carbon_header.image.user3 == 53 || handles.p.carbon_header.image.user3 == 65)
    
        handles.p.trajectoryfile = 'fidcsi_20x20_full_geoff_test';
        
        params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally (but only experimentally) -y
        params.yshift = - handles.p.carbon_shift_x; % in mm, this is intentionally (but only experimentally) -y 
         
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(windowed_carbon_data, handles.p.carbon_header, handles.p.trajectoryfile, params);
    
    elseif (handles.p.carbon_header.image.user3 == 97 || handles.p.carbon_header.image.user3 == 69)

        handles.p.trajectoryfile = 'fidcsi_16x16_full_geoff_test';
        
        params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally (but only experimentally) -y
        params.yshift = - handles.p.carbon_shift_x; % in mm, this is intentionally (but only experimentally) -y 
         
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(windowed_carbon_data, handles.p.carbon_header, handles.p.trajectoryfile, params);
    
    elseif (handles.p.carbon_header.image.user3 == 68 || handles.p.carbon_header.image.user3 == 64)

        handles.p.trajectoryfile = 'fidcsi_12x12_full_geoff';

        params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally (but only experimentally) -y
        params.yshift = - handles.p.carbon_shift_x; % in mm, this is intentionally (but only experimentally) -y 
         
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(windowed_carbon_data, handles.p.carbon_header, handles.p.trajectoryfile, params);
       
    elseif (handles.p.carbon_header.image.user3 == 67 || handles.p.carbon_header.image.user3 == 60 || (handles.p.carbon_header.image.user3 >= 41 && handles.p.carbon_header.image.user3 <= 45))

        handles.p.trajectoryfile = 'fidcsi_8x8_full_geoff';
        
        params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally (but only experimentally) -y
        params.yshift = - handles.p.carbon_shift_x; % in mm, this is intentionally (but only experimentally) -y 
        params.bw = handles.p.carbon_header.rdb_hdr.spectral_width;

        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(windowed_carbon_data, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
    elseif (handles.p.carbon_header.image.user3 == 95)

        handles.p.trajectoryfile = 'fidcsi_12x12_geoff_test'; % centre circle only
        
        params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally (but only experimentally) -y
        params.yshift = - handles.p.carbon_shift_x; % in mm, this is intentionally (but only experimentally) -y 
         
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(windowed_carbon_data, handles.p.carbon_header, handles.p.trajectoryfile, params);
    elseif (handles.p.carbon_header.image.user3 == 79)

        handles.p.trajectoryfile = 'fidcsi_16x16_invivo_stephan_v0';
        
        params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally (but only experimentally) -y
        params.yshift = - handles.p.carbon_shift_x; % in mm, this is intentionally (but only experimentally) -y 
         
        % FIDCSI with 16x16 acquisition matrix...
        handles.d.carbon_recon = fidcsi(windowed_carbon_data, handles.p.carbon_header, handles.p.trajectoryfile, params);

    % check whether the EPSI sequence was used to acquire the data
    elseif (handles.p.carbon_header.image.user3 == 27)
        
        handles.p.trajectoryfile = 'epsi_res12_recon';

        params.xshift = - handles.p.carbon_shift_y; % in mm, this is intentionally (but only experimentally) -y
        params.yshift = - handles.p.carbon_shift_x; % in mm, this is intentionally (but only experimentally) -y 
        
        % correct the frequencies of the peaks which are in the range below -694.4444 Hz 
        % or above 683.5938 Hz due to folding of EPSI
        params = epsi_folding(params, handles.d.carbon_recon); 
        
        % reconstruction of the EPSI data with chosen parameters
        handles.d.carbon_recon = epsi_sd(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        
    elseif (handles.p.carbon_header.image.user3 == 2)
        % Ideal SPiral CSI

        params.freq = [];
        if (handles.p.option_show_f1)
            params.freq = [params.freq handles.p.f1_val];
        end
        if (handles.p.option_show_f2)
            params.freq = [params.freq handles.p.f2_val];
        end
        if (handles.p.option_show_f3)
            params.freq = [params.freq handles.p.f3_val];
        end
        if (handles.p.option_show_f4)
            params.freq = [params.freq handles.p.f4_val];
        end
        handles.d.carbon_recon = idealspiralcsi(handles.d.carbon_data_raw, handles.p.carbon_header, handles.p.trajectoryfile, params);
        handles.d.carbon_recon.image = permute(handles.d.carbon_recon.image, [1 2 3 4 6 5]);
        
        % rotate 90 degrees CCW
%         handles.d.carbon_recon.image = rotmat(recon.image, 3);
        
        handles.p.hz = params.freq;
        handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;
        

        % calculate time axis again, after recon, which seems to sometimes
        % result in fewer frames than initial load suggested
        num_frames = max(1, size(handles.d.carbon_recon.image, 6));    
        total_frame_TR = handles.p.nExcitationsPerTimestep * handles.p.carbon_header.image.tr / 1d6;
        handles.edit_repetitiontime.String  = num2str(total_frame_TR);

        if ~isprop(handles.p, 'timeaxis')
            handles.p.addprop('timeaxis')
        end
        if total_frame_TR > 0
            handles.p.timeaxis = total_frame_TR * (1:num_frames);
        else
            handles.p.timeaxis = 1:num_frames;
            warning('time axis is labelled incorrectly, since TR is not defined. Shown are the number of steps, not the time in seconds.');
        end
        
    elseif (handles.p.carbon_header.image.user3 == 1)
        
        % non-imaging spectroscopy
        [spec,~,~,~] = fid2spec(handles.d.carbon_data_raw, handles.p.carbon_header,...
                                [], params.lb);

        handles.d.carbon_recon.image = permute(spec, [3 4 2 5 6 1]);

    end
    disp('Initial reconstruction of carbon data finished.');
    
    
    % record zoomed size of image
    handles.p.carbon_recon_resolution = [size(handles.d.carbon_recon.image,1) size(handles.d.carbon_recon.image,2)];
    
    %-------------- (2020.04.14, Martin G.): Inserted section for adjusting frequency
    % axis if spectral filling was changed
    Sz = size(handles.d.carbon_recon.image);
    if Sz(3) ~= max(size(handles.p.hz))
        dwell_time_scale_factor = 1;
        if HaveBrukerData(handles)
            if (contains(handles.p.carbon_header.method, 'EPSI', 'IgnoreCase', true))
                dwell_time_scale_factor = 2;
            end
        end
        %For pH-calculation (2020.04.08, section added by Martin G.,)
        %interpolate the spectral axis by a the filling factor
        if HaveSiemensData(handles)
            handles.d.carbon_recon.hz_padded = linspace(-0.5,0.5,(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) .* 1/params.dwell_time;
            handles.d.carbon_recon.hz_padded(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor) = handles.d.carbon_recon.hz_padded((size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) + (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
        else    
            handles.d.carbon_recon.hz_padded = linspace(-0.5,0.5,(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) .* handles.p.carbon_header.specw / dwell_time_scale_factor;
            handles.d.carbon_recon.hz_padded(size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor) = handles.d.carbon_recon.hz_padded((size(handles.d.carbon_data_raw,1)*handles.p.spec_fillfactor)-1) + (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
        end
        
          % extract frequency axis
        if (isfield(handles.d.carbon_recon, 'hz_padded')) %2020.04.09, Martin G.: variable name modified accordingly
            %handles.p.hz = handles.d.carbon_recon.hz;
            handles.p.hz = handles.d.carbon_recon.hz_padded; %2020.04.09, Martin G.: Replaced by the more general term including the spectral filling factor
        else
            handles.p.hz = [];
        end
        handles.p.ppm = handles.p.hz / handles.p.reference_freq + handles.p.working_freq_ppm;
    end
    %-------------- (2020.04.14, Martin G.): Inserted section end

    
    % show reconstructed data using Eugen's functions if desired and using
    % EPSI data (for which they are designed...)
    if (handles.p.carbon_recon_figures_extra == 1 && isfield(handles.p.carbon_header, 'image') && handles.p.carbon_header.image.user3 == 27)
        overlayshiftX = 0;
        overlayshiftY = 0;
        recon_image_eugen_epsi_sd(handles.d.carbon_recon, handles.d.proton_image, handles.p.carbon_header,...
                                  params, handles.p.timesteps, overlayshiftX, overlayshiftY)
    end
    
    % wait for the previous figures to be displayed                  
    drawnow
    
    if (~HaveGEData(handles) || handles.p.carbon_header.image.user3 ~= 2) && handles.p.do_freq_fft
        % find for each pixel / slice, peak-spectrum-frequency near the global
        % freq1 and freq4 frequencies.
        % for most pixels that matter, this should be the same metabolite, but
        % corrected for B0 or pH related frequency shifts that vary from
        % pixel to pixel
        metab_data = abs(handles.d.carbon_recon.image);

        % take max over timesteps
        if (ndims(metab_data) >= 6)
            metab_data = max(metab_data,[],6);
        end
        % take max over coils
        if (ndims(metab_data) >= 5)
            metab_data = max(metab_data,[],5);
        end
        % but not over slices, as each should get its own frequency maps


        % search for peaks within range +/- handles.p.auto_fit_separation / 2
        % from F1 and F4 metabolite frequencies.
        search_radius_hz = handles.p.auto_fit_separation / 2;
        df = handles.p.hz(2) - handles.p.hz(1);
        if (df > 0)
            search_radius_bins = ceil(search_radius_hz / df);
        else
            search_radius_bins = 10;
        end

        f1_centre_bin = FreqToSliderIdx(handles.p.f1_val, handles);
        f4_centre_bin = FreqToSliderIdx(handles.p.f4_val, handles);
        bin_min = 1;
        bin_max = length(handles.p.hz);

        f1_search_low = max(bin_min, min(bin_max, f1_centre_bin - search_radius_bins));
        f1_search_high = max(bin_min, min(bin_max, f1_centre_bin + search_radius_bins));
        f4_search_low = max(bin_min, min(bin_max, f4_centre_bin - search_radius_bins));
        f4_search_high = max(bin_min, min(bin_max, f4_centre_bin + search_radius_bins));

        %for i = 1:size(metab_data,1)
        %    for j = 1:size(metab_data,2)

        %[centres, heights, widths] = FitPeakNear(pixel_spectrum, peak_search_centres, peak_search_ranges, handles)


        % todo: peak fitting within range...

        [~,f1_max_subidx] = max(metab_data(:,:,f1_search_low:f1_search_high,:),[],3);
        [~,f4_max_subidx] = max(metab_data(:,:,f4_search_low:f4_search_high,:),[],3);

        handles.d.carbon_image_freq1_idx = f1_max_subidx + f1_search_low - 1;
        handles.d.carbon_image_freq4_idx = f4_max_subidx + f4_search_low - 1;
    end
    
    % restore or set pointer position
    res_consistent = 0;
    if (saved_old_pointer_pos)
        if (old_carbon_res(1) == size(handles.d.carbon_recon.image,1) && ...
            old_carbon_res(2) == size(handles.d.carbon_recon.image,2))
            res_consistent = 1;
        end
    end
    
    if (res_consistent)
        handles.p.pointer2d = old_pointer2d;
        
    elseif (saved_old_pointer_pos)
        % if resolution changed, adjust pointer position proportionately
        handles.p.pointer2d = round(old_pointer2d .* handles.p.carbon_recon_resolution ./ old_carbon_res);
        
        % but impose limits based on actual size of data now...
        if (handles.p.pointer2d(1) > size(handles.d.carbon_recon.image,1))
            handles.p.pointer2d(1) = size(handles.d.carbon_recon.image,1);
        end
        if (handles.p.pointer2d(1) < 1)
            handles.p.pointer2d(1) = 1;
        end
        if (handles.p.pointer2d(2) > size(handles.d.carbon_recon.image,1))
            handles.p.pointer2d(2) = size(handles.d.carbon_recon.image,1);
        end
        if (handles.p.pointer2d(2) < 1)
            handles.p.pointer2d(2) = 1;
        end
        
    else
        % set mouse pointer to the center of the proton and carbon image
        handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
        handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
    end
    
    % update handles and display figure
    guidata(hObject,handles);
    plot4d_plot(handles)
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% create functions                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function edit_fid_window_high_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_fid_window_low_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_timestep_low_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_timestep_high_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_timestep_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_window_low_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_window_high_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_window_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_f1_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_f2_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_f3_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_f4_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_f1_ppm_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_f2_ppm_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_f3_ppm_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_f4_ppm_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_f1_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function slider_f2_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function slider_f3_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function slider_f4_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_lac_pyr_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_ala_pyr_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_carbon_file_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_proton_file_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_slice_carbon_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_slice_proton_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_slice_carbon_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_slice_proton_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_flipangle_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_repetitiontime_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_resolution_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_FOV_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_t1_metabolite_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_freq_low_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_freq_high_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_freq_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_scalingfactor_f1_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_carbon_shift_x_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_carbon_shift_y_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_roi_kpyrlac_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_roi_kpyrala_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_coil_carbon_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_coil_carbon_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_fit_threshold_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_plot_freq_min_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_plot_freq_max_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_phase1_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_phase0_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_fit_separation_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_plotted_spectrum_as_text_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_intensity_shift_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_broadening_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_output_value_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function slider_proton_overlay_alpha_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end

function edit_alpha_threshold_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_total_signal_threshold_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_resolution2_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function edit_FOV2_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unused functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function edit_plotted_spectrum_as_text_Callback(hObject, eventdata, handles)
    % do nothing

function edit_output_value_Callback(hObject, eventdata, handles)
    % do nothing


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Utility
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function idx = FreqToSliderIdx(freq_in_hz, handles)
    % convert frequency into index on slider
    [~, idxs] = min(abs(handles.p.hz - freq_in_hz));
    idx = idxs(1);

function pdf = Cauchy(x0, gamma, numPoints)
    x = 1:numPoints;
    pdf = 1 ./ (pi*gamma*( (x - x0).^2 + gamma*gamma ));

    
    

function create_pH_map_Callback(hObject, eventdata, handles)
    PlotNothing(handles)
    handles.p.option_plot_pH_map = 1;
    handles.p.option_plot_pH_map_mean = 1;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.fit_current_spectrum = 0;
    
    volume = abs(handles.d.carbon_recon.image);
    %workaround: Only do pH-map for first time step, Further coding needed!
    %2020.04.26 - Martin G.:  start
    volume = volume(:,:,:,1,1,1);
    %2020.04.26 - Martin G.:  end
    Calculate_pH_Fit(volume, hObject, handles);
    handles.d.carbon_recon.ppm_padded = handles.d.carbon_recon.hz_padded / handles.p.reference_freq + handles.p.working_freq_ppm;
    handles.d.carbon_recon.volume = volume;
    
    guidata(hObject,handles);
    plot4d_plot(handles)  
    
    
function pushbutton_FitCurrentSpectrum_Callback(hObject, eventdata, handles) 
    option_intensity = handles.p.option_plot_intensity;
    option_complex = handles.p.option_plot_complex;
    option_real = handles.p.option_plot_real;
    option_phase = handles.p.option_plot_phase;
    PlotNothing(handles)
    handles.p.option_plot_pH_map = 0;
    [abs_spectrum, complex_spectrum] = GetMetabSpectrum(handles);
    handles.p.option_plot_intensity = option_intensity;
    handles.p.option_plot_complex = option_complex;
    handles.p.option_plot_real = option_real;
    handles.p.option_plot_phase = option_phase;
    handles.p.fit_current_spectrum = 1;
    handles.p.option_plot_pH_map = 1;
    handles.p.option_plot_pH_map_compartment = 1;
    handles.p.option_plot_pH_map_mean = 0;
    if handles.p.option_plot_real || handles.p.option_plot_complex
        volume = real(complex_spectrum);
    elseif (handles.p.option_plot_intensity) || (handles.p.option_plot_pH_map)
        volume = abs_spectrum;
    else
        disp('The chosen plot-option does not provide a spectrum suitable for fitting')
        return
    end
    handles.d.carbon_recon.ppm_padded = handles.d.carbon_recon.hz_padded / handles.p.reference_freq + handles.p.working_freq_ppm;
 
    if median(volume) < 0
        warning('please apply intensity shift before pH refitting of this specturm in order avoid negative baseline!') 
        return
    end
    volume = reshape(volume,1,1,max(size(volume)));
    Calculate_pH_Fit(volume, hObject, handles);
    handles.d.carbon_recon.single_voxel_volume = volume;
    
    disp('absolute peak intensities from current spectrum:')
    disp('[ZAmax1 ZAmax2 Urea ZA5_65 ZA1_65 ZA5_70 ZA1_70 ZA5_74 ZA1_74 PPH5]')
    disp(handles.p.spec_peak_val);
    disp('');
    disp('fit peak amplitudes from current spectrum:')
    disp('[ZAmax1 ZAmax2 Urea ZA5_65 ZA1_65 ZA5_70 ZA1_70 ZA5_74 ZA1_74 PPH5]')
    disp(handles.p.spec_peak_fit_amp);
    
    guidata(hObject,handles);
    plot4d_plot(handles)  
    
    
function Calculate_pH_Fit(data_in, hObject, handles)
    AI = 1;
    if AI == 0
        volume = data_in;
        work_freq = handles.p.reference_freq + (handles.p.reference_freq * handles.p.working_freq_ppm *1e-6);
        wf = round(work_freq * 1e6);
        hztoppm = wf / 1e6;
        ind2ppm = abs((handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1))) / hztoppm;
        %spec_axis_ppm = handles.d.carbon_recon.hz_padded ./ hztoppm;
        %spec_sum = squeeze(sum(volume,3));
        m_min = 1; m_max = size(volume,1);
        n_min = 1; n_max = size(volume,2);

        %warnme = 0;
        pphtreatment = 0;
        debughide = 1;  %set to zero if output of fitting results is desired

        % variable to define minimum prominence so that a peak is detected in findpeaks. relative to the highest signal in the
        % entire spectrum
        % handles.p.noise = mean(mean(mean(volume(:,:,round(0.95*size(volume,3)):end))));
        handles.p.noise = zeros(m_max, n_max);                                                               %03.04.2020, added: replace single noise value by noise map for individual voxel noise 
        min_peak_prominence = zeros(m_max, n_max);                                                           %03.04.2020, added: replace single noise value by noise map for individual voxel noise
        min_peak_height = zeros(m_max, n_max);                                                               %03.04.2020, added: replace single noise value by noise map for individual voxel noise
        min_peak_prominence_urea = zeros(m_max, n_max);                                                      %03.04.2020, added: replace single noise value by noise map for individual voxel noise
        for m = m_min:m_max
            for n= n_min:n_max
                handles.p.noise(m,n) = mean([mean(volume(m,n,1:round(0.05*size(volume,3)))) mean(volume(m,n,round(0.95*size(volume,3)):end))]); %old definition before 01.07.2020
                handles.p.noise(m,n) = mean([rms(volume(m,n,1:round(0.05*size(volume,3)))) rms(volume(m,n,round(0.95*size(volume,3)):end))]); %new definition after 01.07.2020
                %handles.p.noise(m,n) = mean([std(volume(m,n,1:round(0.05*size(volume,3)))) std(volume(m,n,round(0.95*size(volume,3)):end))]); %alternative definition of noise via standard-deviation of noisy spectrum a both ends
            end
        end

        min_peak_prominence = handles.p.pH_fit_prominence*handles.p.noise;                                  %06.08.2019: Martin G.: initially set to 0.05;         
        min_peak_height = handles.p.pH_fit_threshold*handles.p.noise;                                       %16.10.2019: Martin G.: added, set a minimium height for the peak to be found
        min_peak_prominence_urea = handles.p.pH_fit_prominence*handles.p.noise;                              %06.08.2019: Martin G.: initially set to 0.05;

        % find the maximum ZA signal in the spectrum
        left_half = round(size(volume,3)/2); %left_third = round(size(handles.volume,3)/3); %06.08.2019: Martin G.: look for Urea in left half, not only left third; 
        max_signal = max(max(max(volume)));

        speclength = size(volume,3);

        mypeakcolor = {'','','black','blue','blue','green','green','red','red','black'};
        mypeakalpha = [ 0, 0,    0.3,   0.5,   0.5,    0.7,    0.7,  0.5,  0.5,    0.3];

        fprintf('peak   search started ')
        for m = m_min:m_max
            fprintf('.')
            for n= n_min:n_max
                if (handles.p.fit_current_spectrum)
                % set everything to zero for initialization
                    handles.p.spec_peak_pos(1:3)=0; 
                    handles.p.spec_peak_val(1:3)=0;
                    handles.p.spec_peak_wid(1:3)=0;
                else
                    handles.p.peak_pos(m,n,1:3)=0;
                    handles.p.peak_val(m,n,1:3)=0;
                    handles.p.peak_wid(m,n,1:3)=0;
                end
                % start finding peaks
                specatpoint = squeeze(volume(m,n,:));

                % find the urea peak by taking the biggest peak in the left third of the spectrum
                [urea_amps,urea_locs,urea_widths,~] = findpeaks(specatpoint(1:left_half),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence_urea(m,n),'SortStr','descend','WidthReference','halfheight');  %%06.08.2019: Martin G.: MinPeakProminence replaced by 1.5 of Average signal across all MRSI data, 

                if (~isempty(urea_amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(3) = urea_locs(1);  % Urea 
                        handles.p.spec_peak_val(3) = urea_amps(1);  % Urea
                        handles.p.spec_peak_wid(3) = urea_widths(1);% Urea
                    else
                        handles.p.peak_pos(m,n,3) = urea_locs(1);  % Urea 
                        handles.p.peak_val(m,n,3) = urea_amps(1);  % Urea
                        handles.p.peak_wid(m,n,3) = urea_widths(1);% Urea
                    end
                end

                % find the two ZA peaks (the most prominent peaks in the right two thirds of the spectrum)
                [pks,locs,widths,prominence] = findpeaks(specatpoint(left_half:end),'MinPeakHeight',min_peak_height(m,n),'MinPeakDistance',round(1/ind2ppm),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight'); %%06.08.2019: Martin G.: Minimum Peak Distance Added (1 ppm)

                % do not use the rightmost peak if there are more than two and if it is not the most prominent one
                % in this case it is most likely a peak belonging to parapyruvate hydrate
                % this data is from \project-zymonic\data\laurel\opt-topspin-data-guest-nmr\fs_20140115_pHseries (~pH 8)
                % --------------------------------------------- %
                % ppm   0     6.5  10.5  12.5  13.5  16.5 19.5  %
                % name  urea  pp1  za1   pph   za5   pph  pp5   %
                % --------------------------------------------- %
                % this behaviour can be deactivated by actively setting pphtreatment to 0
                if (length(pks) > 2) && (pphtreatment == 1)

                    % take the three largest ones
                    pks_max   (1:3) = pks       (1:3); 
                    locs_max  (1:3) = locs      (1:3);
                    widths_max(1:3) = widths    (1:3);
                    proms_max (1:3) = prominence(1:3);            

                    % sort the three largest peaks by position
                    [~,ind] = sort(locs_max,'descend');
                    pks_max   (1:3) = pks_max   (ind(1:3)); 
                    locs_max  (1:3) = locs_max  (ind(1:3));
                    widths_max(1:3) = widths_max(ind(1:3));
                    proms_max (1:3) = proms_max (ind(1:3));

                    % check whether the right most peak is smaller than the middle peak.
                    % this means, that the right most peak is parapyruvate hydrate and not zymonic acid
                    % in this case, exclude the right most peak.
                    if (proms_max(1) < proms_max(2) )
                        if (handles.fit_current_spectrum)
                            % save the data of peaks in positions 1 and 2 for later
                            handles.p.spec_peak_pos(1) = left_half + locs_max(2) - 1; % ZA position 5
                            handles.p.spec_peak_pos(2) = left_half + locs_max(3) - 1; % ZA position 1
                            handles.p.spec_peak_val(1) = pks_max(2);
                            handles.p.spec_peak_val(2) = pks_max(3);
                            handles.p.spec_peak_wid(1) = widths_max(2);
                            handles.p.spec_peak_wid(2) = widths_max(3);
                        else
                            % save the data of peaks in positions 1 and 2 for later
                            handles.p.peak_pos(m,n,1) = left_half + locs_max(2) - 1; % ZA position 5
                            handles.p.peak_pos(m,n,2) = left_half + locs_max(3) - 1; % ZA position 1
                            handles.p.peak_val(m,n,1) = pks_max(2);
                            handles.p.peak_val(m,n,2) = pks_max(3);
                            handles.p.peak_wid(m,n,1) = widths_max(2);
                            handles.p.peak_wid(m,n,2) = widths_max(3);
                        end

                    else
                        if (handles.fit_current_spectrum)
                            handles.p.spec_peak_pos(1) = left_half + locs_max(1) - 1; % ZA position 5
                            handles.p.spec_peak_pos(2) = left_half + locs_max(2) - 1; % ZA position 1
                            handles.p.spec_peak_val(1) = pks_max(1);
                            handles.p.spec_peak_val(2) = pks_max(2);
                            handles.p.spec_peak_wid(1) = widths_max(1);
                            handles.p.spec_peak_wid(2) = widths_max(2); 
                        else
                            % save the data of peaks in positions 1 and 2 for later
                            handles.p.peak_pos(m,n,1) = left_half + locs_max(1) - 1; % ZA position 5
                            handles.p.peak_pos(m,n,2) = left_half + locs_max(2) - 1; % ZA position 1
                            handles.p.peak_val(m,n,1) = pks_max(1);
                            handles.p.peak_val(m,n,2) = pks_max(2);
                            handles.p.peak_wid(m,n,1) = widths_max(1);
                            handles.p.peak_wid(m,n,2) = widths_max(2); 
                        end
                    end

                elseif length(pks) > 1
                    % sort by size of peaks and take the two biggest peaks
                    [~,ind] = sort(pks,'descend'); % can change this to sort bei peak prominence if desired
                    pks_max    = pks(ind(1:2)); 
                    locs_max   = locs(ind(1:2));
                    widths_max = widths(ind(1:2));

                    % sort the two peaks by position
                    [~,ind] = sort(locs_max,'descend');
                    pks_max(1:2)    = pks_max(ind(1:2)); 
                    locs_max(1:2)   = locs_max(ind(1:2));
                    widths_max(1:2) = widths_max(ind(1:2));

                    % save the data for later
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(1) = left_half + locs_max(1) - 1; % ZA position 5
                        handles.p.spec_peak_pos(2) = left_half + locs_max(2) - 1; % ZA position 1
                        handles.p.spec_peak_val(1) = pks_max(1);
                        handles.p.spec_peak_val(2) = pks_max(2);
                        handles.p.spec_peak_wid(1) = widths_max(1);
                        handles.p.spec_peak_wid(2) = widths_max(2);
                    else
                        handles.p.peak_pos(m,n,1) = left_half + locs_max(1) - 1; % ZA position 5
                        handles.p.peak_pos(m,n,2) = left_half + locs_max(2) - 1; % ZA position 1
                        handles.p.peak_val(m,n,1) = pks_max(1);
                        handles.p.peak_val(m,n,2) = pks_max(2);
                        handles.p.peak_wid(m,n,1) = widths_max(1);
                        handles.p.peak_wid(m,n,2) = widths_max(2);
                    end
                end
            end
        end
        fprintf(' peak search finished.\n')

        x0 = 7;

        % these are the ranges in ppm for pH~6.5 (index 1 and 2), pH~7.0 (index 3 and 4) and pH~7.4 (index 5 and 6)
        % in these ranges, findpeaks first looks for the highest peaks and then the fit varies the position within this same range
        %range_ZA1_ppm  = [8.58 10.7  10.7  11.8 11.8 12.8]; % original: [ 9.3 10.6 10.9 11.9 12.0  12.8];
        %range_ZA5_ppm  = [12.8 13.65 13.65 14.22 14.22 14.9]; % original: [12.8 13.6 13.7 14.1 14.15 15.1];
        %range_ZA1_ppm  = [9.09 11.07 11.07 12.30 12.30 13.18]; %last: 13.18 for very basic subjects. 12.85 otherwise!!!!  original: [ 9.3 10.6 10.9 11.9 12.0  12.8];    %new ranges by Martin G on 16.03.2020,
        %range_ZA5_ppm  = [13.2 13.85 13.85 14.52 14.52 14.91]; % original: [12.8 13.6 13.7 14.1 14.15 15.1];  %new ranges by Martin G on 16.03.2020

        range_ZA1_ppm  = [9.086 10.6908 10.6908 11.791 11.791 13.177]; %last: 13.18 for very basic subjects. 12.85 otherwise!!!!  original: [ 9.3 10.6 10.9 11.9 12.0  12.8];    %new ranges by Martin G on 16.03.2020,
        range_ZA5_ppm  = [12.8559 13.66 13.66 14.2112 14.2112 14.9057];
        %corresponds to pH values: [6.00-6.77 : 6.77-7.15 : 7.15-7.90]
        %corresponds to pH values: [5.99-6.77 : 6.77-7.15 : 7.15-7.91]
        range_PPH5_ppm = [14.9 16.1];   %2019.10.17: previously [15.1205 16.1]
        range_Urea_ppm = [-2 2];        %2019.10.17: previously [-1 1]

        % provide the same ranges in a more standardized and useful format for later
        % in Order urea, pH~6.5 (ZA5,ZA1), pH~7.0 (ZA5,ZA1), pH~7.4 (ZA5,ZA1), PPH5
        range_ppm_low  = [0 0 range_Urea_ppm(1) range_ZA5_ppm(1) range_ZA1_ppm(1) range_ZA5_ppm(3) range_ZA1_ppm(3) range_ZA5_ppm(5) range_ZA1_ppm(5) range_PPH5_ppm(1)];
        range_ppm_high = [0 0 range_Urea_ppm(2) range_ZA5_ppm(2) range_ZA1_ppm(2) range_ZA5_ppm(4) range_ZA1_ppm(4) range_ZA5_ppm(6) range_ZA1_ppm(6) range_PPH5_ppm(2)];


        % d) Find ZA1 and/or ZA5 peak for pH~6.5

        % define the regions in ppm where we expect ZA5 and ZA1 in the spectrum for pH 6.5
        ppm_pH65_ZA5_low  = range_ZA5_ppm(1);       ppm_pH65_ZA1_low  =  range_ZA1_ppm(1);
        ppm_pH65_ZA5_high = range_ZA5_ppm(2);       ppm_pH65_ZA1_high =  range_ZA1_ppm(2);

        fprintf('pH 6.5 search started ')
        for m = m_min:m_max
            fprintf('.')
            for n= n_min:n_max

                % calculate spectrum and length of spectrum in this pixel
                specatpoint = squeeze(volume(m,n,:));
                speclength = length(specatpoint);

                % set everything to zero for initialization (index 4: ZA5 pH 6.5 - index 5: ZA1 pH 6.5)
                if (handles.p.fit_current_spectrum)
                    handles.p.spec_peak_pos(4:5)=0; % peak position
                    handles.p.spec_peak_val(4:5)=0; % value at peak maximum
                    handles.p.spec_peak_wid(4:5)=0; % peak width
                    handles.p.spec_peak_prm(4:5)=0; % peak prominence
                else
                    handles.p.peak_pos(m,n,4:5)=0; % peak position
                    handles.p.peak_val(m,n,4:5)=0; % value at peak maximum
                    handles.p.peak_wid(m,n,4:5)=0; % peak width
                    handles.p.peak_prm(m,n,4:5)=0; % peak prominence
                end

                % define the regions where to look for the ZA5 and ZA1 peaks for pH~6.5 based on where the urea peak was found (peak_pos(m,n,3) > 0)
                if(handles.p.fit_current_spectrum)
                    if (handles.p.spec_peak_pos(3) > 0)
                        spec_axis_ppm = (-handles.p.spec_peak_pos(3)+1 : speclength - handles.p.spec_peak_pos(3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1)) / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end
                else
                    if (handles.p.peak_pos(m,n,3) > 0)
                        spec_axis_ppm = (-handles.p.peak_pos(m,n,3)+1 : speclength - handles.p.peak_pos(m,n,3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1)) / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end   
                end
                index_pH65_ZA5_low  = find(spec_axis_ppm > ppm_pH65_ZA5_low & spec_axis_ppm < ppm_pH65_ZA5_high,1,'first');
                index_pH65_ZA5_high = find(spec_axis_ppm > ppm_pH65_ZA5_low & spec_axis_ppm < ppm_pH65_ZA5_high,1,'last' );
                index_pH65_ZA1_low  = find(spec_axis_ppm > ppm_pH65_ZA1_low & spec_axis_ppm < ppm_pH65_ZA1_high,1,'first');
                index_pH65_ZA1_high = find(spec_axis_ppm > ppm_pH65_ZA1_low & spec_axis_ppm < ppm_pH65_ZA1_high,1,'last' );

                % find the ZA5 peak in the predefined regions for pH~6.5 by taking the most prominent peak in the area
                [amps,locs,widths,prmnces] = findpeaks(specatpoint(index_pH65_ZA5_low-2:index_pH65_ZA5_high+2),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight');
                if (~isempty(amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(4) = index_pH65_ZA5_low-2 + locs(1) - 1;   
                        handles.p.spec_peak_val(4) = amps(1);  
                        handles.p.spec_peak_wid(4) = widths(1);
                        handles.p.spec_peak_prm(4) = prmnces(1);
                    else
                        handles.p.peak_pos(m,n,4) = index_pH65_ZA5_low-2 + locs(1) - 1;   
                        handles.p.peak_val(m,n,4) = amps(1);  
                        handles.p.peak_wid(m,n,4) = widths(1);
                        handles.p.peak_prm(m,n,4) = prmnces(1);
                    end
                end

                % find the ZA1 peak in the predefined regions for pH~6.5 by taking the most prominent peak in the area
                [amps,locs,widths,prmnces] = findpeaks(specatpoint(index_pH65_ZA1_low-2:index_pH65_ZA1_high+2),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight');
                if (~isempty(amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(5) = index_pH65_ZA1_low-2 + locs(1) - 1;   
                        handles.p.spec_peak_val(5) = amps(1);  
                        handles.p.spec_peak_wid(5) = widths(1);
                        handles.p.spec_peak_prm(5) = prmnces(1);
                    else
                        handles.p.peak_pos(m,n,5) = index_pH65_ZA1_low-2 + locs(1) - 1;   
                        handles.p.peak_val(m,n,5) = amps(1);  
                        handles.p.peak_wid(m,n,5) = widths(1);
                        handles.p.peak_prm(m,n,5) = prmnces(1);
                    end
                end
            end
        end
        fprintf(' peak search finished.\n')

        % c) Find ZA1 and/or ZA5 peak for pH~7.0

        % define the regions in ppm where we expect ZA5 and ZA1 in the spectrum for pH 6.5
        ppm_pH70_ZA5_low  = range_ZA5_ppm(3);       ppm_pH70_ZA1_low  = range_ZA1_ppm(3);
        ppm_pH70_ZA5_high = range_ZA5_ppm(4);       ppm_pH70_ZA1_high = range_ZA1_ppm(4);

        fprintf('pH 7.0 search started ')
        for m = m_min:m_max
            fprintf('.')
            for n= n_min:n_max

                % calculate spectrum and length of spectrum in this pixel
                specatpoint = squeeze(volume(m,n,:));
                speclength = length(specatpoint);

                % set everything to zero for initialization (index 6: ZA5 pH 7.0 - index 7: ZA1 pH 7.0)
                if (handles.p.fit_current_spectrum)
                    handles.p.spec_peak_pos(6:7)=0; % peak position         [index]
                    handles.p.spec_peak_val(6:7)=0; % value at peak maximum [a.u. ]
                    handles.p.spec_peak_wid(6:7)=0; % peak width            [index]
                    handles.p.spec_peak_prm(6:7)=0; % peak prominence       [a.u. ]
                else
                    handles.p.peak_pos(m,n,6:7)=0; % peak position         [index]
                    handles.p.peak_val(m,n,6:7)=0; % value at peak maximum [a.u. ]
                    handles.p.peak_wid(m,n,6:7)=0; % peak width            [index]
                    handles.p.peak_prm(m,n,6:7)=0; % peak prominence       [a.u. ]
                end

                % define the regions where to look for the ZA5 and ZA1 peaks for pH~7.0 based on where the urea peak was found (peak_pos(m,n,3) > 0)
                if (handles.p.fit_current_spectrum)
                    if (handles.p.spec_peak_pos(3) > 0)
                        spec_axis_ppm = (-handles.p.spec_peak_pos(3)+1 : speclength - handles.p.spec_peak_pos(3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1)) / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end    
                else
                    if (handles.p.peak_pos(m,n,3) > 0)
                        spec_axis_ppm = (-handles.p.peak_pos(m,n,3)+1 : speclength - handles.p.peak_pos(m,n,3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1)) / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end    
                end
                index_pH70_ZA5_low  = find(spec_axis_ppm > ppm_pH70_ZA5_low & spec_axis_ppm < ppm_pH70_ZA5_high,1,'first');
                index_pH70_ZA5_high = find(spec_axis_ppm > ppm_pH70_ZA5_low & spec_axis_ppm < ppm_pH70_ZA5_high,1,'last' );
                index_pH70_ZA1_low  = find(spec_axis_ppm > ppm_pH70_ZA1_low & spec_axis_ppm < ppm_pH70_ZA1_high,1,'first');
                index_pH70_ZA1_high = find(spec_axis_ppm > ppm_pH70_ZA1_low & spec_axis_ppm < ppm_pH70_ZA1_high,1,'last' );

                % find the ZA5 peak in the predefined regions for pH~7.0 by taking the most prominent peak in the area
                [amps,locs,widths,prmnces] = findpeaks(specatpoint(index_pH70_ZA5_low-2:index_pH70_ZA5_high+2),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight');
                if (~isempty(amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(6) = index_pH70_ZA5_low-2 + locs(1) - 1;   
                        handles.p.spec_peak_val(6) = amps(1);  
                        handles.p.spec_peak_wid(6) = widths(1);
                        handles.p.spec_peak_prm(6) = prmnces(1);
                        if handles.p.spec_peak_pos(6) == handles.p.spec_peak_pos(4) %if ZA5 peak found in 7.0-compartment and is idential with the one from the 6.5-compartment, erase it in the 6.5-compartment
                            handles.p.spec_peak_pos(4) = 0;
                            handles.p.spec_peak_val(4) = 0;
                            handles.p.spec_peak_wid(4) = 0;
                            handles.p.spec_peak_prm(4) = 0;
                        end
                    else
                        handles.p.peak_pos(m,n,6) = index_pH70_ZA5_low-2 + locs(1) - 1;   
                        handles.p.peak_val(m,n,6) = amps(1);  
                        handles.p.peak_wid(m,n,6) = widths(1);
                        handles.p.peak_prm(m,n,6) = prmnces(1);
                        if handles.p.peak_pos(m,n,6) == handles.p.peak_pos(m,n,4) %if ZA5 peak found in 7.0-compartment and is idential with the one from the 6.5-compartment, erase it in the 6.5-compartment
                            handles.p.peak_pos(m,n,4) = 0;
                            handles.p.peak_val(m,n,4) = 0;
                            handles.p.peak_wid(m,n,4) = 0;
                            handles.p.peak_prm(m,n,4) = 0;
                        end
                    end
                end

                % find the ZA1 peak in the predefined regions for pH~7.0 by taking the most prominent peak in the area
                [amps,locs,widths,prmnces] = findpeaks(specatpoint(index_pH70_ZA1_low-2:index_pH70_ZA1_high+2),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight');
                if (~isempty(amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(7) = index_pH70_ZA1_low-2 + locs(1) - 1;   
                        handles.p.spec_peak_val(7) = amps(1);  
                        handles.p.spec_peak_wid(7) = widths(1);
                        handles.p.spec_peak_prm(7) = prmnces(1);
                        if handles.p.spec_peak_pos(7) == handles.p.spec_peak_pos(5) %if ZA1 peak found in 7.0-compartment and is idential with the one from the 6.5-compartment, erase it in the 6.5-compartment
                            handles.p.spec_peak_pos(5) = 0;
                            handles.p.spec_peak_val(5) = 0;
                            handles.p.spec_peak_wid(5) = 0;
                            handles.p.spec_peak_prm(5) = 0;
                        end
                    else
                        handles.p.peak_pos(m,n,7) = index_pH70_ZA1_low-2 + locs(1) - 1;   
                        handles.p.peak_val(m,n,7) = amps(1);  
                        handles.p.peak_wid(m,n,7) = widths(1);
                        handles.p.peak_prm(m,n,7) = prmnces(1);
                        if handles.p.peak_pos(m,n,7) == handles.p.peak_pos(m,n,5) %if ZA1 peak found in 7.0-compartment and is idential with the one from the 6.5-compartment, erase it in the 6.5-compartment
                            handles.p.peak_pos(m,n,5) = 0;
                            handles.p.peak_val(m,n,5) = 0;
                            handles.p.peak_wid(m,n,5) = 0;
                            handles.p.peak_prm(m,n,5) = 0;
                        end
                    end
                end
            end
        end
        fprintf(' peak search finished.\n')

        % f) Find ZA1 and/or ZA5 peak for pH~7.4

        % define the regions in ppm where we expect ZA5 and ZA1 in the spectrum for pH 7.4
        ppm_pH74_ZA5_low  = range_ZA5_ppm(5);       ppm_pH74_ZA1_low  = range_ZA1_ppm(5);
        ppm_pH74_ZA5_high = range_ZA5_ppm(6);       ppm_pH74_ZA1_high = range_ZA1_ppm(6);

        fprintf('pH 7.4 search started ')
        for m = m_min:m_max
            fprintf('.')
            for n= n_min:n_max

                % calculate spectrum and length of spectrum in this pixel
                specatpoint = squeeze(volume(m,n,:));
                speclength = length(specatpoint);

                % set everything to zero for initialization (index 8: ZA5 pH 7.4 - index 9: ZA1 pH 7.4)
                if (handles.p.fit_current_spectrum)
                    handles.p.spec_peak_pos(8:9)=0; % peak position
                    handles.p.spec_peak_val(8:9)=0; % value at peak maximum
                    handles.p.spec_peak_wid(8:9)=0; % peak width
                    handles.p.spec_peak_prm(8:9)=0; % peak prominence
                else
                    handles.p.peak_pos(m,n,8:9)=0; % peak position
                    handles.p.peak_val(m,n,8:9)=0; % value at peak maximum
                    handles.p.peak_wid(m,n,8:9)=0; % peak width
                    handles.p.peak_prm(m,n,8:9)=0; % peak prominence
                end

                % define the regions where to look for the ZA5 and ZA1 peaks for pH~7.4 based on where the urea peak was found (peak_pos(m,n,3) > 0)
                if (handles.p.fit_current_spectrum)
                    if (handles.p.spec_peak_pos(3) > 0)
                        spec_axis_ppm = (-handles.p.spec_peak_pos(3)+1 : speclength - handles.p.spec_peak_pos(3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1)) / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end  
                else
                    if (handles.p.peak_pos(m,n,3) > 0)
                        spec_axis_ppm = (-handles.p.peak_pos(m,n,3)+1 : speclength - handles.p.peak_pos(m,n,3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1)) / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end  
                end
                index_pH74_ZA5_low  = find(spec_axis_ppm > ppm_pH74_ZA5_low & spec_axis_ppm < ppm_pH74_ZA5_high,1,'first');
                index_pH74_ZA5_high = find(spec_axis_ppm > ppm_pH74_ZA5_low & spec_axis_ppm < ppm_pH74_ZA5_high,1,'last' );
                index_pH74_ZA1_low  = find(spec_axis_ppm > ppm_pH74_ZA1_low & spec_axis_ppm < ppm_pH74_ZA1_high,1,'first');
                index_pH74_ZA1_high = find(spec_axis_ppm > ppm_pH74_ZA1_low & spec_axis_ppm < ppm_pH74_ZA1_high,1,'last' );

                % find the ZA5 peak in the predefined regions for pH~7.4 by taking the most prominent peak in the area
                [amps,locs,widths,prmnces] = findpeaks(specatpoint(index_pH74_ZA5_low-2:index_pH74_ZA5_high+2),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight');
                if (~isempty(amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(8) = index_pH74_ZA5_low-2 + locs(1) - 1;   
                        handles.p.spec_peak_val(8) = amps(1);  
                        handles.p.spec_peak_wid(8) = widths(1);
                        handles.p.spec_peak_prm(8) = prmnces(1);
                        if handles.p.spec_peak_pos(8) == handles.p.spec_peak_pos(6) %if ZA5 peak found in 7.4-compartment and is idential with the one from the 7.0-compartment, erase it in the 7.0-compartment
                            handles.p.spec_peak_pos(6) = 0;
                            handles.p.spec_peak_val(6) = 0;
                            handles.p.spec_peak_wid(6) = 0;
                            handles.p.spec_peak_prm(6) = 0;
                        end
                    else
                        handles.p.peak_pos(m,n,8) = index_pH74_ZA5_low-2 + locs(1) - 1;   
                        handles.p.peak_val(m,n,8) = amps(1);  
                        handles.p.peak_wid(m,n,8) = widths(1);
                        handles.p.peak_prm(m,n,8) = prmnces(1);
                        if handles.p.peak_pos(m,n,8) == handles.p.peak_pos(m,n,6) %if ZA5 peak found in 7.4-compartment and is idential with the one from the 7.0-compartment, erase it in the 6.5-compartment
                            handles.p.peak_pos(m,n,6) = 0;
                            handles.p.peak_val(m,n,6) = 0;
                            handles.p.peak_wid(m,n,6) = 0;
                            handles.p.peak_prm(m,n,6) = 0;
                        end
                    end
                end

                % find the ZA1 peak in the predefined regions for pH~7.4 by taking the most prominent peak in the area
                [amps,locs,widths,prmnces] = findpeaks(specatpoint(index_pH74_ZA1_low-2:index_pH74_ZA1_high+2),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight');
                if (~isempty(amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(9) = index_pH74_ZA1_low-2 + locs(1) - 1;   
                        handles.p.spec_peak_val(9) = amps(1);  
                        handles.p.spec_peak_wid(9) = widths(1);
                        handles.p.spec_peak_prm(9) = prmnces(1);
                        if handles.p.spec_peak_pos(9) == handles.p.spec_peak_pos(7) %if ZA1 peak found in 7.4-compartment and is idential with the one from the 7.0-compartment, erase it in the 7.0-compartment
                            handles.p.spec_peak_pos(7) = 0;
                            handles.p.spec_peak_val(7) = 0;
                            handles.p.spec_peak_wid(7) = 0;
                            handles.p.spec_peak_prm(7) = 0;
                        end
                        if handles.p.spec_peak_pos(9) == handles.p.spec_peak_pos(4) %if ZA1 peak found in 7.4-compartment and is idential with the ZA5-peak from the 6.5-compartment, erase it in the ZA5-6.5-compartment
                            handles.p.spec_peak_pos(4) = 0;
                            handles.p.spec_peak_val(4) = 0;
                            handles.p.spec_peak_wid(4) = 0;
                            handles.p.spec_peak_prm(4) = 0;
                        end    
                    else
                        handles.p.peak_pos(m,n,9) = index_pH74_ZA1_low-2 + locs(1) - 1;   
                        handles.p.peak_val(m,n,9) = amps(1);  
                        handles.p.peak_wid(m,n,9) = widths(1);
                        handles.p.peak_prm(m,n,9) = prmnces(1);
                        if handles.p.peak_pos(m,n,9) == handles.p.peak_pos(m,n,7) %if ZA1 peak found in 7.4-compartment and is idential with the one from the 7.0-compartment, erase it in the 6.5-compartment
                            handles.p.peak_pos(m,n,7) = 0;
                            handles.p.peak_val(m,n,7) = 0;
                            handles.p.peak_wid(m,n,7) = 0;
                            handles.p.peak_prm(m,n,7) = 0;
                        end
                        if handles.p.peak_pos(m,n,9) == handles.p.peak_pos(m,n,4) %if ZA1 peak found in 7.4-compartment and is idential with the ZA5-peak from the 6.5-compartment, erase it in the ZA5-6.5-compartment
                            handles.p.peak_pos(m,n,4) = 0;
                            handles.p.peak_val(m,n,4) = 0;
                            handles.p.peak_wid(m,n,4) = 0;
                            handles.p.peak_prm(m,n,4) = 0;
                        end    
                    end
                end
            end
        end
        fprintf(' peak search finished.\n')

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % g) Find PPH5 peak

        % define the regions in ppm where we expect PPH5 in the spectrum
        ppm_PPH5_low  = range_PPH5_ppm(1);
        ppm_PPH5_high = range_PPH5_ppm(2);

        fprintf('PPH5   search started ')
        for m = m_min:m_max
            fprintf('.')
            for n= n_min:n_max

                % calculate spectrum and length of spectrum in this pixel
                specatpoint = squeeze(volume(m,n,:));
                speclength = length(specatpoint);

                % set everything to zero for initialization (index 10: PPH5)
                if (handles.p.fit_current_spectrum)
                    handles.p.spec_peak_pos(10)=0; % peak position
                    handles.p.spec_peak_val(10)=0; % value at peak maximum
                    handles.p.spec_peak_wid(10)=0; % peak width
                    handles.p.spec_peak_prm(10)=0; % peak prominence
                else
                    handles.p.peak_pos(m,n,10)=0; % peak position
                    handles.p.peak_val(m,n,10)=0; % value at peak maximum
                    handles.p.peak_wid(m,n,10)=0; % peak width
                    handles.p.peak_prm(m,n,10)=0; % peak prominence
                end

                % define the regions where to look for the PPH peak based on where the urea peak was found (peak_pos(m,n,3) > 1)
                if (handles.p.fit_current_spectrum)
                    if (handles.p.spec_peak_pos(3) > 0)
                        spec_axis_hz  = (-handles.p.spec_peak_pos(3)+1 : speclength - handles.p.spec_peak_pos(3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
                        spec_axis_ppm = spec_axis_hz / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end  
                else
                    if (handles.p.peak_pos(m,n,3) > 0)
                        spec_axis_hz  = (-handles.p.peak_pos(m,n,3)+1 : speclength - handles.p.peak_pos(m,n,3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
                        spec_axis_ppm = spec_axis_hz / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end    
                end
                index_PPH5_low  = find(spec_axis_ppm > ppm_PPH5_low & spec_axis_ppm < ppm_PPH5_high,1,'first');
                index_PPH5_high = find(spec_axis_ppm > ppm_PPH5_low & spec_axis_ppm < ppm_PPH5_high,1,'last' );

                % find the PPH peak in the predefined regions by taking the most prominent peak in the area
                [amps,locs,widths,prmnces] = findpeaks(specatpoint(index_PPH5_low-1:index_PPH5_high+1),'MinPeakHeight',min_peak_height(m,n),'MinPeakProminence',min_peak_prominence(m,n),'SortStr','descend','WidthReference','halfheight');
                if (~isempty(amps))
                    if (handles.p.fit_current_spectrum)
                        handles.p.spec_peak_pos(10) = index_PPH5_low + locs(1) - 1;   
                        handles.p.spec_peak_val(10) = amps(1);  
                        handles.p.spec_peak_wid(10) = widths(1);
                        handles.p.spec_peak_prm(10) = prmnces(1);
                    else
                        handles.p.peak_pos(m,n,10) = index_PPH5_low + locs(1) - 1;   
                        handles.p.peak_val(m,n,10) = amps(1);  
                        handles.p.peak_wid(m,n,10) = widths(1);
                        handles.p.peak_prm(m,n,10) = prmnces(1);
                    end
                end
            end
        end
        fprintf(' peak search finished.\n')

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % h) Fit all peaks (PPH5, Urea, ZA5 and ZA1 for pH~7.4, pH~7.0, pH~6.5) simultaneously
        %    As peak model we use the absolute value of a Lorentzian peak, see Keeler, Understanding NMR spectroscopy, p. 84
        %    S(f) = A*(FWHM/2)^2 / [(FWHM/2)^2 + (f-F0)^2]
        %    where FWHM and F0 are given in Hz. The equation is derived from |a+ib| = a^2 + b^2 with a and b the real
        %    (adsorption) and imaginary (dispersion) part of the Lorentzian function.

        % create conversion factor from index to Hz and Hz axis starting at zero
        pos2hz = abs(handles.d.carbon_recon.hz_padded(2) - handles.d.carbon_recon.hz_padded(1));
        if (handles.p.fit_current_spectrum)
            handles.p.spec_peak_fnd      = zeros(size(handles.p.spec_peak_pos));        % boolean
            handles.p.spec_peak_fit_amp  = zeros(size(handles.p.spec_peak_pos));        % a.u.
            handles.p.spec_peak_fit_fwhm = zeros(size(handles.p.spec_peak_pos));        % Hz
            handles.p.spec_peak_fit_pos  = zeros(size(handles.p.spec_peak_pos));        % Hz (formerly index)
            handles.p.spec_peak_fit_yoff = 0; % a.u.
            handles.p.spec_peak_fit_spectrum = zeros(size(volume));      % fitted spectrum
        else
            handles.p.peak_fnd      = zeros(size(handles.p.peak_pos));        % boolean
            handles.p.peak_fit_amp  = zeros(size(handles.p.peak_pos));        % a.u.
            handles.p.peak_fit_fwhm = zeros(size(handles.p.peak_pos));        % Hz
            handles.p.peak_fit_pos  = zeros(size(handles.p.peak_pos));        % Hz (formerly index)
            handles.p.peak_fit_yoff = zeros(size(handles.p.peak_pos,1),size(handles.p.peak_pos,2)); % a.u.
            handles.p.peak_fit_spectrum = zeros(size(volume));      % fitted spectrum
        end

        fprintf('peak fitting  started ')
        for m = m_min:m_max
            fprintf('.')
            for n= n_min:n_max

                % calculate Hz and ppm axis based on where the urea peak was found (peak_pos(m,n,3) > 0)
                if (handles.p.fit_current_spectrum)
                    if (handles.p.spec_peak_pos(3) > 0)
                        spec_axis_hz  = (-handles.p.spec_peak_pos(3)+1 : speclength - handles.p.spec_peak_pos(3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
                        spec_axis_ppm = spec_axis_hz / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end
                else
                    if (handles.p.peak_pos(m,n,3) > 0)
                        spec_axis_hz  = (-handles.p.peak_pos(m,n,3)+1 : speclength - handles.p.peak_pos(m,n,3)) * (handles.d.carbon_recon.hz_padded(2)-handles.d.carbon_recon.hz_padded(1));
                        spec_axis_ppm = spec_axis_hz / hztoppm;
                    else
                        spec_axis_ppm = handles.d.carbon_recon.hz_padded / hztoppm;
                    end
                end

                % keep track which peaks have been found in this pixel
                npeaks = 0; b0 = []; pos = []; wid = []; lb = []; ub = [];

                % decide whether to fit the amplitude of the peaks only or whether to fit both amplitude and position (and keep
                % the width constant) or whether to fit both width and amplitude (and keep the position constant)
                % always maximum one of the may be set to 1, otherwise, unexpected behaviour will occur!
                fitpeakamponly = 0;
                fitpeakampandpos = 1;

                % in case that only the amplitude is fitted, all peak widths are set to the one from urea
                if fitpeakamponly == 1
                    error('insert this part from the original reconstruction code if needed....!!!')
                % fit amplitude and peak position, keep peak width constant
                elseif fitpeakampandpos == 1
                    % check whether the Urea peak has been found in this pixel
                    if (handles.p.fit_current_spectrum)
                        if handles.p.spec_peak_pos(3) > 0
                            spec_max = max(squeeze(volume(m,n,:)));
                            for k=3:10
                                if handles.p.spec_peak_pos(k) > 0
                                    handles.p.spec_peak_fnd(k) = 1;
                                    npeaks = npeaks+1;
                                    b0(2*npeaks-1)  = handles.p.spec_peak_val(k);
                                    wid(npeaks)     = handles.p.spec_peak_wid(3) * pos2hz; % set all peak widths to the one from Urea!!!
                                    b0(2*npeaks)    = spec_axis_hz(handles.p.spec_peak_pos(k));
                                    % create lower and upper bounds for amplitude (0 and max signal in spectrum)
                                    lb(2*npeaks-1) = 0;
                                    ub(2*npeaks-1) = spec_max*1.1;
                                    % create lower and upper bounds for peak positions from range_ZA1_ppm, range_ZA5_ppm and range_PPH5_ppm
                                    lb(2*npeaks) = range_ppm_low(k) * hztoppm;
                                    ub(2*npeaks) = range_ppm_high(k)* hztoppm;
                                    %pos(npeaks) = handles.spec_axis_hz(handles.peak_pos(m,n,k));
                                    %if x>0 && y>0, plot(spec_axis_ppm,peak_model(b0(2*npeaks-1), b0(2*npeaks),pos(npeaks),handles.spec_axis_hz)/max_signal,'r'), end;
                                    %line([spec_axis_ppm(handles.peak_pos(m,n,k)) spec_axis_ppm(handles.peak_pos(m,n,k))],[0 b0(2*npeaks-1)]/max_signal,'Color','r','LineWidth',2)
                                end
                            end
                            % add an additional parameter in order to fit the vertical offset
                            b0(2*npeaks+1) = 0; lb(2*npeaks+1) = 0; ub(2*npeaks+1) = spec_max; 
                            % create fit function with right number of peaks, peak collection depends on number of peaks found in this pixel
                            % the positions of the peaks are fixed, only widths and heights can be adjusted.
                            peak_collection_fit = @(b,x)peak_collection_ampandpos(b,wid,x); % 
                            % perform nonlinear fit
                            bfit = lsqcurvefit(peak_collection_fit,b0,spec_axis_hz,squeeze(volume(m,n,:))',lb,ub,optimoptions('lsqcurvefit','Display','none'));     
                            % save fitting results
                            npeaks = 0;
                            handles.p.spec_peak_fit_yoff = bfit(end);                                     % a.u.
                            handles.p.spec_peak_fit_spectrum(:) = ones(size(handles.d.carbon_recon.hz_padded))*handles.p.spec_peak_fit_yoff;
                            for k = find(handles.p.spec_peak_fnd(:))'
                                npeaks = npeaks+1;
                                handles.p.spec_peak_fit_amp(k) = bfit(2*npeaks-1);                        % a.u.
                                handles.p.spec_peak_fit_fwhm(k) = handles.p.spec_peak_wid(3) * pos2hz;        % Hz
                                handles.p.spec_peak_fit_pos (k) = bfit(2*npeaks);                          % Hz
                                peak_single = peak_model(handles.p.spec_peak_fit_amp(k), handles.p.spec_peak_fit_fwhm(k), handles.p.spec_peak_fit_pos(k), spec_axis_hz);
                                handles.p.spec_peak_fit_spectrum(:) = squeeze(handles.p.spec_peak_fit_spectrum(:)).' + peak_single;   
                            end                
                        else
                            % if no Urea peak has been found, we don't perform any fitting in this case
                            handles.p.peak_fnd(m,n,1:10) = 0;
                        end
                    else
                        if handles.p.peak_pos(m,n,3) > 0
                            spec_max = max(squeeze(volume(m,n,:)));
                            for k=3:10
                                if handles.p.peak_pos(m,n,k) > 0
                                    handles.p.peak_fnd(m,n,k) = 1;
                                    npeaks = npeaks+1;
                                    b0(2*npeaks-1)  = handles.p.peak_val(m,n,k);
                                    wid(npeaks)     = handles.p.peak_wid(m,n,3) * pos2hz; % set all peak widths to the one from Urea!!!
                                    b0(2*npeaks)    = spec_axis_hz(handles.p.peak_pos(m,n,k));
                                    % create lower and upper bounds for amplitude (0 and max signal in spectrum)
                                    lb(2*npeaks-1) = 0;
                                    ub(2*npeaks-1) = spec_max*1.1;
                                    % create lower and upper bounds for peak positions from range_ZA1_ppm, range_ZA5_ppm and range_PPH5_ppm
                                    lb(2*npeaks) = range_ppm_low(k) * hztoppm;
                                    ub(2*npeaks) = range_ppm_high(k)* hztoppm;
                                    %pos(npeaks) = handles.spec_axis_hz(handles.peak_pos(m,n,k));
                                    %if x>0 && y>0, plot(spec_axis_ppm,peak_model(b0(2*npeaks-1), b0(2*npeaks),pos(npeaks),handles.spec_axis_hz)/max_signal,'r'), end;
                                    %line([spec_axis_ppm(handles.peak_pos(m,n,k)) spec_axis_ppm(handles.peak_pos(m,n,k))],[0 b0(2*npeaks-1)]/max_signal,'Color','r','LineWidth',2)
                                end
                            end
                            % add an additional parameter in order to fit the vertical offset
                            b0(2*npeaks+1) = 0; lb(2*npeaks+1) = 0; ub(2*npeaks+1) = spec_max; 
                            % create fit function with right number of peaks, peak collection depends on number of peaks found in this pixel
                            % the positions of the peaks are fixed, only widths and heights can be adjusted.
                            peak_collection_fit = @(b,x)peak_collection_ampandpos(b,wid,x); % 
                            % perform nonlinear fit
                            bfit = lsqcurvefit(peak_collection_fit,b0,spec_axis_hz,squeeze(volume(m,n,:))',lb,ub,optimoptions('lsqcurvefit','Display','none'));     
                            % save fitting results
                            npeaks = 0;
                            handles.p.peak_fit_yoff(m,n) = bfit(end);                                     % a.u.
                            handles.p.peak_fit_spectrum(m,n,:) = ones(size(handles.d.carbon_recon.hz_padded))*handles.p.peak_fit_yoff(m,n);
                            for k = find(handles.p.peak_fnd(m,n,:))'
                                npeaks = npeaks+1;
                                handles.p.peak_fit_amp (m,n,k) = bfit(2*npeaks-1);                        % a.u.
                                handles.p.peak_fit_fwhm(m,n,k) = handles.p.peak_wid(m,n,3) * pos2hz;        % Hz
                                handles.p.peak_fit_pos (m,n,k) = bfit(2*npeaks);                          % Hz
                                peak_single = peak_model(handles.p.peak_fit_amp(m,n,k), handles.p.peak_fit_fwhm(m,n,k), handles.p.peak_fit_pos(m,n,k), spec_axis_hz);
                                handles.p.peak_fit_spectrum(m,n,:) = squeeze(handles.p.peak_fit_spectrum(m,n,:)).' + peak_single;   
                            end                
                        else
                            % if no Urea peak has been found, we don't perform any fitting in this case
                            handles.p.peak_fnd(m,n,1:10) = 0;
                        end
                    end    
                else
                    error('I should not be here')
                end
            end
        end
        fprintf(' peak fitting finished.\n')


        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % d) calculate pH from ZA5 and ZA1 maxima with respect to Urea simultaneously for pH~6.5
        % calculate difference of ZA peak 5 and ZA peak 1 to urea in ppm
        if (handles.p.fit_current_spectrum)
            if fitpeakampandpos == 1
                diff_ZA5_Urea = abs(handles.p.spec_peak_fit_pos(4) - handles.p.spec_peak_fit_pos(3)) / hztoppm;
                diff_ZA1_Urea = abs(handles.p.spec_peak_fit_pos(5) - handles.p.spec_peak_fit_pos(3)) / hztoppm;
                disp('using fitted amplitudes to calculate map pH~6.5');
            else
                diff_ZA5_Urea = abs(handles.p.spec_peak_pos(4) - handles.p.spec_peak_pos(3)) * ind2ppm;
                diff_ZA1_Urea = abs(handles.p.spec_peak_pos(5) - handles.p.spec_peak_pos(3)) * ind2ppm;
            end

            handles.p.pHspectrum65 = 0; 
            handles.p.pHDiffZA15_spectrum65 = 0;
            fprintf('pH calc 6.5(spec)   started ')
            for m = m_min:m_max
                fprintf('.')
                for n= n_min:n_max   
                    if all(handles.p.spec_peak_pos([3 4])) || all(handles.p.spec_peak_pos([3 5]))  %2019.08.06, Martin G.: modify such that pH is also calculated if only one peak (ZA1 or ZA5) is present
                        % we minimize the sum of squares to find the pH value determined by NMR
                        lb = []; ub = [];
                        % lb = 6.16; up = 6.74;
                        if all(handles.p.spec_peak_pos([3 4 5]))
                            handles.p.pHspectrum65 = lsqnonlin(@(x) za_model(handles.p.za_b, x)' - [diff_ZA5_Urea(m,n) diff_ZA1_Urea(m,n)]',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum65 = abs(za_model_pH_from_peak5(handles.p.za_b,diff_ZA5_Urea(m,n)) - za_model_pH_from_peak1(handles.p.za_b,diff_ZA1_Urea(m,n)));
                        elseif all(handles.p.spec_peak_pos([3 4]))
                            handles.p.pHspectrum65 = lsqnonlin(@(x) za_model_5(handles.p.za_b, x)' - diff_ZA5_Urea(m,n)',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum65 = 0;
                        elseif all(handles.p.spec_peak_pos([3 5]))
                            handles.p.pHspectrum65 = lsqnonlin(@(x) za_model_1(handles.p.za_b, x) - diff_ZA1_Urea(m,n),x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum65 = 0;
                        end
                    end
                end
            end
        else
            if fitpeakampandpos == 1
                diff_ZA5_Urea = abs(handles.p.peak_fit_pos(:,:,4) - handles.p.peak_fit_pos(:,:,3)) / hztoppm;
                diff_ZA1_Urea = abs(handles.p.peak_fit_pos(:,:,5) - handles.p.peak_fit_pos(:,:,3)) / hztoppm;
                disp('using fitted amplitudes to calculate map pH~6.5');
            else
                diff_ZA5_Urea = abs(handles.p.peak_pos(:,:,4) - handles.p.peak_pos(:,:,3)) * ind2ppm;
                diff_ZA1_Urea = abs(handles.p.peak_pos(:,:,5) - handles.p.peak_pos(:,:,3)) * ind2ppm;
            end

            handles.p.pHmap65 = zeros(m_max, n_max); 
            handles.p.pHDiffZA15_65 = zeros(m_max, n_max); 
            fprintf('pH calc 6.5   started ')
            for m = m_min:m_max
                fprintf('.')
                for n= n_min:n_max   
                    if all(handles.p.peak_pos(m,n,[3 4])) || all(handles.p.peak_pos(m,n,[3 5]))  %2019.08.06, Martin G.: modify such that pH is also calculated if only one peak (ZA1 or ZA5) is present
                        % we minimize the sum of squares to find the pH value determined by NMR
                        lb = []; ub = [];
                        % lb = 6.16; up = 6.74;
                        if all(handles.p.peak_pos(m,n,[3 4 5]))
                            handles.p.pHmap65(m,n) = lsqnonlin(@(x) za_model(handles.p.za_b, x)' - [diff_ZA5_Urea(m,n) diff_ZA1_Urea(m,n)]',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_65(m,n) = abs(za_model_pH_from_peak5(handles.p.za_b,diff_ZA5_Urea(m,n)) - za_model_pH_from_peak1(handles.p.za_b,diff_ZA1_Urea(m,n)));
                        elseif all(handles.p.peak_pos(m,n,[3 4]))
                            handles.p.pHmap65(m,n) = lsqnonlin(@(x) za_model_5(handles.p.za_b, x)' - diff_ZA5_Urea(m,n)',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_65(m,n) = 0;
                        elseif all(handles.p.peak_pos(m,n,[3 5]))
                            handles.p.pHmap65(m,n) = lsqnonlin(@(x) za_model_1(handles.p.za_b, x) - diff_ZA1_Urea(m,n),x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_65(m,n) = 0;
                        end
                    end
                end
            end
        end
        fprintf(' pH calculation finished.\n')

        if ~debughide
            % show the fitting result for information
            pH_plot = 4:0.1:10;
            figure(7891), plot(pH_plot,za_model(handles.p.za_b,pH_plot')), xlabel('pH'), ylabel('chemical shift [\Deltappm]'), title('fitting result from pH~6.5')
            hold all
            if (handles.p.fit_current_spectrum)
                plot(handles.p.pHspectrum65,[diff_ZA5_Urea(:), diff_ZA1_Urea(:)],'x')
            else
                plot(handles.p.pHmap65(:),[diff_ZA5_Urea(:), diff_ZA1_Urea(:)],'x')
            end
            hold off, xlim([min(pH_plot) max(pH_plot)]), pause(0.001);
        end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % c) calculate pH from ZA5 and ZA1 maxima with respect to Urea simultaneously for pH~7.0
        % calculate difference of ZA peak 5 and ZA peak 1 to urea in ppm
        if (handles.p.fit_current_spectrum)
            if fitpeakampandpos == 1
                diff_ZA5_Urea = abs(handles.p.spec_peak_fit_pos(6) - handles.p.spec_peak_fit_pos(3)) / hztoppm;
                diff_ZA1_Urea = abs(handles.p.spec_peak_fit_pos(7) - handles.p.spec_peak_fit_pos(3)) / hztoppm;
                disp('using fitted amplitudes to calculate map pH~7.0');
            else
                diff_ZA5_Urea = abs(handles.p.spec_peak_pos(6) - handles.p.peak_pos(3)) * ind2ppm;
                diff_ZA1_Urea = abs(handles.p.spec_peak_pos(7) - handles.p.peak_pos(3)) * ind2ppm;
            end

            handles.p.pHspectrum70 = 0;
            handles.p.pHDiffZA15_spectrum70 = 0;
            fprintf('pH calc 7.0(spec)   started ')
            for m = m_min:m_max
                fprintf('.')
                for n= n_min:n_max   
                    if all(handles.p.spec_peak_pos([3 6])) || all(handles.p.spec_peak_pos([3 7]))  %2019.08.06, Martin G.: modify such that pH is also calculated if only one peak (ZA1 or ZA5) is present
                        % we minimize the sum of squares to find the pH value determined by NMR
                        lb = []; ub = [];
                        % lb = 6.84; up = 7.19;
                        if all(handles.p.spec_peak_pos([3 6 7]))
                            handles.p.pHspectrum70 = lsqnonlin(@(x) za_model(handles.p.za_b, x)' - [diff_ZA5_Urea(m,n) diff_ZA1_Urea(m,n)]',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum70 = abs(za_model_pH_from_peak5(handles.p.za_b,diff_ZA5_Urea(m,n)) - za_model_pH_from_peak1(handles.p.za_b,diff_ZA1_Urea(m,n)));
                        elseif all(handles.p.spec_peak_pos([3 6]))
                            handles.p.pHspectrum70 = lsqnonlin(@(x) za_model_5(handles.p.za_b, x)' - diff_ZA5_Urea(m,n)',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum70 = 0;
                        elseif all(handles.p.spec_peak_pos([3 7]))
                            handles.p.pHspectrum70 = lsqnonlin(@(x) za_model_1(handles.p.za_b, x) - diff_ZA1_Urea(m,n),x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum70 = 0;
                        end
                        if handles.p.pHspectrum70 < 6.6, sprintf('(%.0f,%.0f) %.2f',m,n,handles.p.pHspectrum70); end
                    end
                end
            end
        else
            if fitpeakampandpos == 1
                diff_ZA5_Urea = abs(handles.p.peak_fit_pos(:,:,6) - handles.p.peak_fit_pos(:,:,3)) / hztoppm;
                diff_ZA1_Urea = abs(handles.p.peak_fit_pos(:,:,7) - handles.p.peak_fit_pos(:,:,3)) / hztoppm;
                disp('using fitted amplitudes to calculate map pH~7.0');
            else
                diff_ZA5_Urea = abs(handles.p.peak_pos(:,:,6) - handles.p.peak_pos(:,:,3)) * ind2ppm;
                diff_ZA1_Urea = abs(handles.p.peak_pos(:,:,7) - handles.p.peak_pos(:,:,3)) * ind2ppm;
            end

            handles.p.pHmap70 = zeros(m_max, n_max);
            handles.p.pHDiffZA15_70 = zeros(m_max, n_max);
            fprintf('pH calc 7.0   started ')
            for m = m_min:m_max
                fprintf('.')
                for n= n_min:n_max   
                    if all(handles.p.peak_pos(m,n,[3 6])) || all(handles.p.peak_pos(m,n,[3 7]))  %2019.08.06, Martin G.: modify such that pH is also calculated if only one peak (ZA1 or ZA5) is present
                        % we minimize the sum of squares to find the pH value determined by NMR
                        lb = []; ub = [];
                        % lb = 6.84; up = 7.19;
                        if all(handles.p.peak_pos(m,n,[3 6 7]))
                            handles.p.pHmap70(m,n) = lsqnonlin(@(x) za_model(handles.p.za_b, x)' - [diff_ZA5_Urea(m,n) diff_ZA1_Urea(m,n)]',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_70(m,n) = abs(za_model_pH_from_peak5(handles.p.za_b,diff_ZA5_Urea(m,n)) - za_model_pH_from_peak1(handles.p.za_b,diff_ZA1_Urea(m,n)));
                        elseif all(handles.p.peak_pos(m,n,[3 6]))
                            handles.p.pHmap70(m,n) = lsqnonlin(@(x) za_model_5(handles.p.za_b, x)' - diff_ZA5_Urea(m,n)',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_70(m,n) = 0;
                        elseif all(handles.p.peak_pos(m,n,[3 7]))
                            handles.p.pHmap70(m,n) = lsqnonlin(@(x) za_model_1(handles.p.za_b, x) - diff_ZA1_Urea(m,n),x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_70(m,n) = 0;
                        end
                        if handles.p.pHmap70(m,n) < 6.6, sprintf('(%.0f,%.0f) %.2f',m,n,handles.p.pHmap70(m,n)); end
                    end
                end
            end
        end
        fprintf(' pH calculation finished.\n')

        if ~debughide
            % show the fitting result for information
            pH_plot = 4:0.1:10;
            figure(7892), plot(pH_plot,za_model(handles.p.za_b,pH_plot')), xlabel('pH'), ylabel('chemical shift [\Deltappm]'), title('fitting result from pH~7.0')
            hold all
            if (handles.p.fit_current_spectrum)
                plot(handles.p.pHspectrum70(:),[diff_ZA5_Urea(:), diff_ZA1_Urea(:)],'x')
            else
                plot(handles.p.pHmap70(:),[diff_ZA5_Urea(:), diff_ZA1_Urea(:)],'x')
            end
            hold off, xlim([min(pH_plot) max(pH_plot)]), legend('ZA5','ZA1','Location','SouthEast'), pause(0.001);
        end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % f) calculate pH from ZA5 and ZA1 maxima with respect to Urea simultaneously for pH~7.4
        % calculate difference of ZA peak 5 and ZA peak 1 to urea in ppm
        if (handles.p.fit_current_spectrum)
            if fitpeakampandpos == 1
                diff_ZA5_Urea = abs(handles.p.spec_peak_fit_pos(8) - handles.p.spec_peak_fit_pos(3)) / hztoppm;
                diff_ZA1_Urea = abs(handles.p.spec_peak_fit_pos(9) - handles.p.spec_peak_fit_pos(3)) / hztoppm;
                disp('using fitted amplitudes to calculate map pH~7.4');
            else
                diff_ZA5_Urea = abs(handles.p.spec_peak_pos(8) - handles.p.spec_peak_pos(3)) * ind2ppm;
                diff_ZA1_Urea = abs(handles.p.spec_peak_pos(9) - handles.p.spec_peak_pos(3)) * ind2ppm;
            end

            handles.p.pHspectrum74 = 0;
            handles.p.pHDiffZA15_spectrum74 = 0;
            fprintf('pH calc 7.4   started ')
            for m = m_min:m_max
                fprintf('.')
                for n= n_min:n_max   
                    if all(handles.p.spec_peak_pos([3 8])) || all(handles.p.spec_peak_pos([3 9]))  %2019.08.06, Martin G.: modify such that pH is also calculated if only one peak (ZA1 or ZA5) is present
                        % we minimize the sum of squares to find the pH value determined by NMR
                        lb = []; ub = [];
                        % lb = 7.23; up = 7.61;
                        if all(handles.p.spec_peak_pos([3 8 9]))
                            handles.p.pHspectrum74 = lsqnonlin(@(x) za_model(handles.p.za_b, x)' - [diff_ZA5_Urea(m,n) diff_ZA1_Urea(m,n)]',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum74 = abs(za_model_pH_from_peak5(handles.p.za_b,diff_ZA5_Urea(m,n)) - za_model_pH_from_peak1(handles.p.za_b,diff_ZA1_Urea(m,n)));
                        elseif all(handles.p.spec_peak_pos([3 8]))
                            handles.p.pHspectrum74 = lsqnonlin(@(x) za_model_5(handles.p.za_b, x)' - diff_ZA5_Urea(m,n)',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum74 = 0;
                        elseif all(handles.p.spec_peak_pos([3 9]))
                            handles.p.pHspectrum74 = lsqnonlin(@(x) za_model_1(handles.p.za_b, x) - diff_ZA1_Urea(m,n),x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_spectrum74 = 0;
                        end
                    end
                end
            end
        else
            if fitpeakampandpos == 1
                diff_ZA5_Urea = abs(handles.p.peak_fit_pos(:,:,8) - handles.p.peak_fit_pos(:,:,3)) / hztoppm;
                diff_ZA1_Urea = abs(handles.p.peak_fit_pos(:,:,9) - handles.p.peak_fit_pos(:,:,3)) / hztoppm;
                disp('using fitted amplitudes to calculate map pH~7.4');
            else
                diff_ZA5_Urea = abs(handles.p.peak_pos(:,:,8) - handles.p.peak_pos(:,:,3)) * ind2ppm;
                diff_ZA1_Urea = abs(handles.p.peak_pos(:,:,9) - handles.p.peak_pos(:,:,3)) * ind2ppm;
            end

            handles.p.pHmap74 = zeros(m_max, n_max);
            handles.p.pHDiffZA15_74 = zeros(m_max, n_max);
            fprintf('pH calc 7.4   started ')
            for m = m_min:m_max
                fprintf('.')
                for n= n_min:n_max   
                    if all(handles.p.peak_pos(m,n,[3 8])) || all(handles.p.peak_pos(m,n,[3 9]))  %2019.08.06, Martin G.: modify such that pH is also calculated if only one peak (ZA1 or ZA5) is present
                        % we minimize the sum of squares to find the pH value determined by NMR
                        lb = []; ub = [];
                        % lb = 7.23; up = 7.61;
                        if all(handles.p.peak_pos(m,n,[3 8 9]))
                            handles.p.pHmap74(m,n) = lsqnonlin(@(x) za_model(handles.p.za_b, x)' - [diff_ZA5_Urea(m,n) diff_ZA1_Urea(m,n)]',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_74(m,n) = abs(za_model_pH_from_peak5(handles.p.za_b,diff_ZA5_Urea(m,n)) - za_model_pH_from_peak1(handles.p.za_b,diff_ZA1_Urea(m,n)));
                        elseif all(handles.p.peak_pos(m,n,[3 8]))
                            handles.p.pHmap74(m,n) = lsqnonlin(@(x) za_model_5(handles.p.za_b, x)' - diff_ZA5_Urea(m,n)',x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_74(m,n) = 0;
                        elseif all(handles.p.peak_pos(m,n,[3 9]))
                            handles.p.pHmap74(m,n) = lsqnonlin(@(x) za_model_1(handles.p.za_b, x) - diff_ZA1_Urea(m,n),x0,lb,ub,optimoptions('lsqnonlin','Display','none'));
                            handles.p.pHDiffZA15_74(m,n) = 0;
                        end
                    end
                end
            end
        end    
        fprintf(' pH calculation finished.\n')

        if ~debughide
            % show the fitting result for information
            pH_plot = 4:0.1:10;
            figure(7893), plot(pH_plot,za_model(handles.p.za_b,pH_plot')), xlabel('pH'), ylabel('chemical shift [\Deltappm]'), title('fitting result from pH~7.4')
            hold all
            if (handles.p.fit_current_spectrum)
                plot(handles.p.pHspectrum74,[diff_ZA5_Urea(:), diff_ZA1_Urea(:)],'x')
            else
                plot(handles.p.pHmap74(:),[diff_ZA5_Urea(:), diff_ZA1_Urea(:)],'x')
            end
            hold off, xlim([min(pH_plot) max(pH_plot)]), legend('ZA5','ZA1','Location','SouthEast'), pause(0.001);
        end

        % ***************** pH calculation from ZA only ***************************
        % calculate pH from simple peak finding
        warning('off','MATLAB:polyfit:RepeatedPointsOrRescale');
        pH_5_9 = linspace(5,9,200);
        Diff_5_9 = za_model_5(handles.p.za_b,pH_5_9) - za_model_1(handles.p.za_b,pH_5_9);
        p = polyfit(Diff_5_9,pH_5_9,15);
        % evaluate pH values from polynomial fit to experimental calibration data for 

        % calculate frequency difference between peaks in Hz
        %freqdiff=((freq2-freq1+(freq2_min-freq1_min)).*mask2*(hz1(2)-hz1(1)));
        if (handles.p.fit_current_spectrum)
            handles.p.pHspectrumDiff = 0;
            diff_hz = abs(handles.p.spec_peak_pos(1) - handles.p.spec_peak_pos(2)) *...
                          abs(handles.d.carbon_recon.hz_padded(2) - handles.d.carbon_recon.hz_padded(1));
            diff_ppm = diff_hz ./ hztoppm;
            handles.p.pHspectrumDiff = polyval(p,diff_ppm);
        else
            handles.p.pHmap = zeros(m_max, n_max);
            diff_hz = abs(handles.p.peak_pos(:,:,1) - handles.p.peak_pos(:,:,2)) *...
                          abs(handles.d.carbon_recon.hz_padded(2) - handles.d.carbon_recon.hz_padded(1));
            diff_ppm = diff_hz ./ hztoppm;
            handles.p.pHmap = polyval(p,diff_ppm);
        end
        Sz = size(handles.p.pHmap74);
        
    %%% ---- inserted section for generation of synthetic (AI + Line
    %%% fitting pH maps      
    elseif AI == 1
        Sz = size(handles.p.pHmap74);
%         [file, path] = uigetfile;    
%         fullpath = [path file];
%         load(fullpath);
%         sz = size(predict_map); 
%         for i = 1:sz(1)
%               for j = 1:sz(2)
%                      if max(size(predict_map{i,j})) == 1
%                            predict_map_65(i,j) = 0;
%                            predict_map_70(i,j) = 0;
%                            predict_map_74(i,j) = 0;
%                      else
%                            predict_map_74(i,j) = double(predict_map{i,j}(1));
%                            predict_map_70(i,j) = double(predict_map{i,j}(2));
%                            predict_map_65(i,j) = double(predict_map{i,j}(3));
%                      end
%               end
%         end
%         bw_mask = imbinarize(predict_map_65);
%         for i = 1:sz(1)
%           for j = 1:sz(2)
%               if bw_mask(i,j) == 1
%                    handles.p.pHmap65(i,j) = predict_map_65(i,j);
%                    handles.p.pHmap70(i,j) = predict_map_70(i,j);
%                    handles.p.pHmap74(i,j) = predict_map_74(i,j);
%               end
%           end
%         end
%         disp('Caution! pH Maps are now synthetic from AI and fitted data!')
        %%% ---- end inserted section



        if (handles.p.fit_current_spectrum)
            if handles.p.pHspectrum74~=0 || handles.p.pHspectrum70~=0 || handles.p.pHspectrum65~=0
                handles.p.pHspectrumMean = (handles.p.pHspectrum74*(handles.p.spec_peak_fit_amp(8)+handles.p.spec_peak_fit_amp(9))/2 + handles.p.pHspectrum70*(handles.p.spec_peak_fit_amp(6)+handles.p.spec_peak_fit_amp(7))/2 + handles.p.pHspectrum65*(handles.p.spec_peak_fit_amp(4)+handles.p.spec_peak_fit_amp(5))/2 )/(sum(handles.p.spec_peak_fit_amp(4:9),2)/2);
            else  
                handles.p.pHspectrumMean = 0;
            end
        else    
            for i=1:Sz(1)
                for j=1:Sz(2)
                    if handles.p.pHmap74(i,j)~=0 || handles.p.pHmap70(i,j)~=0 || handles.p.pHmap65(i,j) ~=0
                        if handles.p.pHmeanWeighted == 1
                            if AI == 0
                                handles.p.pHmapMean(i,j) = (handles.p.pHmap74(i,j)*(handles.p.peak_fit_amp(i,j,8)+handles.p.peak_fit_amp(i,j,9))/2 + handles.p.pHmap70(i,j)*(handles.p.peak_fit_amp(i,j,6)+handles.p.peak_fit_amp(i,j,7))/2 + handles.p.pHmap65(i,j)*(handles.p.peak_fit_amp(i,j,4)+handles.p.peak_fit_amp(i,j,5))/2 )/(sum(handles.p.peak_fit_amp(i,j,4:9),3)/2);
                            elseif AI == 1
                                if i == 1 && j == 1
                                    disp('For AI-predicted pH Compartments, a intensity-weighted mean pH cannot be derived!');
                                end
                            end
                        elseif handles.p.pHmeanWeighted_signal == 1
                            handles.p.pHmapMean(i,j) = (handles.p.pHmap74(i,j)*(handles.p.peak_val(i,j,8)+handles.p.peak_val(i,j,9))/2 + handles.p.pHmap70(i,j)*(handles.p.peak_val(i,j,6)+handles.p.peak_val(i,j,7))/2 + handles.p.pHmap65(i,j)*(handles.p.peak_val(i,j,4)+handles.p.peak_val(i,j,5))/2 )/(sum(handles.p.peak_val(i,j,4:9),3)/2);
                        else
                            handles.p.pHmapMean(i,j) = (handles.p.pHmap74(i,j) + handles.p.pHmap70(i,j) + handles.p.pHmap65(i,j))/nnz([handles.p.pHmap74(i,j) handles.p.pHmap70(i,j) handles.p.pHmap65(i,j)]);
                        end
                    else
                        handles.p.pHmapMean(i,j) = 0;
                    end
                    Weights = zeros([1 3]);
                    Weights(1) = handles.p.peak_fit_amp(i,j,4) + handles.p.peak_fit_amp(i,j,5);
                    Weights(2) = handles.p.peak_fit_amp(i,j,6) + handles.p.peak_fit_amp(i,j,7);
                    Weights(3) = handles.p.peak_fit_amp(i,j,8) + handles.p.peak_fit_amp(i,j,9);
                    if max(Weights) == Weights(1) && max(Weights) > 0
                        handles.p.pHmapMain(i,j) = handles.p.pHmap65(i,j);
                    elseif max(Weights) == Weights(2) && max(Weights) > 0
                        handles.p.pHmapMain(i,j) = handles.p.pHmap70(i,j);
                    elseif max(Weights) == Weights(3) && max(Weights) > 0
                        handles.p.pHmapMain(i,j) = handles.p.pHmap74(i,j);
                    else
                        handles.p.pHmapMain(i,j) = 0;
                    end
                end
            end
        end
    end
    handles.p.pHmap74(handles.p.pHmap74 > 10) = 0;
    handles.p.pHmap70(handles.p.pHmap70 > 10) = 0;
    handles.p.pHmap65(handles.p.pHmap65 > 10) = 0;
    handles.p.pHmapMean(handles.p.pHmapMean > 10) = 0;
    handles.p.pHmapMean(handles.p.pHmapMain > 10) = 0;
    handles.p.pHmap74(handles.p.pHmap74 < 4) = 0;
    handles.p.pHmap70(handles.p.pHmap70 < 4) = 0;
    handles.p.pHmap65(handles.p.pHmap65 < 4) = 0;
    handles.p.pHmapMean(handles.p.pHmapMean < 4) = 0;
    handles.p.pHmapMean(handles.p.pHmapMain < 4) = 0;
    
   
function metab_data = RephaseMetabData_Padded(metab_data_in, handles)
    if (length(handles.d.carbon_recon.hz_padded) ~= size(metab_data_in, 3))
        disp('skipping rephasing metab data due to size inconsistency... sure you are working with pH-Calc-Data?')
        metab_data = metab_data_in;
        return
    end

    % apply phase factors...
    phase0_factor = exp(-1i * handles.p.spectrum_phase0 / 180 * pi());
    phase1_factor = exp(-1i * handles.d.carbon_recon.hz_padded' * handles.p.spectrum_phase1 / 1000 / 180 * pi());
    phase1_factor = permute(phase1_factor, [2 3 1 4 5 6]);
    
    if (handles.p.do_freq_fft)
        metab_data = phase0_factor * metab_data_in .* phase1_factor;
    else
        % do fft, apply shift, then undo fft to get back to the phased FID
        spec = fftshift(fft(metab_data_in,[],3),3);
        spec = phase0_factor * spec .* phase1_factor;
        metab_data = ifft(ifftshift(spec,3),[],3);
    end

function metab_data = RephaseMetabData(metab_data_in, handles)
    if (length(handles.p.hz) ~= size(metab_data_in, 3))
        disp('skipping rephasing metab data due to size inconsistency... maybe ISPSCI?')
        metab_data = metab_data_in;
        return
    end

    % apply phase factors...
    phase0_factor = exp(-1i * handles.p.spectrum_phase0 / 180 * pi());
    phase1_factor = exp(-1i * handles.p.hz' * handles.p.spectrum_phase1 / 1000 / 180 * pi());
    phase1_factor = permute(phase1_factor, [2 3 1 4 5 6]);
    
    if (handles.p.do_freq_fft)
        metab_data = phase0_factor * metab_data_in .* phase1_factor;
    else
        % do fft, apply shift, then undo fft to get back to the phased FID
        spec = fftshift(fft(metab_data_in,[],3),3);
        spec = phase0_factor * spec .* phase1_factor;
        metab_data = ifft(ifftshift(spec,3),[],3);
    end

function [spectrum, complex_spectrum] = GetMetabSpectrum(handles)
    spectrum = zeros(1,2048); % default, to be replaced
    complex_spectrum = spectrum;
    if ~isfield(handles,'d') || ~isfield(handles.d, 'carbon_recon')
        disp('No metabolic data to make spectrum of!')
        return
    end
    if handles.p.option_plot_pH_map == 1 && (isfield(handles.d.carbon_recon,'volume') || isfield(handles.d.carbon_recon,'single_voxel_volume'))
        if ~(handles.p.fit_current_spectrum)
            metab_data = handles.d.carbon_recon.volume;
        else
            metab_data = handles.d.carbon_recon.single_voxel_volume - handles.p.intensity_offset;
        end
    else 
        metab_data = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
        metab_data = RephaseMetabData(metab_data, handles);
    end
    

    if ~handles.p.option_timestep_sum
        time_idx_low = handles.p.timestep_val;
        time_idx_high = time_idx_low + handles.p.timestep_length - 1;
    else
        time_idx_low = 1;
        time_idx_high = size(metab_data, 6);
    end
    metab_data_multicoil = MetabDataIndexedByTime(metab_data, time_idx_low, time_idx_high, handles);

    
    % get absolute spectrum. note: indexing by coil takes absolute value
    metab_data = MetabDataIndexedByCoil(metab_data_multicoil, handles);

    if handles.p.option_plot_phase
        metab_data = angle(metab_data);
    else
        if isreal(metab_data)
            metab_data = metab_data + handles.p.intensity_offset;
        else
            metab_data = abs(metab_data) + handles.p.intensity_offset;
        end
    end
    metab_data = MetabDataIndexedByPosition(metab_data, handles);
    spectrum = squeeze(metab_data); % magnitude spectrum to output    
    
    
    % get complex spectrum: manually do single-coil indexing.
    if (handles.p.option_carbon_rms && (size(metab_data_multicoil,5) > 1))
        disp('Warning: Cant generate complex spectrum with RMS combination of coils')
    end
    metab_data = MetabDataIndexedByCoil(metab_data_multicoil, handles);
    metab_data = metab_data + handles.p.intensity_offset;                       %Martin G, 2020.04.03, added: also add intensity offset to real part of complex spectrum
    metab_data = MetabDataIndexedByPosition(metab_data, handles);
    complex_spectrum = squeeze(metab_data); % complex spectrum to output    

function metab_data = MetabDataIndexedBySlice(metab_data_in, handles)
    metab_data = metab_data_in(:, :, :, handles.p.slice_carbon_val, :, :);

function metab_data = MetabDataIndexedByCoil(metab_data_in, handles)
    % average / index over coils
    if (~handles.p.option_plot_phase)
        if (handles.p.option_carbon_rms && (size(metab_data_in,5) > 1))
            metab_data = sqrt(mean(abs(metab_data_in).^2, 5));
        else
            metab_data = metab_data_in(:, :, :, :, handles.p.coil_carbon_val, :);
        end

    else
        % for phase, can't take absolute value before calculating, so
        % just index or take mean...
        if (handles.p.option_carbon_rms && (size(metab_data_in,5) > 1))
            metab_data = mean(metab_data_in, 5);
        else
            metab_data = metab_data_in(:, :, :, :, handles.p.coil_carbon_val, :);
        end
    end    
    
function metab_data = MetabDataIndexedByTime(metab_data_in, time_idx_low, time_idx_high, handles)
    % picks single timepoint or averages (mean) over range of specified
    % range of timepoints
    
    if (time_idx_high > size(metab_data_in, 6))
        time_idx_high = size(metab_data_in, 6);
    end
    if (time_idx_high < 1)
        time_idx_high = 1;
    end
    if (time_idx_low > time_idx_high)
        time_idx_low = time_idx_high;
    end
    if (time_idx_low < 1)
        time_idx_low = 1;
    end

    
    metab_data = ApplyFlipAngleCorrectionFactors(metab_data_in, handles);
    
    
    % average / index over time
    if (time_idx_high <= time_idx_low)
        metab_data = metab_data(:,:,:,:,:,time_idx_low);
    else
        metab_data = mean(metab_data(:,:,:,:,:,time_idx_low:time_idx_high), 6);
    end

function metab_data = MetabDataIndexedByPosition(metab_data_in, handles)
    % is there a defined ROI and is averaging over it enabled?
    average_over_roi = (handles.p.specandtime_roi == 1);

    if (average_over_roi)
        volume_mask = zeros(size(metab_data_in));
        for freq = 1:size(volume_mask,3)
            for slice = 1:size(volume_mask,4)
                for coil = 1:size(volume_mask,5)
                    for time = 1:size(volume_mask,6)
                        volume_mask(:,:,freq,slice,coil,time) = handles.p.roi_mask;
                    end
                end
            end
        end
        volume_mask(metab_data_in == 0) = 0;
        metab_data = volume_mask .* metab_data_in;
        metab_data = sum(sum(metab_data,2),1) ./ sum(sum(volume_mask,2),1);
  
    else
        % just index by cursor position
        idx1 = min(max(1, handles.p.pointer2d(1)), size(metab_data_in,1));
        idx2 = min(max(1, handles.p.pointer2d(2)), size(metab_data_in,2));
        metab_data = metab_data_in(idx1, idx2, :, :, :, :);
    end    

function metab_data = ApplyFlipAngleCorrectionFactors(metab_data_in, handles)
if (~handles.p.flipangle_correction_desired)
    metab_data = metab_data_in;
    return
end
if size(metab_data_in, 6) < 2
    metab_data = metab_data_in;
    disp('No timeseries axis to apply flip angle correction to!')
    return
end

fac = 1; %no flip angle correction is applied here

sz = size(metab_data_in);
fac_rep = ones(sz);
for x = 1:sz(1)
    for y = 1:sz(2)
        for f = 1:sz(3)
            for s = 1:sz(4)
                for c = 1:sz(5)
                    fac_rep(x,y,f,s,c,:) = fac;
                end
            end
        end
    end
end

metab_data = metab_data_in .* fac_rep;

    
function my_lorentzian_out = my_lorentzian(x, params)
% params: amp1, xoffset1, broadness1, amp2, xoffset2, broadness2, yoffset
my_lorentzian_out = params.yoffset +...
                    params.amp1/pi .* params.broadness1/2 ./ ((x-params.xoffset1hz).^2 + (params.broadness1/2).^2) +...
                    params.amp2/pi .* params.broadness2/2 ./ ((x-params.xoffset2hz).^2 + (params.broadness2/2).^2) +...
                    params.amp3/pi .* params.broadness3/2 ./ ((x-params.xoffset3hz).^2 + (params.broadness3/2).^2);
                
function za = za_model(b,x)
    % return a vector with two components, ZA5(pH) and ZA1(pH)
    za = [b(1) + b(3) * ( 1 ./ (1 + 10.^-(x-b(5)))),b(2) + b(4) * ( 1 ./ (1 + 10.^-(x-b(5))))];

function za = za_model_5(b,x)
    % return a scalar with one component, ZA5(pH) 
    za = b(1) + b(3) * ( 1 ./ (1 + 10.^-(x-b(5))));

function za = za_model_1(b,x)
    % return a scalar with one component, ZA1(pH) 
    za = b(2) + b(4) * ( 1 ./ (1 + 10.^-(x-b(5))));

function peak = peak_model(amp,wid,pos,x)
    % return the shape of a magnitude Lorentzian peak
    peak = amp * (wid/2)^2 ./ ((wid/2)^2 + (x-pos).^2);

function peak = peak_collection(b,pos,x)
    % combine peaks based on which peaks were previously found
    % number of peaks
    npeaks = length(pos);
    % add a vertical offset into the model for baseline correction
    peak = b(2*npeaks+1);
    % add number of peaks
    for k=1:npeaks
        peak = peak + peak_model(b(2*k-1),b(2*k),pos(k),x);
    end

function peak = peak_collection_amponly(b,wid,pos,x)
    % combine peaks based on which peaks were previously found
    % number of peaks
    npeaks = length(pos);
    % add a vertical offset into the model for baseline correction
    peak = b(npeaks+1);
    % add number of peaks
    for k=1:npeaks
        peak = peak + peak_model(b(k),wid(k),pos(k),x);
    end

function peak = peak_collection_ampandpos(b,wid,x)
    % combine peaks based on which peaks were previously found
    % number of peaks
    npeaks = length(wid);
    % add a vertical offset into the model for baseline correction
    peak = b(2*npeaks+1);
    % add number of peaks
    for k=1:npeaks
        peak = peak + peak_model(b(2*k-1),wid(k),b(2*k),x);
    end
    
function [spectrumnew, frequenciesnew] = zeropadding(spectrum, frequencies, fillingfactor)
    tdomain = ifftshift(ifft(spectrum));                                                                       % first transform spectrum back into time domain
    if floor(length(spectrum)*fillingfactor) ~= length(spectrum)*fillingfactor 
        warning('The length of the desired zero-padded length is not an integer value !')           % check if new number of data points corresponds to an integer
    end
%     if length(spectrum) ~= length(frequencies)                                                      % check if input arrays have same length
%         warning('Frequency range and spectrum do not have the same length!')    
%     end
    
    tdomainnew = zeros(1,floor(length(spectrum)*fillingfactor));                                    % if not, round down padded spectrum length to lower integer value 
    
    if length(tdomainnew) >= length(spectrum)
        for i=1:length(spectrum)
            tdomainnew(i) = tdomain(i);                                                             % data points are filled at beginning of zero-array of new length
        end
    else
        error('Please choose a fillingfactor larger than 1 !')                                      % function only intended to provide upsampling                   
    end 
    spectrumnew = fft(tdomainnew);                                                                  % transform new t-domain data back into frequency domain
    
    lowestfrequency = min(frequencies);
    highestfrequency = max(frequencies);
    frequenciesnew = linspace(lowestfrequency,highestfrequency,floor(length(frequencies)*fillingfactor));    
    

% --- Executes on button press in radiobutton_mean_pHmap.
function radiobutton_mean_pHmap_Callback(hObject, eventdata, handles)
    fit_curr = handles.p.fit_current_spectrum;
    PlotNothing(handles);
    handles.p.option_plot_pH_map = 1;
    handles.p.option_plot_pH_map_mean = 1;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.fit_current_spectrum = fit_curr;

    guidata(hObject,handles);
    plot4d_plot(handles);
    
function radiobutton_main_pHmap_Callback(hObject, eventdata, handles)    
    fit_curr = handles.p.fit_current_spectrum;
    PlotNothing(handles);
    handles.p.option_plot_pH_map = 1;
    handles.p.option_plot_pH_map_main = 1;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_compartment = 0;
    handles.p.fit_current_spectrum = fit_curr;

    guidata(hObject,handles);
    plot4d_plot(handles);

function radiobutton_pH_compartment_Callback(hObject, eventdata, handles)
    fit_curr = handles.p.fit_current_spectrum;
    PlotNothing(handles);
    handles.p.option_plot_pH_map = 1;
    handles.p.option_plot_pH_map_compartment = 1;
    handles.p.option_plot_pH_map_mean = 0;
    handles.p.option_plot_pH_map_main = 0;
    handles.p.fit_current_spectrum = fit_curr;

    guidata(hObject,handles);
    plot4d_plot(handles);
    
    
function checkbox_pHmap70_Callback(hObject, eventdata, handles)
    handles.p.option_show_pHmap70 = handles.checkbox_pHmap70.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);

function checkbox_pHmap74_Callback(hObject, eventdata, handles)
    handles.p.option_show_pHmap74 = handles.checkbox_pHmap74.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);
    
function checkbox_pHmap65_Callback(hObject, eventdata, handles)
    handles.p.option_show_pHmap65 = handles.checkbox_pHmap65.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_Display_pH_value_Callback(hObject, eventdata, handles)

function edit_Display_pH_value_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


function slider_alpha74_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha_74 = hObject.Value;

    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_alpha74_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end


function slider_alpha70_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha_70 = hObject.Value;

    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_alpha70_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end


function slider_alpha65_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha_65 = hObject.Value;

    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_alpha65_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end



function edit_Fit_threshold_Callback(hObject, eventdata, handles)
    val = str2double(get(hObject,'String'));
    if isempty(val), val = handles.p.pH_fit_threshold; end
    handles.p.pH_fit_threshold = val;
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_Fit_threshold_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


function checkbox_invert_colormap_Callback(hObject, eventdata, handles)
    handles.p.invert_colormap = handles.checkbox_invert_colormap.Value;
    
    guidata(hObject,handles);
    plot4d_plot(handles);


function checkbox_cut_pH_map_Callback(hObject, eventdata, handles)
    handles.p.cut_pH_map = handles.checkbox_cut_pH_map.Value;
    handles.p.roi_draw_cut = handles.checkbox_cut_pH_map.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);



function edit_proton_cut_threshold_Callback(hObject, eventdata, handles)
    val = str2double(get(hObject,'String'));
    if isempty(val), val = handles.p.proton_cut_threshold; end
    handles.p.proton_cut_threshold = val;
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_proton_cut_threshold_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


function checkbox_phmax_auto_Callback(hObject, eventdata, handles)
    handles.p.pH_window_auto = handles.checkbox_phmax_auto.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);


function edit_phwindow_low_Callback(hObject, eventdata, handles)
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        guidata(hObject,handles);
        plot4d_plot(handles);

        return
    end

    % changing low value should not change the high value unless the new low
    % value is equal or greater than the old high value. so, adjust the window
    % length based on the difference in the old and new window (low) values
    window_val_shift = edit_num - handles.p.pH_window_val;
    new_window_length = handles.p.pH_window_length - window_val_shift;
    handles.p.pH_window_length = new_window_length; % may be negative, but may be overwritten by checks in plot function

    handles.p.pH_window_val = edit_num;

    handles.p.pH_window_auto = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_phwindow_low_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_phwindow_high_Callback(hObject, eventdata, handles)
    edit_num = str2num(hObject.String); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0
        guidata(hObject,handles);
        plot4d_plot(handles);

        return
    end

    % changing high value should not change the low value unless the new high
    % value is less than or equal to old low value. so, adjust the window
    % length based on the difference in the old and new window (high) values,
    % and change the low value only if the high value is set too low
    if edit_num <= handles.p.pH_window_val
        handles.p.pH_window_val = edit_num - 0.1;
    end

    handles.p.pH_window_length = edit_num - handles.p.pH_window_val;

    handles.p.pH_window_auto = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_phwindow_high_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


function slider_phwindow_Callback(hObject, eventdata, handles)
    hObject.Value = round(hObject.Value,1);
    val = hObject.Value;
    if (val > hObject.Max)
        val = hObject.Max;
    end
    handles.p.pH_window_length = val;
    handles.p.pH_window_auto = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);

function slider_phwindow_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end


function alpha74_text_CreateFcn(hObject, eventdata, handles)

function pushbutton30_Callback(hObject, eventdata, handles)


function edit_Fit_prominence_Callback(hObject, eventdata, handles)
    val = str2double(get(hObject,'String'));
    if isempty(val), val = handles.p.pH_fit_threshold; end
    handles.p.pH_fit_prominence = val;
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_Fit_prominence_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function pushbutton_roi_cut_save_Callback(hObject, eventdata, handles)
   if isempty(handles.p.roi_xi_cut)
        disp('no ROIs to save')
    end

    defaultname = '';
    if ~isempty(handles.p.proton_file)
        [defaultname, ~, ~] = fileparts(handles.p.proton_file);
    elseif ~isempty(handles.p.carbon_file)
        [defaultname, ~, ~] = fileparts(handles.p.carbon_file);
    end
    
    if ~isempty(defaultname)
        % move up to folder containing multiple scans from the locatino of
        % 2dseq file
        defaultname = fullfile(defaultname, '../../../c13tool_rois.mat');
    end
    
    % define which filetypes can be selected as raw files
    filterspec = {'.mat', 'MatLab Matrix File'};
    file_prompt = 'Please select the Cut-ROI Save File';    
    
    [filename, pathname] = uiputfile(filterspec, file_prompt, defaultname);
    if isempty(filename)
        disp('no save file selected...')
        return
    end
    
    mask = handles.p.roi_mask_cut;  %#ok<NASGU>
    xi = handles.p.roi_xi_cut;      %#ok<NASGU>
    yi = handles.p.roi_yi_cut;      %#ok<NASGU>
    
    save([pathname filename], 'mask', 'xi', 'yi');
    
    disp(['ROIs saved to: ' pathname filename])



function pushbutton_roi_cut_load_Callback(hObject, eventdata, handles)
    defaultname = '';
    if ~isempty(handles.p.proton_file)
        [defaultname, ~, ~] = fileparts(handles.p.proton_file);
    elseif ~isempty(handles.p.carbon_file)
        [defaultname, ~, ~] = fileparts(handles.p.carbon_file);
    end
    
    if ~isempty(defaultname)
        % move up to folder containing multiple scans from the location of
        % 2dseq file
        % todo: check if it's an fid or a 2dseq and appropriately move up
        % just one or a full three directories
        defaultname = fullfile(defaultname, '../../../*.mat');
    end
    
    % define which filetypes can be selected as raw files
    filterspec = {'.mat', 'MatLab Matrix File'};
    file_prompt = 'Please select the Cut-ROI File';    
    
    [filename, pathname] = uigetfile(filterspec, file_prompt, defaultname);
    if isempty(filename)
        disp('no file selected...')
        return
    end

    
    % load saved ROI file, and assign anything present to ROI fields
    loaded_rois = load([pathname filename]);
    
    if isfield(loaded_rois, 'mask')
        handles.p.roi_mask_cut = loaded_rois.mask;
    end
    if isfield(loaded_rois, 'xi')
        handles.p.roi_xi_cut = loaded_rois.xi;
    end
    if isfield(loaded_rois, 'yi')
        handles.p.roi_yi_cut = loaded_rois.yi;
    end    
    handles.p.cut_roi_loaded = 1;
    handles.p.cut_pH_map = 1;  % enable use of averaging within ROI
    guidata(hObject,handles);
    plot4d_plot(handles);

function pushbutton_roi_cut_clear_Callback(hObject, eventdata, handles)
    handles.p.cut_pH_map = 0;
    handles.p.cut_roi_loaded = 0;
    guidata(hObject,handles);
    plot4d_plot(handles);



function checkbox_fig_PPT_Callback(hObject, eventdata, handles)
    handles.p.fig_ppt = handles.checkbox_fig_PPT.Value;
    guidata(hObject,handles);
    plot4d_plot(handles);
    



function edit_alpha74_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha_74 = str2double(hObject.String);
    
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_alpha74_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_alpha70_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha_70 = str2double(hObject.String);
    
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_alpha70_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_alpha65_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha_65 = str2double(hObject.String);
    
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_alpha65_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_proton_overlay_alpha_Callback(hObject, eventdata, handles)
    handles.p.option_overlay_alpha = str2double(hObject.String);
    
    guidata(hObject,handles);
    plot4d_plot(handles);

function edit_proton_overlay_alpha_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function checkbox_pHweighted_Callback(hObject, eventdata, handles)
    handles.p.pHmeanWeighted = handles.checkbox_pHweighted.Value;
    handles.p.pHmeanWeighted_signal = 0;
    disp('Caution: has to be set before "Creating pH-Map"!')
    
    guidata(hObject,handles);
    plot4d_plot(handles);
    
    
function checkbox_pHweighted_signal_Callback(hObject, eventdata, handles)
     handles.p.pHmeanWeighted_signal = handles.checkbox_pHweighted_signal.Value;
     handles.p.pHmeanWeighted = 0;
     disp('Caution: has to be set before "Creating pH-Map"!')
    
    guidata(hObject,handles);
    plot4d_plot(handles);
    


function edit_spec_fill_Callback(hObject, eventdata, handles)
    handles.pushbutton_carbon_recon.BackgroundColor = handles.p.color_lightgrey;

    edit_num = round(str2num(hObject.String)); %#ok<ST2NM>
    if nnz(size(edit_num)) == 0 || nnz(size(edit_num)) > 2
        edit_num = 1;
    end
    if (edit_num < 1)
        edit_num = 1;
    end

    handles.edit_spec_fill.String = edit_num;
    handles.p.spec_fillfactor = edit_num;
    
    if(isfield(handles,'d')) %increase FID windowing to not automatically exclude new zeropadded end (2020.04.14, Martin G.)
        if(isfield(handles.d,'carbon_recon'))
            if(isfield(handles.d.carbon_recon, 'image'))
                szraw = size(handles.d.carbon_data_raw);
                handles.p.carbon_recon_point_high = handles.p.spec_fillfactor*szraw(1);
                handles.edit_fid_window_high.String = handles.p.spec_fillfactor*szraw(1);
            end
        end
    end
    guidata(hObject,handles);


function edit_spec_fill_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function checkbox_pHmap_roi_draw_Callback(hObject, eventdata, handles)
    handles.p.pHmap_roi_draw = handles.checkbox_pHmap_roi_draw.Value;
    guidata(hObject,handles);
 



function edit_ROI_Px_13C_Callback(hObject, eventdata, handles)
    %unused

function edit_ROI_Px_13C_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_ROI_Px_1H_Callback(hObject, eventdata, handles)
     %unused
     
function edit_ROI_Px_1H_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_Vox_Sz_Callback(hObject, eventdata, handles)
    handles.p.Vox_Sz = str2double(hObject.String);
    if handles.p.Vox_Sz < 0
        handles.p.Vox_Sz = 0;
    end
    guidata(hObject,handles);  
    plot4d_plot(handles);

    
function edit_Vox_Sz_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_Area_Callback(hObject, eventdata, handles)
    %unused

function edit_Area_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function plot4d_plot(handles)
    PrepStuff(handles);
    AutoPhase(handles);
    GUIUpdate(handles);

    if ~isfield(handles,'d')
        return
    end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % create figure for display (image, spectrum and time course)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % create figure if no handle was passed or if the handle that was passed is
    % not valid any more, e.g. because the figure was closed 
    if isprop(handles.p,'figid_display') && ishandle(handles.p.figid_display)
        figure(handles.p.figid_display)
    else
        handles.p.figid_display = figure('Name','plot4d_display','NumberTitle','off');
    end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % plot various images and graphs
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    handles.edit_plotted_spectrum_as_text.String = {};  % clear before following may set...
    handles.edit_Display_pH_value.String = {}; %clear before following may set...
    % disp('==== plot4d_plot plotting images ====')
    PlotProton(handles);
    PlotCarbon(handles);
    
    UpdatePeakFits(handles);
    
    DisplayResult(handles);
    PlotSpectrum(handles);
    PlotTime(handles);

    PlotTimeSpectrumSurface(handles);

    DebugOutput(handles);


    % title overall figure
    a = axes;
    a.Position = [0.1300    0.1100    0.7750    0.85];
    a.Visible = 'off';
    filtered_filename = strrep(handles.p.carbon_file, '\', '\\');
    filtered_filename = strrep(filtered_filename, '_', '\_');
    t1 = title(filtered_filename);
%     t1.Visible = 'on';
    t1.Visible = 'off';


    % update handles
    guidata(handles.plot4d_control, handles);
    % disp('==== plot4d_plot done ====')
    % disp(' ')
    if (handles.p.fig_ppt)
        FigureReadyforPPT
    end
end

function UpdatePeakFits(handles)
    if ~handles.p.lorentz_fit_desired
        handles.p.lorentz_fit_params = [];
        
    else
        handles.p.lorentz_fit_params = [];
        % fit to spectrum (in ROI or pixel) at all timepoints, save results
        metab_data = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
        metab_data = RephaseMetabData(metab_data, handles);
        metab_data = MetabDataIndexedByPosition(metab_data, handles);
        metab_data = ApplyFlipAngleCorrectionFactors(metab_data, handles);
        
        if (handles.p.option_plot_intensity)
            metab_data = abs(metab_data);
        elseif (handles.p.option_plot_complex || handles.p.option_plot_real)
        end
        
        [fit_params, ~] = FitToSpectrum(real(squeeze(metab_data(1,1,:,1,1,1))), handles, true);
        handles.p.lorentz_fit_params = zeros(length(fit_params), size(metab_data,6));
        handles.p.lorentz_fit_params(:,1) = fit_params;
        
        for t = 2:size(metab_data,6)
            [fit_params, ~] = FitToSpectrum(real(squeeze(metab_data(1,1,:,1,1,t))), handles, true);
            handles.p.lorentz_fit_params(:,t) = fit_params;
        end
    end
end

function metab_data = MetabDataIndexedBySlice(metab_data_in, handles)
    metab_data = metab_data_in(:, :, :, handles.p.slice_carbon_val, :, :);
end

function metab_data = MetabDataIndexedByCoil(metab_data_in, handles)
    % average / index over coils
    if (~handles.p.option_plot_phase)
        if (handles.p.option_carbon_rms && (size(metab_data_in,5) > 1))
            metab_data = sqrt(mean(abs(metab_data_in).^2, 5));
        else
            metab_data = metab_data_in(:, :, :, :, handles.p.coil_carbon_val, :);
        end

    else
        % for phase, can't take absolute value before calculating, so
        % just index or take mean...
        if (handles.p.option_carbon_rms && (size(metab_data_in,5) > 1))
            metab_data = mean(metab_data_in, 5);
        else
            metab_data = metab_data_in(:, :, :, :, handles.p.coil_carbon_val, :);
        end
    end
end

function metab_data = MetabDataIndexedByFreq(metab_data_in, freq_idx_low, freq_idx_high, handles)
    if (freq_idx_high > size(metab_data_in,3))
        freq_idx_high = size(metab_data_in,3);
    end
    if (freq_idx_high < 1)
        freq_idx_high = 1;
    end
    if (freq_idx_low > freq_idx_high)
        freq_idx_low = freq_idx_high;
    end
    if (freq_idx_low < 1)
        freq_idx_low = 1;
    end


    % don't do fit lookup for images, or when fitting hasn't been done
    if (handles.p.lorentz_fit_desired && size(metab_data_in,1) == 1 && size(metab_data_in,2) == 1)
        % average / index over frequency in metab data
        if (size(handles.p.lorentz_fit_params,1) < 1)
            error('No fit data to use for indexing!')
        end
        if (freq_idx_high ~= freq_idx_low)
            disp('Indexing fitted data over multiple freqs not yet supported')
            % take mean over range of frequencies
            metab_data = mean(metab_data_in(:,:,freq_idx_low:freq_idx_high,:,:,:),3);
            return;
        end

        
        % determine indices in lorentz fit parameters corresponding to each
        % metabolite frequency
        shown_peak_indices = [2 2 2 2];
        if (handles.p.option_show_f1)
            shown_peak_indices(2:end) = shown_peak_indices(2:end) + 3;
        end
        if (handles.p.option_show_f2)
            shown_peak_indices(3:end) = shown_peak_indices(3:end) + 3;
        end
        if (handles.p.option_show_f3)
            shown_peak_indices(4:end) = shown_peak_indices(4:end) + 3;
        end
        
        
        % is it one of the fit peak freqs, which is also enabled for display now?
        if (handles.p.option_show_f1 && freq_idx_low == FreqToSliderIdx(handles.p.f1_val, handles))
            metab_data = handles.p.lorentz_fit_params(shown_peak_indices(1),:);
            
        elseif (handles.p.option_show_f2 && freq_idx_low == FreqToSliderIdx(handles.p.f2_val, handles))
            metab_data = handles.p.lorentz_fit_params(shown_peak_indices(2),:);
            
        elseif (handles.p.option_show_f3 && freq_idx_low == FreqToSliderIdx(handles.p.f3_val, handles))
            metab_data = handles.p.lorentz_fit_params(shown_peak_indices(3),:);
            
        elseif (handles.p.option_show_f4 && freq_idx_low == FreqToSliderIdx(handles.p.f4_val, handles))
            metab_data = handles.p.lorentz_fit_params(shown_peak_indices(4),:);
            
        else
            metab_data = handles.p.lorentz_fit_params(1,:); % timeseries of constant background
        end
        metab_data = metab_data.';
        
    else
        % average / index over frequency in metab data
        if (freq_idx_high <= freq_idx_low)
            % indlex single frequency
            metab_data = metab_data_in(:,:,freq_idx_low,:,:,:);
        else
            % take mean over range of frequencies
            metab_data = mean(metab_data_in(:,:,freq_idx_low:freq_idx_high,:,:,:),3);
        end
    end
end

function metab_data = MetabDataIndexedByTime(metab_data_in, time_idx_low, time_idx_high, handles)
    % picks single timepoint or averages (mean) over range of specified
    % range of timepoints
    
    if (time_idx_high > size(metab_data_in, 6))
        time_idx_high = size(metab_data_in, 6);
    end
    if (time_idx_high < 1)
        time_idx_high = 1;
    end
    if (time_idx_low > time_idx_high)
        time_idx_low = time_idx_high;
    end
    if (time_idx_low < 1)
        time_idx_low = 1;
    end

    
    metab_data = ApplyFlipAngleCorrectionFactors(metab_data_in, handles);
    
    
    % average / index over time
    if (time_idx_high <= time_idx_low)
        metab_data = metab_data(:,:,:,:,:,time_idx_low);
    else
        metab_data = mean(metab_data(:,:,:,:,:,time_idx_low:time_idx_high), 6);
    end
end

function metab_data = MetabDataIndexedByPosition(metab_data_in, handles)
    % is there a defined ROI and is averaging over it enabled?
    average_over_roi = (handles.p.specandtime_roi == 1);
   
    if (average_over_roi)
        volume_mask = zeros(size(metab_data_in));
        if size(volume_mask,1) == size(handles.p.roi_mask,1) && size(volume_mask,2) == size(handles.p.roi_mask,2)
            for freq = 1:size(volume_mask,3)
                for slice = 1:size(volume_mask,4)
                    for coil = 1:size(volume_mask,5)
                        for time = 1:size(volume_mask,6)
                            volume_mask(:,:,freq,slice,coil,time) = handles.p.roi_mask;
                        end
                    end
                end
            end
            volume_mask(metab_data_in==0) = 0;
            metab_data = volume_mask .* metab_data_in;
            metab_data = sum(sum(metab_data,2),1) ./ sum(sum(volume_mask,2),1);
        else
            idx1 = min(max(1, handles.p.pointer2d(1)), size(metab_data_in,1));
            idx2 = min(max(1, handles.p.pointer2d(2)), size(metab_data_in,2));
            metab_data = metab_data_in(idx1, idx2, :, :, :, :);
            disp('WARNING: ROI_mask and Data to not match size (unwanted) -> No ROI averaging done (single voxel treatment applied)')
        end
    else
        % just index by cursor position
        idx1 = min(max(1, handles.p.pointer2d(1)), size(metab_data_in,1));
        idx2 = min(max(1, handles.p.pointer2d(2)), size(metab_data_in,2));
        metab_data = metab_data_in(idx1, idx2, :, :, :, :);
    end
end

function pH_data = pHDataIndexedByPosition(pH_data_in, handles)
    average_over_roi = (handles.p.specandtime_roi == 1);
    if (average_over_roi)
        volume_mask = zeros(size(pH_data_in));
        if size(volume_mask,1) == size(handles.p.roi_mask,1) && size(volume_mask,2) == size(handles.p.roi_mask,2)
            for comp = 1:size(volume_mask,3)
                volume_mask(:,:,comp) = handles.p.roi_mask;   
            end
            volume_mask(pH_data_in==0) = 0;
            pH_data = volume_mask .* pH_data_in;
            tmp = pH_data(:); %Following four lines: Get the three lowest pH-values in ROI and display them in the command window!!!
            tmp = tmp(tmp ~= 0);
            tmp = sort(tmp);
            if ~isempty(tmp) && max(size(tmp)) == 3
                txt = ['Lowest pH-values in ROI: 1st: ', num2str(tmp(1)), '  2nd: ', num2str(tmp(2)), '  3rd: ', num2str(tmp(3))];
                disp(txt)
            end
            pH_data = sum(sum(pH_data,2),1) ./ sum(sum(volume_mask,2),1);
            
        else
            idx1 = min(max(1, handles.p.pointer2d(1)), size(pH_data_in,1));
            idx2 = min(max(1, handles.p.pointer2d(2)), size(pH_data_in,2));
            pH_data = pH_data_in(idx1, idx2, :, :, :, :);
            disp('pH-Data WARNING: ROI_mask and Data to not match size (unwanted) -> No ROI averaging done (single voxel treatment applied)')
        end    
  
    else
        % just index by cursor position
        idx1 = min(max(1, handles.p.pointer2d(1)), size(pH_data_in,1));
        idx2 = min(max(1, handles.p.pointer2d(2)), size(pH_data_in,2));
        pH_data = pH_data_in(idx1, idx2, :, :, :, :);
    end
    
end    

function metab_image = GetMetabImage(handles)
    metab_image = zeros(8,8); % default, to be replaced
    if ~isfield(handles,'d') || ~isfield(handles.d, 'carbon_recon')
        disp('No metabolic data to plot!')
        return
    end
    if (size(handles.d.carbon_recon.image,1)==1 && size(handles.d.carbon_recon.image,2)==1)
        metab_image = 0;
        return
    end

    metab_data = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
    metab_data = RephaseMetabData(metab_data, handles);
    
    if ~handles.p.option_timestep_sum
        time_idx_low = handles.p.timestep_val;
        time_idx_high = time_idx_low + handles.p.timestep_length - 1;
    else
        time_idx_low = 1;
        time_idx_high = size(metab_data, 6);
    end
    metab_data = MetabDataIndexedByTime(metab_data, time_idx_low, time_idx_high, handles);

    
    metab_data = MetabDataIndexedByCoil(metab_data, handles);

    
    if (handles.p.option_plot_freq1_offset)
        % metab_data dicarded here; just use fit freq indices
        if (isfield(handles.d,'carbon_image_freq1_idx'))
            metab_image = handles.p.hz(handles.d.carbon_image_freq1_idx) - handles.p.f1_val;
        else
            metab_image = zeros(size(metab_data,1), size(metab_data,2));
        end
        metab_image = metab_image + handles.p.intensity_offset;

    elseif (handles.p.option_plot_freq4_offset)
        % metab_data dicarded here; just use fit freq indices
        if (isfield(handles.d,'carbon_image_freq4_idx'))
            metab_image = handles.p.hz(handles.d.carbon_image_freq4_idx) - handles.p.f4_val;
        else
            metab_image = zeros(size(metab_data,1), size(metab_data,2));
        end
        metab_image = metab_image +  + handles.p.intensity_offset;
        
    elseif handles.p.option_plot_pH_map == 1
        if handles.p.option_plot_pH_map_mean == 1
            metab_image = handles.p.pHmapMean;
        elseif handles.p.option_plot_pH_map_main == 1
            metab_image = handles.p.pHmapMain;
        elseif handles.p.option_plot_pH_map_compartment == 1
            Sz = size(handles.p.pHmap74);
            metab_image = zeros([Sz, 3]);
            metab_image(:,:,1) = handles.p.pHmap74;
            metab_image(:,:,2) = handles.p.pHmap70;
            metab_image(:,:,3) = handles.p.pHmap65;
        else
            disp('in GetMetabImage: no pH map created (yet) to plot...!')
            return
        end
            
    elseif isfield(handles,'d') && isfield(handles.d,'carbon_recon') && isfield(handles.d.carbon_recon,'image')

        if ~handles.p.option_freq_sum
            freq_low_idx = FreqToSliderIdx(handles.p.freq_val, handles);
            freq_high_idx = FreqToSliderIdx(handles.p.freq_val + handles.p.freq_length, handles);
        else
            freq_low_idx = 1;
            freq_high_idx = length(handles.p.hz);
        end
        
        if (handles.p.option_plot_intensity)
            % average over specified frequency range
            metab_image = MetabDataIndexedByFreq(abs(metab_data), freq_low_idx, freq_high_idx, handles);
            metab_image = metab_image + handles.p.intensity_offset;

        elseif (handles.p.option_plot_complex || handles.p.option_plot_real)
            metab_image = real(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
            metab_image = metab_image + handles.p.intensity_offset;
        
        elseif (handles.p.option_plot_phase)
            metab_image = angle(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
            metab_image = metab_image + handles.p.intensity_offset;

        elseif (handles.p.option_plot_lac_pyr)
            freq4_idx = FreqToSliderIdx(handles.p.f4_val, handles);
            freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
            metab_image = GetMetabRatio(metab_data, freq4_idx, freq1_idx, handles);
            metab_image = metab_image + handles.p.intensity_offset;
            
        elseif (handles.p.option_plot_ala_pyr)
            freq2_idx = FreqToSliderIdx(handles.p.f2_val, handles);
            freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
            metab_image = GetMetabRatio(metab_data, freq2_idx, freq1_idx, handles);
            metab_image = metab_image + handles.p.intensity_offset;
            
        elseif (handles.p.option_plot_diff_norm)
            freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
            freq2_idx = FreqToSliderIdx(handles.p.f2_val, handles);
            freq3_idx = FreqToSliderIdx(handles.p.f3_val, handles);
            metab_image = GetMetabFraction2minus1over3(metab_data, freq1_idx, freq2_idx, freq3_idx, handles);
            metab_image = metab_image + handles.p.intensity_offset;
 
        elseif (handles.p.option_plot_lac_allfreqs)
            freq4_idx = FreqToSliderIdx(handles.p.f4_val, handles);
            metab_image = GetMetabFractionOverAllFreqsMean(metab_data, freq4_idx, handles);
            metab_image = metab_image + handles.p.intensity_offset;
            
        else
            error('not sure what carbon info to plot...')
        end
    end
end

function total_carbon_image = GetTotalCarbonImage(handles)
    total_carbon_image = zeros(8,8); % default, to be replaced
    if ~isfield(handles,'d') || ~isfield(handles.d, 'carbon_recon')
        disp('No metabolic data to plot!')
        return
    end


    total_carbon_image = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
    total_carbon_image = RephaseMetabData(total_carbon_image, handles);
    
    if ~handles.p.option_timestep_sum
        time_idx_low = handles.p.timestep_val;
        time_idx_high = time_idx_low + handles.p.timestep_length - 1;
    else
        time_idx_low = 1;
        time_idx_high = size(total_carbon_image, 6);
    end        
    total_carbon_image = MetabDataIndexedByTime(total_carbon_image, time_idx_low, time_idx_high, handles);

    
    total_carbon_image = MetabDataIndexedByCoil(total_carbon_image, handles);
   
    freq_low_idx = 1;
    freq_high_idx = length(handles.p.hz);
    
    total_carbon_image = abs(MetabDataIndexedByFreq(total_carbon_image, freq_low_idx, freq_high_idx, handles));
end

function metab_data = RephaseMetabData(metab_data_in, handles)
    if (length(handles.p.hz) ~= size(metab_data_in, 3))
        disp('skipping rephasing metab data due to size inconsistency... maybe ISPSCI?')
        metab_data = metab_data_in;
        return
    end

    % apply phase factors...
    phase0_factor = exp(-1i * handles.p.spectrum_phase0 / 180 * pi());
    phase1_factor = exp(-1i * handles.p.hz' * handles.p.spectrum_phase1 / 1000 / 180 * pi());
    phase1_factor = permute(phase1_factor, [2 3 1 4 5 6]);
    
    if (handles.p.do_freq_fft)
        metab_data = phase0_factor * metab_data_in .* phase1_factor;
    else
        % do fft, apply shift, then undo fft to get back to the phased FID
        spec = fftshift(fft(metab_data_in,[],3),3);
        spec = phase0_factor * spec .* phase1_factor;
        metab_data = ifft(ifftshift(spec,3),[],3);
    end
end

function result = isodd(x)
    result = (mod(x,2) == 1);
end

function [spectrum, complex_spectrum] = GetMetabSpectrum(handles)  %Never forget to update function in 4dplot as well!!!
    spectrum = zeros(1,2048); % default, to be replaced
    complex_spectrum = spectrum;
    if ~isfield(handles,'d') || ~isfield(handles.d, 'carbon_recon')
        disp('No metabolic data to make spectrum of!')
        return
    end
    if handles.p.option_plot_pH_map == 1 && (isfield(handles.d.carbon_recon,'volume') || isfield(handles.d.carbon_recon,'single_voxel_volume'))
        if ~(handles.p.fit_current_spectrum)
            metab_data = handles.d.carbon_recon.volume;
        else
            metab_data = handles.d.carbon_recon.single_voxel_volume - handles.p.intensity_offset;
        end
    else 
        metab_data = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
        metab_data = RephaseMetabData(metab_data, handles);
    end
    

    if ~handles.p.option_timestep_sum
        time_idx_low = handles.p.timestep_val;
        time_idx_high = time_idx_low + handles.p.timestep_length - 1;
    else
        time_idx_low = 1;
        time_idx_high = size(metab_data, 6);
    end
    metab_data_multicoil = MetabDataIndexedByTime(metab_data, time_idx_low, time_idx_high, handles);

    
    % get absolute spectrum. note: indexing by coil takes absolute value
    metab_data = MetabDataIndexedByCoil(metab_data_multicoil, handles);

    if handles.p.option_plot_phase
        metab_data = angle(metab_data);
    else
        if isreal(metab_data)
            metab_data = metab_data + handles.p.intensity_offset;
        else
            metab_data = abs(metab_data) + handles.p.intensity_offset;
        end
    end
    metab_data = MetabDataIndexedByPosition(metab_data, handles);
    spectrum = squeeze(metab_data); % magnitude spectrum to output    
    
    
    % get complex spectrum: manually do single-coil indexing.
    if (handles.p.option_carbon_rms && (size(metab_data_multicoil,5) > 1))
        disp('Warning: Cant generate complex spectrum with RMS combination of coils')
    end
    metab_data = MetabDataIndexedByCoil(metab_data_multicoil, handles);
    metab_data = metab_data + handles.p.intensity_offset;                       %Martin G, 2020.04.03, added: also add intensity offset to real part of complex spectrum
    metab_data = MetabDataIndexedByPosition(metab_data, handles);
    complex_spectrum = squeeze(metab_data); % complex spectrum to output
end

function ratios = GetMetabRatio(metab_data_in, freq1_idx, freq2_idx, handles)
    if (handles.p.lorentz_fit_desired)
        disp(' --- GetMetabRatio with Lorentzian fits ---')

        % check that currently enabled frequencies include those of
        % the selected ratio to plot. if not, can't use areas as ratio...
        if (handles.p.option_plot_lac_pyr)
            if ~handles.p.option_show_f1 || ~handles.p.option_show_f4
                error('cant do ratio of freqs 4 and 1 unless they are both enabled');
            end
            
        elseif (handles.p.option_plot_ala_pyr)
            if ~handles.p.option_show_f1 || ~handles.p.option_show_f2
                error('cant do ratio of freqs 2 and 1 unless they are both enabled');
            end
            
        else
            % not sure what is being plotted... just take the intensities
            error('not sure what freq ratios to check / use in GetMetabRatio');
        end
        
        % fit peaks around currently enabled display frequencies, return
        % ratios based on the areas of those peaks that correspond to the
        % requested frequency indices
        
        % TODO: THIS!
        
        ratios = 1;
    end
    if (true)   % todo: make else case for above
%         disp(' --- GetMetabRatio with basic spectrum intensity ratio ---');
        metab1_data = abs(metab_data_in(:,:,freq1_idx,:,:,:)) + handles.p.intensity_offset;
        metab2_data = abs(metab_data_in(:,:,freq2_idx,:,:,:)) + handles.p.intensity_offset;
        ratios = metab1_data ./ metab2_data;
    end
end

function fractions = GetMetabFraction2minus1over3(metab_data_in, freq1_idx, freq2_idx, freq3_idx, handles)
    % todo: fit peaks around specified frequencies, generate map of the
    % ratios of their areas    
    metab1_data = abs(metab_data_in(:,:,freq1_idx,:,:,:)) + handles.p.intensity_offset;
    metab2_data = abs(metab_data_in(:,:,freq2_idx,:,:,:)) + handles.p.intensity_offset;
    metab3_data = abs(metab_data_in(:,:,freq3_idx,:,:,:)) + handles.p.intensity_offset;
    fractions = (metab2_data - metab1_data) ./ metab3_data;
end

function fractions = GetMetabFractionOverAllFreqsMean(metab_data_in, freq_idx, handles)
    % todo: fit peaks around specified frequencies, generate map of the
    % ratios of their areas    
    metab_data = abs(metab_data_in(:,:,freq_idx,:,:,:)) + handles.p.intensity_offset;
    metab_data_freqsum = mean(abs(metab_data_in),3) + handles.p.intensity_offset;
    fractions = metab_data ./ metab_data_freqsum;
end

function [timeseries, complex_timeseries, description] = GetMetabTimeSeries(handles)
%     disp(['GetMetabTimeSeries(~ ' num2str(round(handles.p.freq_val + handles.p.freq_length / 2)) ')'])
    timeseries = zeros(1,6); % default, to be replaced
    complex_timeseries = timeseries;
    description = '';
    if ~isfield(handles,'d') || ~isfield(handles.d, 'carbon_recon')
        disp('No metabolic data to make spectrum of!')
        return
    end
    
    if ~handles.p.lorentz_fit_desired && handles.p.option_plot_pH_map == 0
        metab_data = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
        metab_data = RephaseMetabData(metab_data, handles);
        metab_data = MetabDataIndexedByPosition(metab_data, handles);
        metab_data = ApplyFlipAngleCorrectionFactors(metab_data, handles);
    elseif handles.p.option_plot_pH_map == 1 && ~(handles.p.fit_current_spectrum)
        if handles.p.option_plot_pH_map_mean == 1
            metab_data = MetabDataIndexedByPosition(handles.p.pHmapMean, handles);
        elseif handles.p.option_plot_pH_map_main == 1
            metab_data = MetabDataIndexedByPosition(handles.p.pHmapMain, handles);
        elseif handles.p.option_plot_pH_map_compartment == 1 
            metab_data(:,:,1) = pHDataIndexedByPosition(handles.p.pHmap74, handles);
            metab_data(:,:,2) = pHDataIndexedByPosition(handles.p.pHmap70, handles);
            metab_data(:,:,3) = pHDataIndexedByPosition(handles.p.pHmap65, handles);
            metab_data(:,:,4) = pHDataIndexedByPosition(handles.p.pHDiffZA15_74, handles);
            metab_data(:,:,5) = pHDataIndexedByPosition(handles.p.pHDiffZA15_70, handles);
            metab_data(:,:,6) = pHDataIndexedByPosition(handles.p.pHDiffZA15_65, handles);
        else
            metab_data = zeros(1,1);  % results come from fit done separately
            disp('GetTimeSeries: There seems to be something wrong with the plotting options of pH maps')
        end
    elseif handles.p.option_plot_pH_map == 1 && handles.p.fit_current_spectrum == 1
        if handles.p.option_plot_pH_map_mean == 1
            metab_data = handles.p.pHspectrumMean;
        elseif handles.p.option_plot_pH_map_main == 1
            Weights = zeros([1 3]);
            Weights(1) = handles.p.spec_peak_fit_amp(4) + handles.p.spec_peak_fit_amp(5);
            Weights(2) = handles.p.spec_peak_fit_amp(6) + handles.p.spec_peak_fit_amp(7);
            Weights(3) = handles.p.spec_peak_fit_amp(8) + handles.p.spec_peak_fit_amp(9);
            if max(Weights) == Weights(1) && max(Weights) > 0
                metab_data = handles.p.pHspectrum65;
            elseif max(Weights) == Weights(2) && max(Weights) > 0
                metab_data = handles.p.pHspectrum65;
            elseif max(Weights) == Weights(3) && max(Weights) > 0
                metab_data = handles.p.pHspectrum65;
            else
                metab_data = 0;
            end
        elseif handles.p.option_plot_pH_map_compartment == 1 
            metab_data(:,:,1) = handles.p.pHspectrum74;
            metab_data(:,:,2) = handles.p.pHspectrum70;
            metab_data(:,:,3) = handles.p.pHspectrum65;
            metab_data(:,:,4) = handles.p.pHDiffZA15_spectrum74;
            metab_data(:,:,5) = handles.p.pHDiffZA15_spectrum70;
            metab_data(:,:,6) = handles.p.pHDiffZA15_spectrum65;
        else
            metab_data = zeros(1,1);  % results come from fit done separately
            disp('GetTimeSeries: There seems to be something wrong with the plotting options of pH maps')
        end
    else
        metab_data = zeros(1,1,size(handles.d.carbon_recon.image,3));  % results come from fit done separately
    end


    if ~handles.p.option_freq_sum
        freq_low_idx = FreqToSliderIdx(handles.p.freq_val, handles);
        freq_high_idx = FreqToSliderIdx(handles.p.freq_val + handles.p.freq_length, handles);
    elseif handles.p.lorentz_fit_desired
        disp('Frequency Summing Not Supported for fitted data')
        freq_low_idx = FreqToSliderIdx(handles.p.freq_val, handles);
        freq_high_idx = freq_low_idx;
    else
        freq_low_idx = 1;
        freq_high_idx = length(handles.p.hz);
    end        
    
    
    
    % cumulative sum, before indexing by frequency.
    % todo: implement for fitted data
    if handles.p.option_cumsum && ~handles.p.lorentz_fit_desired
        if ~handles.p.option_timestep_sum
            time_idx_low = handles.p.timestep_val;
            time_idx_high = time_idx_low + handles.p.timestep_length - 1;
        else
            time_idx_low = 1;
            time_idx_high = size(metab_data, 6);
        end
        if (time_idx_low < 1)
            time_idx_low = 1;
        end
        if (time_idx_high > size(metab_data,6))
            time_idx_high = size(metab_data,6);
        end
        
        metab_data_temp = zeros(size(metab_data));
        metab_data_temp(:,:,:,:,:,time_idx_low:time_idx_high) = cumsum(metab_data(:,:,:,:,:,time_idx_low:time_idx_high), 6);
        metab_data = metab_data_temp;
        
        description = [description ' Cumulative Sum'];
    end    
    
    
    
    % Select contrast to show
    if (handles.p.option_plot_intensity) && ~handles.p.fit_current_spectrum 
        % average over specified frequency range
        metab_data = abs(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
        metab_data = metab_data + handles.p.intensity_offset;
        description = [description ' Magnitude'];
        
    elseif (handles.p.option_plot_complex || handles.p.option_plot_real) && ~handles.p.fit_current_spectrum 
        metab_data = real(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
        metab_data = metab_data + handles.p.intensity_offset;
        if (handles.p.option_plot_real)
            description = [description ' Real Part'];
        else
            description = [description ' Real and Imaginary Parts'];
        end
        
    elseif (handles.p.option_plot_phase) && ~handles.p.fit_current_spectrum 
        metab_data = angle(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
        description = [description ' Phase'];

    elseif (handles.p.option_plot_lac_pyr)
        freq4_idx = FreqToSliderIdx(handles.p.f4_val, handles);
        freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
        metab_data = GetMetabRatio(metab_data, freq4_idx, freq1_idx, handles);
        description = [description ' Freq4 / Freq1'];

    elseif (handles.p.option_plot_ala_pyr)
        freq2_idx = FreqToSliderIdx(handles.p.f2_val, handles);
        freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
        metab_data = GetMetabRatio(metab_data, freq2_idx, freq1_idx, handles);
        description = [description ' Freq2 / Freq1'];

    elseif (handles.p.option_plot_freq1_offset || handles.p.option_plot_freq4_offset)
        metab_data = abs(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
        description = [description ' Freq1 Offset'];
        
    elseif (handles.p.option_plot_diff_norm)
        freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
        freq2_idx = FreqToSliderIdx(handles.p.f2_val, handles);
        freq3_idx = FreqToSliderIdx(handles.p.f3_val, handles);
        metab_data = GetMetabFraction2minus1over3(metab_data, freq1_idx, freq2_idx, freq3_idx, handles);
        description = [description ' (Freq2 - Freq1) / Freq3'];

    elseif (handles.p.option_plot_lac_allfreqs)
        freq4_idx = FreqToSliderIdx(handles.p.f4_val, handles);
        metab_data = GetMetabFractionOverAllFreqsMean(metab_data, freq4_idx, handles);
        description = [description ' Freq4 / Mean(All Freqs)'];
    elseif (handles.p.option_plot_pH_map)
        if handles.p.option_plot_pH_map_mean == 1
            description = [description 'pH (mean)'];
        elseif handles.p.option_plot_pH_map_main == 1
            description = [description 'pH (main)'];
        elseif handles.p.option_plot_pH_map_compartment == 1
            description = [description 'pH compartments (7.4, 7.0, 6.5)'];
        end
    else
        error('not sure what carbon info to plot...')
    end
    
    
    
    if (~handles.p.lorentz_fit_desired)
        metab_data_multicoil = metab_data;
        metab_data = MetabDataIndexedByCoil(metab_data, handles);
        timeseries = squeeze(metab_data);

    
        % get complex spectrum: manually do single-coil indexing.
        if (handles.p.option_carbon_rms && (size(metab_data_multicoil,5) > 1))
            disp('Cant generate complex spectrum with RMS combination of coils')
        end
        complex_timeseries = MetabDataIndexedByCoil(metab_data_multicoil, handles);
        complex_timeseries = squeeze(complex_timeseries); % complex spectrum to output
    else
        timeseries = squeeze(metab_data);
        complex_timeseries = timeseries;
    end
end

function metab_data = GetMetabTimeSeriesFreq(freq_idx, handles)
    % disp(['GetMetabTimeSeriesFreq(' num2str(freq_idx) ')'])
    % similar to GetMetabTimeSeries but always ignores frequencies
    % in handles and just returns specified freq
    metab_data = zeros(1,6); % default, to be replaced
    if ~isfield(handles,'d') || ~isfield(handles.d, 'carbon_recon')
        disp('No metabolic data to make spectrum of!')
        return
    end
    
    if ~handles.p.lorentz_fit_desired
        metab_data = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
        metab_data = RephaseMetabData(metab_data, handles);
        metab_data = MetabDataIndexedByPosition(metab_data, handles);
        metab_data = ApplyFlipAngleCorrectionFactors(metab_data, handles);
    else
        metab_data = zeros(1,1,size(handles.d.carbon_recon.image,3));  % results come from fit done separately
    end
    
    
    metab_data = MetabDataIndexedByFreq(metab_data, freq_idx, freq_idx, handles);
    
    
    % todo: fix for fitted data
    if handles.p.option_cumsum
        if ~handles.p.option_timestep_sum
            time_idx_low = handles.p.timestep_val;
            time_idx_high = time_idx_low + handles.p.timestep_length - 1;
        else
            time_idx_low = 1;
            time_idx_high = size(metab_data, 6);
        end
        if (time_idx_low < 1)
            time_idx_low = 1;
        end
        if (time_idx_high > size(metab_data,6))
            time_idx_high = size(metab_data,6);
        end
        
        metab_data_temp = zeros(size(metab_data));
        metab_data_temp(:,:,:,:,:,time_idx_low:time_idx_high) = cumsum(metab_data(:,:,:,:,:,time_idx_low:time_idx_high), 6);
        metab_data = metab_data_temp;
    end
    
    if (handles.p.lorentz_fit_desired)
        % do nothing... coil index should have been done before fitting
    elseif (handles.p.option_carbon_rms && (size(metab_data,5) > 1))
        disp('Warning: Cant generate complex spectrum with RMS combination of coils')
        % result not actually complex after this call...
        metab_data = MetabDataIndexedByCoil(metab_data, handles);
    else
        metab_data = metab_data(:, :, :, :, handles.p.coil_carbon_val, :);
    end    
end

function fac = GetFlipAngleCorrectionFactors(handles)
    fac = 1;

    if (~handles.p.flipangle_correction_desired)
        return
    end

    % calculate the frame-to-frame flip angle correction
    corr_fa = 0;

    if HaveGEData(handles)
        if isprop(handles.p,'carbon_header') && isprop(handles.p,'timeaxis')
            corr_fa = handles.p.carbon_header.image.mr_flip;
        end

    elseif HaveBrukerData(handles)
        if isfield(handles.p.carbon_header, 'ACQ_flip_angle')
            corr_fa = handles.p.carbon_header.ACQ_flip_angle;
        else
            error('cant get Bruker flip angle from header...')
        end

    elseif HaveSiemensData(handles)
        error('flip angle correction not implemented for Siemens data')

    else
        error('unknown data type! cant get flip angle')
    end

    % doesn't really make sense to correct a 90 degree angle, as all magnetization would be used up after 1 shot in the excited slice
    if (corr_fa == 90)
       corr_fa = 0;
    end

    fac = 1 ./ (cosd(corr_fa).^(((1:length(handles.p.timeaxis))-1) * handles.p.nExcitationsPerTimestep))';
end

function metab_data = ApplyFlipAngleCorrectionFactors(metab_data_in, handles)
    if (~handles.p.flipangle_correction_desired)
        metab_data = metab_data_in;
        return
    end
    if size(metab_data_in, 6) < 2
        metab_data = metab_data_in;
        disp('No timeseries axis to apply flip angle correction to!')
        return
    end
    
    fac = GetFlipAngleCorrectionFactors(handles);
    
    sz = size(metab_data_in);
    fac_rep = ones(sz);
    for x = 1:sz(1)
        for y = 1:sz(2)
            for f = 1:sz(3)
                for s = 1:sz(4)
                    for c = 1:sz(5)
                        fac_rep(x,y,f,s,c,:) = fac;
                    end
                end
            end
        end
    end
    
    metab_data = metab_data_in .* fac_rep;
end

function spec = multi_lorentzian(params, xdata)
    % background level
    spec = ones(size(xdata)) * params(1);

    % lorentzian peaks, parameterized by height, scale parameter (width), and centre position
    for o = 1:3:(length(params)-3)
        % for each set of 3 params, add a gaussian peak to the output spectrum
        for n = 1:length(xdata)
            spec(n) = spec(n) + lorentz_dist(params(o+1), params(o+2), 0 - xdata(n) + params(o+3));
        end
    end
    
%     figure(82353)
%     plot(xdata, spec)
%     drawnow
end

function retval = lorentz_dist(ampl, scale, x)
    retval = 0;
    if (ampl ~= 0 && scale > 0)
        retval = ampl/(pi*scale*(1 + (x/scale)^2));
    end
end

function [fit_params, param_names] = FitToSpectrum(pixel_spectrum, handles, fit_lorentzians)
    pixel_spectrum = real(pixel_spectrum);
    fit_params = 0; % to be replaced, or as default in case fit fails

    % comment line for layout purposes
%     disp(['Fitting To Spectrum: ' num2str(squeeze(pixel_spectrum)')])


    maxps = max(pixel_spectrum);

    % fit parameters:
    param_names = {'Background'};
    x0 = 0;
    ub = 2*maxps;
    lb = -maxps;

    % set upper limits on search area for peak size based on total area of
    % spectrum. need to multiply by frequency axis step size to properly
    % scale area from sum of spectrum points.
    if (length(handles.p.hz) > 1)
        area = sum(abs(pixel_spectrum)) * (handles.p.hz(2) - handles.p.hz(1));
    else
        area = sum(abs(pixel_spectrum));
    end
%     disp(['total spectrum area: ' num2str(area)])

    if (handles.p.option_show_f1)
        param_names =   [param_names,  {'Peak 1 Area',  'Peak 1 Width', 'Peak 1 Freq'}];
        x0 =            [x0             area            15              handles.p.f1_val];
        ub =            [ub             area            15              handles.p.f1_val + 50];
        lb =            [lb             0               15              handles.p.f1_val - 50];
    end

    if (handles.p.option_show_f2)
        param_names =   [param_names,  {'Peak 2 Area',  'Peak 2 Width', 'Peak 2 Freq'}];
        x0 =            [x0             area            15              handles.p.f2_val];
        ub =            [ub             area            15              handles.p.f2_val + 50];
        lb =            [lb             0               15              handles.p.f2_val - 50];
    end
 
    if (handles.p.option_show_f3)
        param_names =   [param_names,  {'Peak 3 Area',  'Peak 3 Width', 'Peak 3 Freq'}];
        x0 =            [x0             area            15              handles.p.f3_val];
        ub =            [ub             area            15              handles.p.f3_val + 50];
        lb =            [lb             0               15              handles.p.f3_val - 50];
    end    
    
    if (handles.p.option_show_f4)
        param_names =   [param_names,  {'Peak 4 Area',  'Peak 4 Width', 'Peak 4 Freq'}];
        x0 =            [x0             area            15              handles.p.f4_val];
        ub =            [ub             area            15              handles.p.f4_val + 50];
        lb =            [lb             0               15              handles.p.f4_val - 50];
    end

    % fit multi-parameteric multi-Gaussian + baseline to spectrum
%     options = optimset('MaxFunEvals', 1000, 'MaxIter', 2000, ...
%                        'Display', 'iter', 'TolFun', 1e-1, ...
%                        'Display', 'off');
    options = optimset('Display', 'off');
    % blah indent to here



    try
%         disp('==== Fitting Lorentzians to pixel spectrum ====')
        if (fit_lorentzians)
            x = lsqcurvefit(@multi_lorentzian, x0, handles.p.hz.', pixel_spectrum, lb, ub, options);
        else
            x = lsqcurvefit(@multi_gaussian,   x0, handles.p.hz.', pixel_spectrum, lb, ub, options);
        end
%         disp('==== Fitting Lorentzians finished ====')
    catch
        disp('! Fit Failure !')
        return
    end

    fit_params = x;
    
%     disp(['Fit params: ' num2str(fit_params)])
end

function result = GetResultValue(handles)
    result = 0; % default, to be replaced
    
    if ~isfield(handles,'d') || ~isfield(handles.d, 'carbon_recon')
        disp('No metabolic data to process!')
        return
    end

    
    metab_data = MetabDataIndexedBySlice(handles.d.carbon_recon.image, handles);
    

    if ~handles.p.option_timestep_sum
        time_idx_low = handles.p.timestep_val;
        time_idx_high = time_idx_low + handles.p.timestep_length - 1;        
    else
        time_idx_low = 1;
        time_idx_high = size(metab_data, 6);
    end        
    metab_data = MetabDataIndexedByTime(metab_data, time_idx_low, time_idx_high, handles);
    metab_data = MetabDataIndexedByCoil(metab_data, handles);
    if handles.p.option_plot_pH_map == 1
        metab_data = [];
        if handles.p.option_plot_pH_map_mean == 1
            metab_data = pHDataIndexedByPosition(handles.p.pHmapMean, handles);
        elseif handles.p.option_plot_pH_map_main == 1
            metab_data = pHDataIndexedByPosition(handles.p.pHmapMain, handles);
        elseif handles.p.option_plot_pH_map_compartment == 1
            metab_data(:,:,1) = pHDataIndexedByPosition(handles.p.pHmap74, handles);
            metab_data(:,:,2) = pHDataIndexedByPosition(handles.p.pHmap70, handles);
            metab_data(:,:,3) = pHDataIndexedByPosition(handles.p.pHmap65, handles);
        else
            disp('in Get Result Value: no pH map created (yet) to plot...!')
            return
        end
    else
        metab_data = MetabDataIndexedByPosition(metab_data, handles);
    end
    
    % determine result value based on selected display option
    if (handles.p.option_plot_freq1_offset)
        if (isfield(handles.d,'carbon_image_freq1_idx'))
            metab_image = handles.p.hz(handles.d.carbon_image_freq1_idx) - handles.p.f1_val;
        else
            metab_image = zeros(size(metab_data,1), size(metab_data,2));
        end
        metab_image = metab_image + handles.p.intensity_offset;
        metab_image = MetabDataIndexedByPosition(metab_image, handles);

    elseif (handles.p.option_plot_freq4_offset)
        if (isfield(handles.d,'carbon_image_freq4_idx'))
            metab_image = handles.p.hz(handles.d.carbon_image_freq4_idx) - handles.p.f4_val;
        else
            metab_image = zeros(size(metab_data,1), size(metab_data,2));
        end
        metab_image = metab_image + handles.p.intensity_offset;
        metab_image = MetabDataIndexedByPosition(metab_image, handles);

    elseif isfield(handles,'d') && isfield(handles.d,'carbon_recon') && isfield(handles.d.carbon_recon,'image')
        if ~handles.p.option_freq_sum
            freq_low_idx = FreqToSliderIdx(handles.p.freq_val, handles);
            freq_high_idx = FreqToSliderIdx(handles.p.freq_val + handles.p.freq_length, handles);
        else
            freq_low_idx = 1;
            freq_high_idx = length(handles.p.hz);
        end        
        
        if (handles.p.option_plot_intensity)
            % average over specified frequency range, take magnitude -> intensity
            metab_image = abs(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
            metab_image = metab_image + handles.p.intensity_offset;
            
        elseif (handles.p.option_plot_complex || handles.p.option_plot_real)
            % average over specified frequency range, take real part
            metab_image = real(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
            metab_image = metab_image + handles.p.intensity_offset;
            
        elseif (handles.p.option_plot_phase)
            % average over frequency range, find phase angle
            metab_image = angle(MetabDataIndexedByFreq(metab_data, freq_low_idx, freq_high_idx, handles));
            metab_image = metab_image + handles.p.intensity_offset;
            
        elseif (handles.p.option_plot_lac_pyr)
            % select individual frequencies, find ratio of peak heights or areas
            freq4_idx = FreqToSliderIdx(handles.p.f4_val, handles);
            freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
            metab_image = GetMetabRatio(metab_data, freq4_idx, freq1_idx, handles);
            
        elseif (handles.p.option_plot_ala_pyr)
            % select individual frequencies, find ratio of peak heights or areas
            freq2_idx = FreqToSliderIdx(handles.p.f2_val, handles);
            freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
            metab_image = GetMetabRatio(metab_data, freq2_idx, freq1_idx, handles);
            
        elseif (handles.p.option_plot_diff_norm)
            % select individual frequencies, find ratio of peak height or
            % area difference and value
            freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
            freq2_idx = FreqToSliderIdx(handles.p.f2_val, handles);
            freq3_idx = FreqToSliderIdx(handles.p.f3_val, handles);
            metab_image = GetMetabFraction2minus1over3(metab_data, freq1_idx, freq2_idx, freq3_idx, handles);
            
        elseif (handles.p.option_plot_lac_allfreqs)
            % select individual frequency, find ratio of that peak hight or
            % area and the sum of all frequencies
            freq4_idx = FreqToSliderIdx(handles.p.f4_val, handles);
            metab_image = GetMetabFractionOverAllFreqsMean(metab_data, freq4_idx, handles);
        elseif handles.p.option_plot_pH_map == 1
            metab_image = metab_data;
        else
            error('not sure what carbon info to plot...')
        end
    end

    result = metab_image;    
end

function PrepStuff(handles)
    % safety checks on specified slices, coil, frequency
    if isfield(handles,'d') && isfield(handles.d,'carbon_recon')
        % range check selected positions...
        if (handles.p.slice_carbon_val > size(handles.d.carbon_recon.image, 4))
            handles.p.slice_carbon_val = size(handles.d.carbon_recon.image, 4);
        end
        if (handles.p.slice_carbon_val < 1)
            handles.p.slice_carbon_val = 1;
        end
        if (handles.p.coil_carbon_val > size(handles.d.carbon_recon.image, 5))
            handles.p.coil_carbon_val = size(handles.d.carbon_recon.image, 5);
        end
        if (handles.p.coil_carbon_val < 1)
            handles.p.coil_carbon_val = 1;
        end
    end
    if handles.p.freq_length < 1
        handles.p.freq_length = 1;
    end
    if isfield(handles,'p') && isfield(handles.p, 'hz')
        if (handles.p.freq_val < min(handles.p.hz))
            handles.p.freq_val = min(handles.p.hz);
        end
        if (handles.p.freq_val > max(handles.p.hz) - handles.p.freq_length)
            handles.p.freq_val = max(handles.p.hz) - handles.p.freq_length;
        end
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % create figure to choose a region of interest (ROI) if desired           %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if isprop(handles.p,'roi_draw') && handles.p.roi_draw && isfield(handles,'d') && isfield(handles.d,'proton_image')    

        % open a new figure
        fig_roi = figure('Name', 'plot4d_roi', 'NumberTitle', 'off');
        
        %inserted section to overlay proton image with pH-map for ROI drawing if desired (2020.04.17 - Martin G.)
        if (handles.p.pHmap_roi_draw)
            hold on
            % get metabolic image (intensity, ratio, phase, etc.)
            metab_image = GetMetabImage(handles);
            proton_carbon_scaling_x = size(handles.d.proton_image,1)/size(handles.d.carbon_recon.image,1);
            proton_carbon_scaling_y = size(handles.d.proton_image,2)/size(handles.d.carbon_recon.image,2);
            if proton_carbon_scaling_x ~= proton_carbon_scaling_y
                warning('axis ratio of carbon image and proton image are not equal, wrong image chosen or acquisition issues?')
            end
            metab_image = imresize(metab_image,proton_carbon_scaling_x,'bilinear');
            
            if handles.p.option_plot_pH_map_compartment == 1 
                plotted_carbon_image = permute(metab_image, [2 1 3]);

                %plot first pH_map
                if handles.p.option_show_pHmap65 == 1 && handles.p.option_plot_pH_map == 1
                    
                    carbon_image_1  = imagesc(plotted_carbon_image(:,:,3));
                    axis image
                    alpha_data_65 = ones(size(plotted_carbon_image(:,:,3))) * handles.p.option_overlay_alpha_65;
                    % total carbon image threshold
                    if (handles.p.option_total_signal_threshold ~= -Inf)
                        total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                        alpha_data_65(total_carbon_image(:,:,3) <= handles.p.option_total_signal_threshold) = 0;
                    end
                    % displayed image threshold
                    if (handles.p.option_alpha_threshold ~= -Inf)
                        alpha_data_65(plotted_carbon_image(:,:,3) <= handles.p.option_alpha_threshold) = 0;
                    end
                    %cut pH-Map to proton-Image area
                    if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                        alpha_data_65(handles.p.roi_mask_cut == 0) = 0; 
                    end  
                    set(carbon_image_1, 'AlphaData', alpha_data_65);
                    set(gca,'YDir','normal')  
                    hold on    
                end
                %plot second pH_map
                if handles.p.option_show_pHmap70 == 1 && handles.p.option_plot_pH_map == 1
                    carbon_image_2  = imagesc(plotted_carbon_image(:,:,2));
                    axis image
                    alpha_data_70 = ones(size(plotted_carbon_image(:,:,2))) * handles.p.option_overlay_alpha_70;
                    % total carbon image threshold
                    if (handles.p.option_total_signal_threshold ~= -Inf)
                        total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                        alpha_data_70(total_carbon_image(:,:,2) <= handles.p.option_total_signal_threshold) = 0;
                    end
                    % displayed image threshold
                    if (handles.p.option_alpha_threshold ~= -Inf)
                        alpha_data_70(plotted_carbon_image(:,:,2) <= handles.p.option_alpha_threshold) = 0;
                    end
                    %cut pH-Map to proton-Image area
                    if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                        alpha_data_70(handles.p.roi_mask_cut == 0) = 0; 
                    end  
                    set(carbon_image_2, 'AlphaData', alpha_data_70);
                    set(gca,'YDir','normal')
                    hold on
                end
                        %plot second pH_map
                if handles.p.option_show_pHmap74 == 1 && handles.p.option_plot_pH_map == 1
                    carbon_image_3  = imagesc(plotted_carbon_image(:,:,1));
                    axis image
                    alpha_data_74 = ones(size(plotted_carbon_image(:,:,1))) * handles.p.option_overlay_alpha_74;
                    % total carbon image threshold
                    if (handles.p.option_total_signal_threshold ~= -Inf)
                        total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                        alpha_data_74(total_carbon_image(:,:,1) <= handles.p.option_total_signal_threshold) = 0;
                    end
                    % displayed image threshold
                    if (handles.p.option_alpha_threshold ~= -Inf)
                        alpha_data_74(plotted_carbon_image(:,:,1) <= handles.p.option_alpha_threshold) = 0;
                    end
                         %cut pH-Map to proton-Image area
                    if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                        alpha_data_74(handles.p.roi_mask_cut == 0) = 0; 
                    end  
                    set(carbon_image_3, 'AlphaData', alpha_data_74);
                    set(gca,'YDir','normal')
                    hold on
                end
                if handles.p.option_show_pHmap74 == 0 && handles.p.option_show_pHmap70 == 0 && handles.p.option_show_pHmap65 == 0
                    plotted_carbon_image = permute(metab_image, [2 1 3]);

                    % plot basic metabolic image
                    carbon_image = imagesc(plotted_carbon_image);
                    axis image

                    % transparency or threshold for drawing carbon image
                    alpha_data = ones(size(plotted_carbon_image)) * handles.p.option_overlay_alpha;
                    % total carbon image threshold
                    if (handles.p.option_total_signal_threshold ~= -Inf)
                        total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                        alpha_data(total_carbon_image <= handles.p.option_total_signal_threshold) = 0;
                    end
                    % displayed image threshold
                    if (handles.p.option_alpha_threshold ~= -Inf)
                        alpha_data(plotted_carbon_image <= handles.p.option_alpha_threshold) = 0;
                    end
                    %cut pH-Map to proton-Image area
                    if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                        alpha_data(handles.p.roi_mask_cut == 0) = 0; 
                    end  
                    set(carbon_image, 'AlphaData', alpha_data(:,:,1));
                end


            else    
                plotted_carbon_image = permute(metab_image, [2 1]);

                % plot basic metabolic image
                carbon_image = imagesc(plotted_carbon_image);
                axis image

                % transparency or threshold for drawing carbon image
                alpha_data = ones(size(plotted_carbon_image)) * handles.p.option_overlay_alpha;
                % total carbon image threshold
                if (handles.p.option_total_signal_threshold ~= -Inf)
                    total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                    alpha_data(total_carbon_image <= handles.p.option_total_signal_threshold) = 0;
                end
                % displayed image threshold
                if (handles.p.option_alpha_threshold ~= -Inf)
                    alpha_data(plotted_carbon_image <= handles.p.option_alpha_threshold) = 0;
                end
                %cut pH-Map to proton-Image area
                if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1 && ~(handles.p.fit_current_spectrum)
                    alpha_data(handles.p.roi_mask_cut == 0) = 0; 
                end  
                set(carbon_image, 'AlphaData', alpha_data);
            end
            
            hold on
            % get anatomical / proton image
            plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
            plotted_proton_image = circshift(plotted_proton_image, round([handles.p.yshift handles.p.xshift]));
            plotted_proton_image = plotted_proton_image / max(max(plotted_proton_image));

            % plot over top of carbon image
            ppi_sz = size(plotted_proton_image);    
            plotted_proton_image_rgb = zeros(ppi_sz(1), ppi_sz(2), 3);
            for n = 1:3
                plotted_proton_image_rgb(:,:,n) = plotted_proton_image;
            end
            metab_sz = size(metab_image);
            proton_image = image(plotted_proton_image_rgb, 'XData', [0 metab_sz(1)] + 0.5, 'YData', [0 metab_sz(2)] + 0.5);
            % draw and label the proton image
            set(gca, 'YDir', 'normal')
            title(sprintf('proton image (slice=%d)', handles.p.slice_proton_val), 'FontSize', 8),
            colormap(gca,'gray')
            axis square
            hold off
            
            
            % reorder so carbon / functional image is over top of anatomical (for transparency see-through purposes)
            if handles.p.option_plot_pH_map == 1 && handles.p.option_plot_pH_map_compartment == 1 
                if handles.p.option_show_pHmap74 == 1
                    uistack(carbon_image_3, 'top')
                end
                if handles.p.option_show_pHmap70 == 1
                    uistack(carbon_image_2, 'top')
                end
                if handles.p.option_show_pHmap65 == 1
                    uistack(carbon_image_1, 'top')
                end  
            else
                uistack(carbon_image, 'top')
            end
            uistack(proton_image,'bottom')

            % scaling window for carbon data
            if (~handles.p.window_auto) && ~(handles.p.option_plot_pH_map)
                % use user-specified range
                caxis([handles.p.window_val handles.p.window_val + handles.p.window_length])

            elseif (handles.p.option_plot_pH_map)
                if (~handles.p.pH_window_auto)
                    % use user-specified range
                    caxis([handles.p.pH_window_val handles.p.pH_window_val + handles.p.pH_window_length])

                elseif handles.p.option_plot_pH_map_compartment == 1 
                    plotted_carbon_image_temp3 = NaN(size(plotted_carbon_image));
                    if handles.p.option_show_pHmap74 == 1
                        plotted_carbon_image_temp = plotted_carbon_image(:,:,1);
                        plotted_carbon_image_temp(alpha_data_74 <= 0) = NaN;
                        plotted_carbon_image_temp3(:,:,1) = plotted_carbon_image_temp;
                    end
                    if handles.p.option_show_pHmap70 == 1
                        plotted_carbon_image_temp = plotted_carbon_image(:,:,2);
                        plotted_carbon_image_temp(alpha_data_70 <= 0) = NaN;
                        plotted_carbon_image_temp3(:,:,2) = plotted_carbon_image_temp;
                    end
                    if handles.p.option_show_pHmap65 == 1
                        plotted_carbon_image_temp = plotted_carbon_image(:,:,3);
                        plotted_carbon_image_temp(alpha_data_65 <= 0) = NaN;
                        plotted_carbon_image_temp3(:,:,3) = plotted_carbon_image_temp;
                    end
                    plotted_max = (max(max(max(plotted_carbon_image_temp3))));
                    if (isnan(plotted_max))
                        % fall back to ignoring alpha
                        plotted_max = max(max(max(plotted_carbon_image)));
                    end
                    plotted_min = (min(min(min(plotted_carbon_image_temp3))));
                    if (isnan(plotted_min))
                        % fall back to ignoring alpha
                        plotted_min = min(min(min(plotted_carbon_image)));
                    end  

                    if (plotted_min < plotted_max)
                        % avoid adjusting if min/max are the same as this causes a crash
                        caxis([plotted_min plotted_max])
                    end
                elseif handles.p.option_plot_pH_map_mean == 1 || handles.p.option_plot_pH_map_main == 1
                    % determine range from min/max of what is plotted (accounting for transparency)

                    % set transparent pixels to NaN so they will be ignored in min/max considerations
                    plotted_carbon_image_temp = plotted_carbon_image;
                    plotted_carbon_image_temp(alpha_data <= 0) = NaN;
                    plotted_max = max(max(plotted_carbon_image_temp));
                    if (isnan(plotted_max))
                        % fall back to ignoring alpha
                        plotted_max = max(max(plotted_carbon_image));
                    end
                    plotted_min = min(min(plotted_carbon_image_temp));
                    if (isnan(plotted_min))
                        % fall back to ignoring alpha
                        plotted_min = min(min(plotted_carbon_image));
                    end    

                    if (plotted_min < plotted_max)
                        % avoid adjusting if min/max are the same as this causes a crash
                        caxis([plotted_min plotted_max])
                    end
                else
                    disp('there is something wrong with the plotting options of the pH maps...')
                end

            else
                % determine range from min/max of what is plotted (accounting for transparency)

                % set transparent pixels to NaN so they will be ignored in min/max considerations
                plotted_carbon_image_temp = plotted_carbon_image(:,:,1);
                plotted_carbon_image_temp(alpha_data <= 0) = NaN;
                plotted_max = max(max(plotted_carbon_image_temp));
                if (isnan(plotted_max))
                    % fall back to ignoring alpha
                    plotted_max = max(max(plotted_carbon_image));
                end
                plotted_min = min(min(plotted_carbon_image_temp));
                if (isnan(plotted_min))
                    % fall back to ignoring alpha
                    plotted_min = min(min(plotted_carbon_image));
                end    

                if (plotted_min < plotted_max)
                    % avoid adjusting if min/max are the same as this causes a crash
                    caxis([plotted_min plotted_max])
                end
            end

            set(gca,'YDir','normal')
            if strcmp(handles.p.option_colourmap,'default')
                colormap(gca, handles.p.option_colourmap)
            else
                cmp = colormap(gca, handles.p.option_colourmap);
            end
            if (handles.p.invert_colormap) && ~(strcmp(handles.p.option_colourmap,'default'))
                colormap(gca,flipud(cmp))
            end
        else 
        %end inserted section
        
            plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
            plotted_proton_image = circshift(plotted_proton_image, round([handles.p.yshift handles.p.xshift]));
            %draw and label the proton image
            imagesc(plotted_proton_image)
            set(gca, 'YDir', 'normal')
            title(sprintf('proton image (slice=%d)', handles.p.slice_proton_val), 'FontSize', 8),
            xlabel('x')
            ylabel('y')
            colormap(gca,'gray')
            colorbar
            axis square
        end

        % display help to choose and save the region of interest
        disp('Please choose the desired region of interest by clicking in the proton image.');
        disp('Double-click to add a final vertex to the polygon and close the polygon.');
        disp('Right-click to close the polygon without adding a vertex.');
        disp('You can adjust the position of the polygon and individual vertices in the polygon by clicking and dragging.');
        disp('After positioning and sizing the polygon, create the mask by either double-clicking over the polygon or choosing Create Mask from the tool''s context menu.');
        disp('To delete the polygon, press Backspace, Escape or Delete, or choose the Cancel option from the context menu.');
        disp('If the polygon is deleted, all return values are set to empty.');

        [handles.p.roi_mask, handles.p.roi_xi, handles.p.roi_yi] = roipoly;
        close(fig_roi);

        % plotted proton image has been permuted, so the generated roi_mask is
        % sized and oriented to match that, and needs to be permuted as well to
        % match the orientation of the persistently stored proton or carbon
        % image reconstructions, so as to be useful for averaging over it
        handles.p.roi_mask = permute(handles.p.roi_mask, [2 1]);

        % record / set GUI state that finished drawing the region of interest
        % is completed
        handles.p.roi_draw = 0;
        fprintf('\nRegion of interest successfully created\n');
    end
    
    if isprop(handles.p,'roi_draw_cut') && handles.p.roi_draw_cut && isfield(handles,'d') && isfield(handles.d,'proton_image') && ~(handles.p.cut_roi_loaded) 

        % open a new figure
        fig_roi = figure('Name', 'plot4d_roi', 'NumberTitle', 'off');

        plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
        plotted_proton_image = circshift(plotted_proton_image, round([handles.p.yshift handles.p.xshift]));
        % draw and label the proton image
        imagesc(plotted_proton_image)
        set(gca, 'YDir', 'normal')
        title(sprintf('proton image (slice=%d)', handles.p.slice_proton_val), 'FontSize', 8),
        xlabel('x')
        ylabel('y')
        colormap(gca,'gray')
        colorbar
        axis square

        % display help to choose and save the region of interest
        disp('Please choose ROI to cut pH map, the whole process works similar to generating a ROI for the metabolic image')

        [handles.p.roi_mask_cut, handles.p.roi_xi_cut, handles.p.roi_yi_cut] = roipoly;
        close(fig_roi);

        % plotted proton image has been permuted, so the generated roi_mask is
        % sized and oriented to match that, and needs to be permuted as well to
        % match the orientation of the persistently stored proton or carbon
        % image reconstructions, so as to be useful for averaging over it
        handles.p.roi_mask_cut = permute(handles.p.roi_mask_cut, [2 1]);

        % record / set GUI state that finished drawing the region of interest
        % is completed
        handles.p.roi_draw_cut = 0;
        fprintf('\nRegion of interest for proton cut successfully created\n');
    else
        handles.p.roi_draw_cut = 0;
    end

    % set mouse pointer to center if the user has not clicked yet
    if ~isprop(handles.p, 'pointer2d')
        handles.p.addprop('pointer2d');
        handles.p.pointer2d = [1 1];
        if isfield(handles,'d') && isfield(handles.d,'carbon_recon') && isfield(handles.d.carbon_recon,'image')
            handles.p.pointer2d(1) = floor(size(handles.d.carbon_recon.image,1)/2);
            handles.p.pointer2d(2) = floor(size(handles.d.carbon_recon.image,2)/2);
        else
            handles.p.pointer2d = [1 1];
        end
    end

    if ~isprop(handles.p, 'drag_start_pointer_pos2d')
        handles.p.addprop('drag_start_pointer_pos2d');
        handles.p.drag_start_pointer_pos2d = [1 1];
        handles.p.addprop('actively_window_level_dragging');
        handles.p.actively_window_level_dragging = 0;
        handles.p.addprop('actively_pH_window_level_dragging');
        handles.p.actively_pH_window_level_dragging = 0;
        handles.p.addprop('actively_phasing_dragging');
        handles.p.actively_phasing_dragging = 0;
    end


    % calculate the carbon ROI mask from the proton ROI polygon
    if isfield(handles,'d') && isfield(handles.d, 'proton_image') && isfield(handles.d,'carbon_recon') && isprop(handles.p,'roi_xi') && isprop(handles.p,'roi_yi')

        proton_carbon_scaling_x = size(handles.d.proton_image,1)/size(handles.d.carbon_recon.image,1);
        proton_carbon_scaling_y = size(handles.d.proton_image,2)/size(handles.d.carbon_recon.image,2);

        % ROIs were drawn on the permuted proton image, so their aspect ratio
        % will be wrong in the case of a non-square image, unless the sizes are
        % permuted
        carbon_recon_sz = size(handles.d.carbon_recon.image);
        proton_recon_sz = size(handles.d.proton_image);
        handles.p.roi_mask = poly2mask(((handles.p.roi_xi - 0.5) / proton_carbon_scaling_x) + 0.5,...
                                       ((handles.p.roi_yi - 0.5) / proton_carbon_scaling_y) + 0.5,...
                                       carbon_recon_sz(2), ...
                                       carbon_recon_sz(1));
        % but need to permute result back to match stored shape of carbon recon
        handles.p.roi_mask = permute(handles.p.roi_mask, [2 1]);
        
        handles.p.roi_mask_1H = poly2mask((handles.p.roi_xi - 0.5) + 0.5,...           % (2020.04.17 - Martin G. generate a Second ROI-Mask with size of proton image to calculate ROI-Area more accurately)
                                       (handles.p.roi_yi - 0.5) + 0.5,...
                                       proton_recon_sz(2), ...
                                       proton_recon_sz(1));
        % but need to permute result back to match stored shape of carbon recon
        handles.p.roi_mask_1H = permute(handles.p.roi_mask_1H, [2 1]);
    end
    
    % calculate the pH Cut ROI mask from the proton ROI polygon
    if isfield(handles,'d') && isfield(handles.d, 'proton_image') && isfield(handles.d,'carbon_recon') && isprop(handles.p,'roi_xi_cut') && isprop(handles.p,'roi_yi_cut') && ~(handles.p.cut_roi_loaded)

        proton_carbon_scaling_x = size(handles.d.proton_image,1)/size(handles.d.carbon_recon.image,1);
        proton_carbon_scaling_y = size(handles.d.proton_image,2)/size(handles.d.carbon_recon.image,2);

        % ROIs were drawn on the permuted proton image, so their aspect ratio
        % will be wrong in the case of a non-square image, unless the sizes are
        % permuted
        carbon_recon_sz = size(handles.d.carbon_recon.image);
        handles.p.roi_mask_cut = poly2mask(((handles.p.roi_xi_cut - 0.5) / proton_carbon_scaling_x) + 0.5,...
                                       ((handles.p.roi_yi_cut - 0.5) / proton_carbon_scaling_y) + 0.5,...
                                       carbon_recon_sz(2), ...
                                       carbon_recon_sz(1));
        % but need to permute result back to match stored shape of carbon recon
        % handles.p.roi_mask_cut = permute(handles.p.roi_mask_cut, [2 1]);
    end
end

function AutoPhase(handles)
    if ~handles.p.autophase
        return
    end

    handles.p.autophase = 0;

    if (handles.p.option_carbon_rms && size(handles.d.carbon_recon.image,5) > 1)
        disp('Cant phase RMS data; Pick just one coil')
        return
    end

    
    if (handles.p.fix_click_phase)
        % determine phase at middle click frequency before changing linear
        % phase factor
        middle_freq = (handles.p.freq_val + handles.p.freq_length / 2);
        old_middle_freq_phase = handles.p.spectrum_phase0 + middle_freq * handles.p.spectrum_phase1 / 1000;
        old_middle_freq_phase = mod(old_middle_freq_phase + 180, 360) - 180;
    end
        
    % reset before autodetermining phase...
    orig_phase0 = handles.p.spectrum_phase0;
    orig_phase1 = handles.p.spectrum_phase1;
    handles.p.spectrum_phase0 = 0;
    handles.p.spectrum_phase1 = 0;
    [~, complex_spectrum] = GetMetabSpectrum(handles);

    
    % if currently plotting FID, switch to spectrum before attempting
    % to determine phase factors
    if (~handles.p.do_freq_fft)
        complex_spectrum = fftshift(fft(complex_spectrum));
    end
    

    % find index with highest spectral intensity
    spectrum_mag = abs(complex_spectrum);
    [~, max_mag_idx] = max(spectrum_mag);
    if (max_mag_idx > length(spectrum_mag) || max_mag_idx < 1)
        max_mag_idx = 1;
    end

    % scan over phasing factors to find "optimum"
    best_ph0 = orig_phase0;
    best_ph1 = orig_phase1;
    best_area = Inf;

    areas = [];
    ph1s = [];

    for ph1 = -10000:1:10000
        phase1_factor = exp(-1i * handles.p.hz' * ph1 / 1000 / 180 * pi());
        ph1s = [ph1s ph1]; %#ok<AGROW>
        linear_phased_spectrum = complex_spectrum .* phase1_factor;

        ph0 = angle(linear_phased_spectrum(max_mag_idx));
        phase0_factor = exp(-1i * ph0);
        phased_spectrum = linear_phased_spectrum * phase0_factor;

        area = -min(real(phased_spectrum));%abs(sum(imag(phased_spectrum)));
        areas = [areas area];

        if (area < best_area)
            best_ph0 = ph0;
            best_ph1 = ph1;
            best_area = area;
        end
    end

    % figure(2359)
    % plot(1:length(phased_spectrum), real(phased_spectrum), '-b', ...
    %      1:length(phased_spectrum), imag(phased_spectrum), '-r');
    % title(num2str(ph1))
    % 
    % figure(2353)
    % plot(ph1s, areas, '-', best_ph1, best_area, '*')
    % drawnow

    handles.p.spectrum_phase0 = best_ph0 * 180 / pi();
    handles.p.spectrum_phase1 = best_ph1;
    
    
    if (handles.p.fix_click_phase)
        % restore phase at click freq
        
        % adjust 0th order phase to restore middle click freq phase
        new_base_middle_freq_phase = middle_freq * handles.p.spectrum_phase1 / 1000;
        new_base_middle_freq_phase = mod(new_base_middle_freq_phase + 180, 360) - 180;
        
        phase_diff = old_middle_freq_phase - new_base_middle_freq_phase;
        phase_diff = mod(phase_diff + 180, 360) - 180;
        
        handles.p.spectrum_phase0 = phase_diff;        
    end
end

function idx = FreqToSliderIdx(freq_in_hz, handles)
    % convert frequency into index on slider
    [~, idxs] = min(abs(handles.p.hz - freq_in_hz));
    idx = idxs(1);
end

function GUIUpdate(handles)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % update values in graphical user interface (GUI)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % proton data
    handles.edit_proton_file.String = handles.p.proton_file;

    % carbon data, repetition time, resolution, etc.
    handles.edit_carbon_file.String     = handles.p.carbon_file;
    handles.edit_resolution.String      = num2str(handles.p.carbon_resolution(1));
    if (length(handles.p.carbon_resolution) > 1)
        handles.edit_resolution2.String = num2str(handles.p.carbon_resolution(2));
    else
        handles.edit_resolution2.String = handles.edit_resolution.String;
    end
    
    handles.edit_fid_window_high.String = num2str(handles.p.carbon_recon_point_high);
    handles.edit_fid_window_low.String  = num2str(handles.p.carbon_recon_point_low);
    handles.edit_broadening.String      = num2str(handles.p.carbon_line_broadening);
    handles.edti_spec_fill.String       = num2str(handles.p.spec_fillfactor);

    % proton slice
    handles.slider_slice_proton.Min        = 1;
    handles.slider_slice_proton.Max        = 1;
    if isfield(handles, 'd') && isfield(handles.d, 'proton_image')
        handles.slider_slice_proton.Max    = size(handles.d.proton_image,3);
    end
    slider_step_temp = handles.slider_slice_proton.Max - handles.slider_slice_proton.Min;
    handles.slider_slice_proton.SliderStep = [1 1] / max(1, slider_step_temp);
    handles.slider_slice_proton.Value      = handles.p.slice_proton_val;
    handles.edit_slice_proton.String       = num2str(handles.p.slice_proton_val);

    % carbon slice
    handles.slider_slice_carbon.Min        = 1;
    handles.slider_slice_carbon.Max        = 1;
    if isfield(handles, 'd') && isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'image')
        handles.slider_slice_carbon.Max    = size(handles.d.carbon_recon.image,4);
    end
    slider_step_temp = handles.slider_slice_carbon.Max - handles.slider_slice_carbon.Min;
    handles.slider_slice_carbon.SliderStep = [1 1] / max(1, slider_step_temp);
    handles.slider_slice_carbon.Value      = handles.p.slice_carbon_val;
    handles.edit_slice_carbon.String       = num2str(handles.p.slice_carbon_val);

    % carbon coil
    handles.slider_coil_carbon.Min        = 1;
    handles.slider_coil_carbon.Max        = 1;
    if isfield(handles, 'd') && isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'image')
        handles.slider_coil_carbon.Max    = size(handles.d.carbon_recon.image,5);
    end
    slider_step_temp = handles.slider_coil_carbon.Max - handles.slider_coil_carbon.Min;
    handles.slider_coil_carbon.SliderStep = [1 1] / max(1, slider_step_temp);
    handles.slider_coil_carbon.Value      = handles.p.coil_carbon_val;
    if (handles.p.option_carbon_rms)
        handles.edit_coil_carbon.String   = 'RMS';
    else
        handles.edit_coil_carbon.String   = num2str(handles.p.coil_carbon_val);
    end
    handles.checkbox_carbon_rms.Value     = handles.p.option_carbon_rms;


    % timestep
    if isfield(handles, 'd') && isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'image')
        num_data_frames = max(1, size(handles.d.carbon_recon.image, 6));
    else
        num_data_frames = 1;
    end

    handles.slider_timestep.Min        = 1;
    handles.slider_timestep.Max        = num_data_frames;
    slider_step_temp = max(1, num_data_frames - 1);
    handles.slider_timestep.SliderStep = [1 1] / slider_step_temp;
    handles.slider_timestep.Value      = handles.p.timestep_val;
    handles.edit_timestep_low.String   = num2str(handles.p.timestep_val);
    handles.edit_timestep_high.String  = num2str(handles.p.timestep_val + handles.p.timestep_length - 1);

    % automatic maximum signal option
    handles.checkbox_signalmax_auto.Value = handles.p.window_auto;
    handles.checkbox_phmax_auto.Value = handles.p.pH_window_auto;

    % signal window
    if isfield(handles, 'd') && isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'image')
        window_max = 2*max(max(max(max(max(max(abs(handles.d.carbon_recon.image)))))));
    else
        window_max = 1000;
    end
    
    %pH map window
    if max(max(max(handles.p.pHmap74)),max(max(handles.p.pHmapMean))) > 0
        pH_window_max = max(1.3*max(max(handles.p.pHmapMean)),1.3*max(max(handles.p.pHmap74)));
    else
        pH_window_max = 7.5;
    end    
        
    if handles.p.window_val > window_max
        handles.p.window_val = window_max;
    end
    if handles.p.window_length > window_max
        handles.p.window_length = window_max;
    end
    if handles.p.window_length < 0
        handles.p.window_length = 1;
    end
    %same of pH...
    if handles.p.pH_window_val > pH_window_max
        handles.p.pH_window_val = pH_window_max;
    end
    if handles.p.pH_window_length > pH_window_max
        handles.p.pH_window_length = pH_window_max;
    end
    if handles.p.pH_window_length < 0
        handles.p.pH_window_length = 0.1;
    end
    
    
    
    handles.slider_window.Max           = window_max;
    handles.slider_window.Min           = 1;
    handles.slider_window.SliderStep    = [0.0001 0.005];
    handles.slider_window.Value         = handles.p.window_length;
    handles.edit_window_low.String      = num2str(handles.p.window_val);
    handles.edit_window_high.String     = num2str(handles.p.window_val + handles.p.window_length);
    
    handles.slider_phwindow.Max           = pH_window_max;
    handles.slider_phwindow.Min           = 0.1;
    handles.slider_phwindow.SliderStep    = [0.02 0.1];
    handles.slider_phwindow.Value         = handles.p.pH_window_length;
    handles.edit_phwindow_low.String      = num2str(handles.p.pH_window_val);
    handles.edit_phwindow_high.String     = num2str(handles.p.pH_window_val + handles.p.pH_window_length);

    % frequency values
    handles.slider_freq.Value    = FreqToSliderIdx(handles.p.freq_val + handles.p.freq_length / 2, handles);
    handles.edit_freq_low.String = num2str(round(handles.p.freq_val));
    handles.edit_freq_high.String= num2str(round(handles.p.freq_val + handles.p.freq_length));

    handles.slider_f1.Value      = FreqToSliderIdx(handles.p.f1_val, handles);
    handles.slider_f2.Value      = FreqToSliderIdx(handles.p.f2_val, handles);
    handles.slider_f3.Value      = FreqToSliderIdx(handles.p.f3_val, handles);
    handles.slider_f4.Value      = FreqToSliderIdx(handles.p.f4_val, handles);
    handles.edit_f1.String       = num2str(round(handles.p.f1_val));
    handles.edit_f2.String       = num2str(round(handles.p.f2_val));
    handles.edit_f3.String       = num2str(round(handles.p.f3_val));
    handles.edit_f4.String       = num2str(round(handles.p.f4_val));

    handles.edit_f1_ppm.String   = num2str(round(1000*(handles.p.f1_val / handles.p.reference_freq + handles.p.working_freq_ppm))/1000);
    handles.edit_f2_ppm.String   = num2str(round(1000*(handles.p.f2_val / handles.p.reference_freq + handles.p.working_freq_ppm))/1000);
    handles.edit_f3_ppm.String   = num2str(round(1000*(handles.p.f3_val / handles.p.reference_freq + handles.p.working_freq_ppm))/1000);
    handles.edit_f4_ppm.String   = num2str(round(1000*(handles.p.f4_val / handles.p.reference_freq + handles.p.working_freq_ppm))/1000);


    % frequency ranges (indices for what can be displayed in image, not what to
    % display in spectrum)
    if isfield(handles,'d') && isfield(handles.d,'carbon_recon')
        freq_min = 1;
        freq_max = size(handles.d.carbon_recon.image,3);
    else
        freq_min = 1;
        freq_max = 1024;
    end

    handles.slider_freq.Min        = freq_min;
    handles.slider_freq.Max        = freq_max;
    handles.slider_freq.SliderStep = [1 10]/(freq_max - freq_min);
    handles.slider_f1.Min          = freq_min;
    handles.slider_f1.Max          = freq_max;
    handles.slider_f1.SliderStep   = [1 10]/(freq_max - freq_min); 
    handles.slider_f2.Min          = freq_min;
    handles.slider_f2.Max          = freq_max;
    handles.slider_f2.SliderStep   = [1 10]/(freq_max - freq_min);
    handles.slider_f3.Min          = freq_min;
    handles.slider_f3.Max          = freq_max;
    handles.slider_f3.SliderStep   = [1 10]/(freq_max - freq_min);
    handles.slider_f4.Min          = freq_min;
    handles.slider_f4.Max          = freq_max;
    handles.slider_f4.SliderStep   = [1 10]/(freq_max - freq_min);


    % reconstruction / display options
    handles.edit_plot_freq_min.String = num2str(handles.p.freq_min);
    handles.edit_plot_freq_max.String = num2str(handles.p.freq_max);
    handles.edit_carbon_shift_x.String = num2str(handles.p.carbon_shift_x);
    handles.edit_carbon_shift_y.String = num2str(handles.p.carbon_shift_y);
    handles.edit_intensity_shift.String = num2str(handles.p.intensity_offset);
    handles.edit_phase0.String = num2str(round(handles.p.spectrum_phase0*10)/10);
    handles.edit_phase1.String = num2str(handles.p.spectrum_phase1);
    handles.checkbox_fix_click_phase.Value = handles.p.fix_click_phase;
    if (handles.p.fix_click_phase)
        handles.edit_phase0.Enable = 'off';
    else
        handles.edit_phase0.Enable = 'on';
    end

    % results
    handles.checkbox_flipanglecorrection.Value = handles.p.flipangle_correction_desired;
    handles.edit_t1_metabolite.String          = num2str(handles.p.t1_metabolite);

    % update apparent conversion rates for single voxel
    handles.edit_lac_pyr.String = '';%num2str(sprintf('%.4f',handles.p.k_pyr_lac));
    handles.edit_ala_pyr.String = '';%num2str(sprintf('%.4f',handles.p.k_pyr_ala));

    % update display options for extra figures
    handles.checkbox_carbon_load_figures_extra.Value  = handles.p.carbon_load_figures_extra;
    handles.checkbox_carbon_recon_figures_extra.Value = handles.p.carbon_recon_figures_extra;

    % update reconstruction options
    handles.edit_carbon_shift_x.String = num2str(handles.p.carbon_shift_x);
    handles.edit_carbon_shift_y.String = num2str(handles.p.carbon_shift_y); 

    % update spectrum and time display options
    handles.radiobutton_specandtime_roi.Value         = (handles.p.specandtime_roi == 1);
    handles.radiobutton_specandtime_singlevoxel.Value = (handles.p.specandtime_roi == 0);
    handles.radiobutton_no_cursor.Value =               (handles.p.specandtime_roi == 2);

    % update scaling factor
    handles.scalingfactor_f1.String = num2str(handles.p.downscale_f1);

    % update apparent conversion rates for ROI
    handles.edit_roi_kpyrlac.String = '';%num2str(sprintf('%.4f', handles.p.roi_k_pyr_lac_mean));
    handles.edit_roi_kpyrala.String = '';%num2str(sprintf('%.4f', handles.p.roi_k_pyr_ala_mean));

    handles.show_exchange_radio.Value = 0;%handles.p.show_exchange_rate;
    handles.show_peak_radio.Value     = 1;%not(handles.p.show_exchange_rate);


    % update number of voxels in the ROI
    num_roi_voxels = sum(handles.p.roi_mask(:));
    if (num_roi_voxels > 0)
        handles.uipanel_roi.Title = sprintf('ROI (n=%d)', num_roi_voxels);
    else
        handles.uipanel_roi.Title = 'ROI';
    end

    % update pixel number in the results
    if (handles.p.specandtime_roi == 1) && isprop(handles.p,'roi_xi') && isprop(handles.p,'roi_yi')
        handles.uipanel_results.Title = 'Results in ROI';
    elseif isprop(handles.p, 'pointer2d')
        handles.uipanel_results.Title = sprintf('Results (x=%d, y=%d)',handles.p.pointer2d(1), handles.p.pointer2d(2));
    else
        handles.uipanel_results.Title = 'Results';
    end

    % update timestep and frequency sum options
    handles.checkbox_freq_sum.Value = handles.p.option_freq_sum;
    handles.checkbox_timestep_sum.Value = handles.p.option_timestep_sum;

    % update what to plot options
    handles.radiobutton_plot_intensity.Value = handles.p.option_plot_intensity;
    handles.radiobutton_plot_complex.Value = handles.p.option_plot_complex;
    handles.radiobutton_plot_real.Value = handles.p.option_plot_real;
    handles.radiobutton_plot_phase.Value = handles.p.option_plot_phase;
    handles.radiobutton_plot_lac_pyr.Value = handles.p.option_plot_lac_pyr;
    handles.radiobutton_plot_ala_pyr.Value = handles.p.option_plot_ala_pyr;
    handles.radiobutton_diff_norm.Value = handles.p.option_plot_diff_norm;
    handles.radiobutton_plot_lac_allfreq.Value = handles.p.option_plot_lac_allfreqs;
    
    handles.radiobutton_mean_pHmap.Value = handles.p.option_plot_pH_map_mean;
    handles.radiobutton_pH_compartment.Value = handles.p.option_plot_pH_map_compartment;
    handles.radiobutton_main_pHmap.Value = handles.p.option_plot_pH_map_main;

    if handles.p.option_plot_pH_map_mean == 1
        handles.radiobutton_mean_pHmap.Value = 1;
    elseif handles.p.option_plot_pH_map_main == 1
        handles.radiobutton_main_pHmap.Value = 1;
    elseif handles.p.option_plot_pH_map_compartment
        handles.radiobutton_pH_compartment.Value = 1;
    end
    handles.checkbox_pHmap65.Value = handles.p.option_show_pHmap65;
    handles.checkbox_pHmap70.Value = handles.p.option_show_pHmap70;
    handles.checkbox_pHmap74.Value = handles.p.option_show_pHmap74;
    handles.checkbox_invert_colormap.Value = handles.p.invert_colormap;
    handles.checkbox_cut_pH_map.Value = handles.p.cut_pH_map;
    handles.checkbox_fig_PPT.Value = handles.p.fig_ppt;
    handles.checkbox_pHweighted.Value = handles.p.pHmeanWeighted;
    handles.checkbox_pHweighted_signal.Value = handles.p.pHmeanWeighted_signal;
    
    handles.edit_Fit_threshold.String = num2str(handles.p.pH_fit_threshold);
    handles.edit_Fit_prominence.String = num2str(handles.p.pH_fit_prominence);
    handles.edit_proton_cut_threshold.String = num2str(handles.p.proton_cut_threshold);
    
    handles.edit_alpha74.String = num2str(handles.p.option_overlay_alpha_74);
    handles.edit_alpha70.String = num2str(handles.p.option_overlay_alpha_70);
    handles.edit_alpha65.String = num2str(handles.p.option_overlay_alpha_65);
    handles.slider_alpha74.Value = handles.p.option_overlay_alpha_74;
    handles.slider_alpha70.Value = handles.p.option_overlay_alpha_70;
    handles.slider_alpha65.Value = handles.p.option_overlay_alpha_65;
    handles.edit_proton_overlay_alpha.String = num2str(handles.p.option_overlay_alpha);
    handles.edit_spec_fill.String = num2str(handles.p.spec_fillfactor);
    handles.edit_ROI_Px_13C.String = num2str(handles.edit_ROI_Px_13C.Value);
    handles.edit_ROI_Px_1H.String = num2str(handles.edit_ROI_Px_1H.Value);
    handles.edit_Area.String = num2str(handles.edit_Area.Value);
    handles.edit_Vox_Sz.String = num2str(handles.p.Vox_Sz);
    handles.edit_Vox_Sz.Value = handles.p.Vox_Sz;

    handles.radiobutton_plot_freq1_offset.Value = handles.p.option_plot_freq1_offset;
    handles.radiobutton_plot_freq4_offset.Value = handles.p.option_plot_freq4_offset;

    handles.radiobutton_default_colourmap.Value = 0;
    handles.radiobutton_hot_colourmap.Value = 0;
    handles.radiobutton_jet_colourmap.Value = 0;
    handles.radiobutton_gray_colourmap.Value = 0;
    if (strcmp(handles.p.option_colourmap, 'default'))
        handles.radiobutton_default_colourmap.Value = 1;
    elseif (strcmp(handles.p.option_colourmap, 'hot'))
        handles.radiobutton_hot_colourmap.Value = 1;
    elseif (strcmp(handles.p.option_colourmap, 'jet'))
        handles.radiobutton_jet_colourmap.Value = 1;
    elseif (strcmp(handles.p.option_colourmap, 'gray'))
        handles.radiobutton_gray_colourmap.Value = 1;
    end
end

function PlotProton(handles)
    subplot = @(m,n,p) subtightplot(m, n, p, [0.10 0.08], [0.10 0.03], [0.08 0.05]);
    subplot(2,2,1);

    if ~isfield(handles,'d') || ~isfield(handles.d,'proton_image')
%         disp('No proton image to plot');
        return;
    end

    plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
    plotted_proton_image = circshift(plotted_proton_image, round([handles.p.yshift handles.p.xshift]));
    
    % draw and label the proton image
    imagesc(plotted_proton_image)

    set(gca,'YDir','normal')

    % label the axes
    xlabel('x [mm]')
    ylabel('y [mm]')
    colormap(gca,'gray')
    cbarp = colorbar;
%     if (handles.p.fig_ppt)
%         ylabel(cbarp,'Intensity','FontSize',12,'FontWeight','Bold');
%     end   
    axis image


    fov = handles.p.proton_fov;
    ticklabelsx = -(fov(1)/2):(fov(1)/4):(fov(1)/2);
    ticklabelsy = -(fov(2)/2):(fov(2)/4):(fov(2)/2);

    ticksx = linspace(1, size(plotted_proton_image, 2), numel(ticklabelsx));
    set(gca, 'XTick', ticksx, 'XTickLabel', round(ticklabelsx,2))

    ticksy = linspace(1, size(plotted_proton_image, 1), numel(ticklabelsy));
    set(gca, 'YTick', ticksy, 'YTickLabel', round(ticklabelsy,2))



    % annotate the proton image if carbon data is loaded as well
    if isfield(handles.d,'carbon_recon') && isfield(handles.d.carbon_recon, 'image')

        proton_carbon_scaling_x = size(handles.d.proton_image,1)/size(handles.d.carbon_recon.image,1);
        proton_carbon_scaling_y = size(handles.d.proton_image,2)/size(handles.d.carbon_recon.image,2);


        % check whether a ROI is defined
        if (handles.p.specandtime_roi == 1) && isprop(handles.p,'roi_xi') && isprop(handles.p,'roi_yi')
            % draw the line enclosing the region of interest
           line(handles.p.roi_xi, handles.p.roi_yi, 'Color', 'w');
%             line(handles.p.roi_xi(24:26),handles.p.roi_yi(24:26), 'Color', 'w');   % these lines might be helpful if you want to draw only parts of the roi
%             line(handles.p.roi_xi(1:10),handles.p.roi_yi(1:10), 'Color', 'w');
%             line(handles.p.roi_xi(11:23),handles.p.roi_yi(11:23), 'Color', 'w');
%             loaded_rois_2 = load(['C:\Users\Martin Grashei\Desktop\Promotion MRI\Experimental Data\2019.07.25 - Schilling - A2.7 - EL4 ZA CSI + Gel\' 'Tumor Small ROI.mat']); %delete after single usage again!!!!
%             line(loaded_rois_2.xi, loaded_rois_2.yi, 'Color', 'y'); %delete after single usage again!!!!
        elseif (handles.p.specandtime_roi == 0) && isprop(handles.p,'pointer2d')
            % draw the horizontal and vertical lines that mark the pixel of interest
            line([(handles.p.pointer2d(1)-0.5)*proton_carbon_scaling_x+0.5 (handles.p.pointer2d(1)-0.5)*proton_carbon_scaling_x+0.5], ...
                 [0.5 size(handles.d.proton_image,2)+0.5], 'Color', 'w');
            line([0.5 size(handles.d.proton_image,1)+0.5], ...
                 [(handles.p.pointer2d(2)-0.5)*proton_carbon_scaling_y+0.5 (handles.p.pointer2d(2)-0.5)*proton_carbon_scaling_y+0.5], 'Color', 'w');
        end


        % define which function to call when the carbon image is clicked on
        subplot_proton_bdf = @(m,n) subplot_proton_ButtonDownFcn(m, n, handles);
        set(allchild(gca), 'ButtonDownFcn', subplot_proton_bdf);
    end
end

function PlotCarbon(handles)
    subplot = @(m,n,p) subtightplot(m, n, p, [0.10 0.08], [0.10 0.03], [0.08 0.05]);
    carbon_plot_axes = subplot(2,2,2); %#ok<NASGU>

    method = 'bilinear';
    method2 = 'box';
    factor = 4;
    % get metabolic image (intensity, ratio, phase, etc.)
    metab_image = GetMetabImage(handles);
    if handles.p.option_plot_pH_map_compartment == 1 
        plotted_carbon_image = permute(metab_image, [2 1 3]);
        plotted_carbon_image(plotted_carbon_image == 0) = NaN;
        plotted_carbon_image = imresize(plotted_carbon_image,factor,method); %line for interpolation plot (remove if not for ismrm abstract
        plotted_carbon_image(isnan(plotted_carbon_image)) = 0;
        %plot first pH_map
        if handles.p.option_show_pHmap65 == 1 && handles.p.option_plot_pH_map == 1
            carbon_image_1  = imagesc(plotted_carbon_image(:,:,3));
            axis image
            alpha_data_65 = ones(size(plotted_carbon_image(:,:,3))) * handles.p.option_overlay_alpha_65;
            % total carbon image threshold
            if (handles.p.option_total_signal_threshold ~= -Inf)
                total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                alpha_data_65(total_carbon_image(:,:,3) <= handles.p.option_total_signal_threshold) = 0;
            end
            % displayed image threshold
            if (handles.p.option_alpha_threshold ~= -Inf)
                alpha_data_65(plotted_carbon_image(:,:,3) <= handles.p.option_alpha_threshold) = 0;
            end
            %cut pH-Map to proton-Image area
            if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                % get anatomical / proton image
%                 plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
%                 pHmask = plotted_proton_image / max(max(plotted_proton_image));
%                 pHmask = imresize(pHmask,size(plotted_carbon_image(:,:,3),1)/size(pHmask,1),'bilinear');
%                 pHmask(pHmask < handles.p.proton_cut_threshold) = 0;
%                 pHmask(pHmask > handles.p.proton_cut_threshold) = 1;
                roi_mask_cut_interp = imresize(handles.p.roi_mask_cut(:,:,1),factor,method2);
                alpha_data_65(roi_mask_cut_interp == 0) = 0; 
                %alpha_data_65(handles.p.roi_mask_cut == 0) = 0; 
            end  
            set(carbon_image_1, 'AlphaData', alpha_data_65);
            set(gca,'YDir','normal')  
            hold on    
        end
        %plot second pH_map
        if handles.p.option_show_pHmap70 == 1 && handles.p.option_plot_pH_map == 1
            carbon_image_2  = imagesc(plotted_carbon_image(:,:,2));
            axis image
            alpha_data_70 = ones(size(plotted_carbon_image(:,:,2))) * handles.p.option_overlay_alpha_70;
            % total carbon image threshold
            if (handles.p.option_total_signal_threshold ~= -Inf)
                total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                alpha_data_70(total_carbon_image(:,:,2) <= handles.p.option_total_signal_threshold) = 0;
            end
            % displayed image threshold
            if (handles.p.option_alpha_threshold ~= -Inf)
                alpha_data_70(plotted_carbon_image(:,:,2) <= handles.p.option_alpha_threshold) = 0;
            end
            %cut pH-Map to proton-Image area
            if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                % get anatomical / proton image
%                 plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
%                 pHmask = plotted_proton_image / max(max(plotted_proton_image));
%                 pHmask = imresize(pHmask,size(plotted_carbon_image(:,:,2),1)/size(pHmask,1),'bilinear');
%                 pHmask(pHmask < handles.p.proton_cut_threshold) = 0;
%                 pHmask(pHmask > handles.p.proton_cut_threshold) = 1;
                roi_mask_cut_interp = imresize(handles.p.roi_mask_cut,factor,method2);
                alpha_data_70(roi_mask_cut_interp == 0) = 0; 
                %alpha_data_70(handles.p.roi_mask_cut == 0) = 0; 
            end  
            set(carbon_image_2, 'AlphaData', alpha_data_70);
            set(gca,'YDir','normal')
            hold on
        end
                %plot second pH_map
        if handles.p.option_show_pHmap74 == 1 && handles.p.option_plot_pH_map == 1
            carbon_image_3  = imagesc(plotted_carbon_image(:,:,1));
            axis image
            alpha_data_74 = ones(size(plotted_carbon_image(:,:,1))) * handles.p.option_overlay_alpha_74;
            % total carbon image threshold
            if (handles.p.option_total_signal_threshold ~= -Inf)
                total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                alpha_data_74(total_carbon_image(:,:,1) <= handles.p.option_total_signal_threshold) = 0;
            end
            % displayed image threshold
            if (handles.p.option_alpha_threshold ~= -Inf)
                alpha_data_74(plotted_carbon_image(:,:,1) <= handles.p.option_alpha_threshold) = 0;
            end
                 %cut pH-Map to proton-Image area
            if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                % get anatomical / proton image
%                 plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
%                 pHmask = plotted_proton_image / max(max(plotted_proton_image));
%                 pHmask = imresize(pHmask,size(plotted_carbon_image(:,:,1),1)/size(pHmask,1),'bilinear');
%                 pHmask(pHmask < handles.p.proton_cut_threshold) = 0;
%                 pHmask(pHmask > handles.p.proton_cut_threshold) = 1;
                roi_mask_cut_interp = imresize(handles.p.roi_mask_cut(:,:,1),factor,method2);
                alpha_data_74(roi_mask_cut_interp == 0) = 0; 
                %alpha_data_74(handles.p.roi_mask_cut == 0) = 0; 
            end  
            set(carbon_image_3, 'AlphaData', alpha_data_74);
            set(gca,'YDir','normal')
            hold on
        end
        if handles.p.option_show_pHmap74 == 0 && handles.p.option_show_pHmap70 == 0 && handles.p.option_show_pHmap65 == 0
            plotted_carbon_image = permute(metab_image, [2 1 3]);
            plotted_carbon_image = imresize(plotted_carbon_image,factor,method);

            % plot basic metabolic image
            carbon_image = imagesc(plotted_carbon_image);
            axis image



            % transparency or threshold for drawing carbon image
            alpha_data = ones(size(plotted_carbon_image)) * handles.p.option_overlay_alpha;
            % total carbon image threshold
            if (handles.p.option_total_signal_threshold ~= -Inf)
                total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
                alpha_data(total_carbon_image <= handles.p.option_total_signal_threshold) = 0;
            end
            % displayed image threshold
            if (handles.p.option_alpha_threshold ~= -Inf)
                alpha_data(plotted_carbon_image <= handles.p.option_alpha_threshold) = 0;
            end
            %cut pH-Map to proton-Image area
            if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1
                % get anatomical / proton image
%                 plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
%                 pHmask = plotted_proton_image / max(max(plotted_proton_image));
%                 pHmask = imresize(pHmask,size(plotted_carbon_image,1)/size(pHmask,1),'bilinear');
%                 pHmask(pHmask < handles.p.proton_cut_threshold) = 0;
%                 pHmask(pHmask > handles.p.proton_cut_threshold) = 1;
                roi_mask_cut_interp = imresize(handles.p.roi_mask_cut(:,:,1),factor,method2);
                alpha_data(roi_mask_cut_interp == 0) = 0; 
                %alpha_data(handles.p.roi_mask_cut == 0) = 0; 
            end  
            set(carbon_image, 'AlphaData', alpha_data(:,:,1));
        end
        
        
    else    
        plotted_carbon_image = permute(metab_image, [2 1]);
        plotted_carbon_image = imresize(plotted_carbon_image,factor,method); %line for interpolation plot (remove if not for ismrm abstract
        
        % plot basic metabolic image
        carbon_image = imagesc(plotted_carbon_image);
        axis image


    
        % transparency or threshold for drawing carbon image
        alpha_data = ones(size(plotted_carbon_image)) * handles.p.option_overlay_alpha;
        % total carbon image threshold
        if (handles.p.option_total_signal_threshold ~= -Inf)
            total_carbon_image = permute(GetTotalCarbonImage(handles), [2 1]);
            alpha_data(total_carbon_image <= handles.p.option_total_signal_threshold) = 0;
        end
        % displayed image threshold
        if (handles.p.option_alpha_threshold ~= -Inf)
            alpha_data(plotted_carbon_image <= handles.p.option_alpha_threshold) = 0;
        end
        %cut pH-Map to proton-Image area
        if (isfield(handles.d, 'proton_image')) && handles.p.cut_pH_map == 1 && ~(handles.p.fit_current_spectrum)
            % get anatomical / proton image
%             plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
%             pHmask = plotted_proton_image / max(max(plotted_proton_image));
%             pHmask = imresize(pHmask,size(plotted_carbon_image,1)/size(pHmask,1),'bilinear');
%             pHmask(pHmask < handles.p.proton_cut_threshold) = 0;
%             pHmask(pHmask > handles.p.proton_cut_threshold) = 1;
            roi_mask_cut_interp = imresize(handles.p.roi_mask_cut(:,:,1),factor,method);
            alpha_data(roi_mask_cut_interp == 0) = 0; 
            %alpha_data(handles.p.roi_mask_cut == 0) = 0; 
        end  
        set(carbon_image, 'AlphaData', alpha_data);
    end
    
    
    if (isfield(handles.d, 'proton_image'))
        hold on

        % get anatomical / proton image
        plotted_proton_image = permute(handles.d.proton_image(:,:,handles.p.slice_proton_val),[2 1]);
        plotted_proton_image = circshift(plotted_proton_image, round([handles.p.yshift handles.p.xshift]));
        plotted_proton_image = plotted_proton_image / max(max(plotted_proton_image));

        % plot over top of carbon image
        ppi_sz = size(plotted_proton_image);    
        plotted_proton_image_rgb = zeros(ppi_sz(1), ppi_sz(2), 3);
        for n = 1:3
            plotted_proton_image_rgb(:,:,n) = plotted_proton_image;
        end
        %metab_sz = size(metab_image);
        metab_sz = size(imresize(metab_image,factor,method));
        image(plotted_proton_image_rgb, 'XData', [0 metab_sz(1)] + 0.5, 'YData', [0 metab_sz(2)] + 0.5);

        hold off
        
    end

    % reorder so carbon / functional image is over top of anatomical (for transparency see-through purposes)
    if handles.p.option_plot_pH_map == 1 && handles.p.option_plot_pH_map_compartment == 1 
        if handles.p.option_show_pHmap74 == 1
            uistack(carbon_image_3, 'top')
        end
        if handles.p.option_show_pHmap70 == 1
            uistack(carbon_image_2, 'top')
        end
        if handles.p.option_show_pHmap65 == 1
            uistack(carbon_image_1, 'top')
        end  
    else
        uistack(carbon_image, 'top')
    end

    % scaling window for carbon data
    if (~handles.p.window_auto) && ~(handles.p.option_plot_pH_map)
        % use user-specified range
        caxis([handles.p.window_val handles.p.window_val + handles.p.window_length])
        
    elseif (handles.p.option_plot_pH_map)
        if (~handles.p.pH_window_auto)
            % use user-specified range
            caxis([handles.p.pH_window_val handles.p.pH_window_val + handles.p.pH_window_length])
            
        elseif handles.p.option_plot_pH_map_compartment == 1 
            plotted_carbon_image_temp3 = NaN(size(plotted_carbon_image));
            if handles.p.option_show_pHmap74 == 1
                plotted_carbon_image_temp = plotted_carbon_image(:,:,1);
                plotted_carbon_image_temp(alpha_data_74 <= 0) = NaN;
                plotted_carbon_image_temp3(:,:,1) = plotted_carbon_image_temp;
            end
            if handles.p.option_show_pHmap70 == 1
                plotted_carbon_image_temp = plotted_carbon_image(:,:,2);
                plotted_carbon_image_temp(alpha_data_70 <= 0) = NaN;
                plotted_carbon_image_temp3(:,:,2) = plotted_carbon_image_temp;
            end
            if handles.p.option_show_pHmap65 == 1
                plotted_carbon_image_temp = plotted_carbon_image(:,:,3);
                plotted_carbon_image_temp(alpha_data_65 <= 0) = NaN;
                plotted_carbon_image_temp3(:,:,3) = plotted_carbon_image_temp;
            end
            plotted_max = (max(max(max(plotted_carbon_image_temp3))));
            if (isnan(plotted_max))
                % fall back to ignoring alpha
                plotted_max = max(max(max(plotted_carbon_image)));
            end
            plotted_min = (min(min(min(plotted_carbon_image_temp3))));
            if (isnan(plotted_min))
                % fall back to ignoring alpha
                plotted_min = min(min(min(plotted_carbon_image)));
            end  
        
            if (plotted_min < plotted_max)
                % avoid adjusting if min/max are the same as this causes a crash
                caxis([plotted_min plotted_max])
            end
        elseif handles.p.option_plot_pH_map_mean == 1 || handles.p.option_plot_pH_map_main == 1
            % determine range from min/max of what is plotted (accounting for transparency)

            % set transparent pixels to NaN so they will be ignored in min/max considerations
            plotted_carbon_image_temp = plotted_carbon_image;
            plotted_carbon_image_temp(alpha_data <= 0) = NaN;
            plotted_max = max(max(plotted_carbon_image_temp));
            if (isnan(plotted_max))
                % fall back to ignoring alpha
                plotted_max = max(max(plotted_carbon_image));
            end
            plotted_min = min(min(plotted_carbon_image_temp));
            if (isnan(plotted_min))
                % fall back to ignoring alpha
                plotted_min = min(min(plotted_carbon_image));
            end    

            if (plotted_min < plotted_max)
                % avoid adjusting if min/max are the same as this causes a crash
                caxis([plotted_min plotted_max])
            end
        else
            disp('there is something wrong with the plotting options of the pH maps...')
        end
            
    else
        % determine range from min/max of what is plotted (accounting for transparency)

        % set transparent pixels to NaN so they will be ignored in min/max considerations
        plotted_carbon_image_temp = plotted_carbon_image(:,:,1);
        plotted_carbon_image_temp(alpha_data <= 0) = NaN;
        plotted_max = max(max(plotted_carbon_image_temp));
        if (isnan(plotted_max))
            % fall back to ignoring alpha
            plotted_max = max(max(plotted_carbon_image));
        end
        plotted_min = min(min(plotted_carbon_image_temp));
        if (isnan(plotted_min))
            % fall back to ignoring alpha
            plotted_min = min(min(plotted_carbon_image));
        end    

        if (plotted_min < plotted_max)
            % avoid adjusting if min/max are the same as this causes a crash
            caxis([plotted_min plotted_max])
        end
    end
    
    set(gca,'YDir','normal')
    if (handles.p.option_plot_phase)
        caxis([-pi pi])
    end

    % axis labels, colourbar, colourmap for carbon
    xlabel('x [mm]')
    ylabel('y [mm]')
    if strcmp(handles.p.option_colourmap,'default')
        colormap(gca, handles.p.option_colourmap)
    else
        cmp = colormap(gca, handles.p.option_colourmap);
    end
    cbar = colorbar;
    if (handles.p.invert_colormap) && ~(strcmp(handles.p.option_colourmap,'default'))
        colormap(gca,flipud(cmp))
    end
    if (handles.p.option_plot_pH_map)
        ylabel(cbar,'pH');
        if (handles.p.fig_ppt)
            ylabel(cbar,'pH','FontSize',12,'FontWeight','Bold');
            %set(cbar,'YTick',(6.9:0.1:7.8))
%             t=get(cbar,'Limits');
%             dc = round(((t(2)-t(1))/0.05) + 1);
%             T=linspace(t(1),t(2),dc);
%             set(cbar,'Ticks',T);
%             TL=arrayfun(@(x) sprintf('%.2f',x),T,'un',0);
%             set(cbar,'TickLabels',TL);
        end
    end

    if isfield(handles.d,'carbon_recon')
        fov = handles.p.carbon_fov;
        
        if (isfield(handles.p.carbon_header, 'sliceOrient') && max(strcmp(handles.p.carbon_header.sliceOrient, 'coronal')))
            ticklabelsy = -(fov(1)/2):(fov(1)/4):(fov(1)/2);
            ticklabelsx = -(fov(2)/2):(fov(2)/4):(fov(2)/2);
        else
            ticklabelsx = -(fov(1)/2):(fov(1)/4):(fov(1)/2);
            ticklabelsy = -(fov(2)/2):(fov(2)/4):(fov(2)/2);
        end
    else
        % fallback dummy values...
        ticklabelsx = -1:1:1;
        ticklabelsy = -1:1:1;
    end
    if (size(metab_image,2) > 1)
        ticksx = linspace(1, size(metab_image, 1)*factor, numel(ticklabelsx));
        set(gca, 'XTick', ticksx, 'XTickLabel', round(ticklabelsx,2))

        ticksy = linspace(1, size(metab_image, 2)*factor, numel(ticklabelsy));
        set(gca, 'YTick', ticksy, 'YTickLabel', round(ticklabelsy,2))
    end


    % check whether a ROI is defined
    if (handles.p.specandtime_roi == 1) && ...
        isfield(handles, 'd') && isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'image')   

        % visualize which voxels are included in the ROI
        for m = 1:size(handles.p.roi_mask,1)
            m_rng = [m-0.5 m+0.5 m+0.5 m-0.5];
            for n = 1:size(handles.p.roi_mask,2)
                n_rng = [n+0.5 n+0.5 n-0.5 n-0.5];
                if (handles.p.roi_mask(m,n) == 1)
                  %  patch(m_rng, n_rng, '', 'EdgeColor', 'w', 'FaceColor', 'none');
                end
            end
        end

        % draw the line enclosing the region of interest
        proton_carbon_scaling_x = size(handles.d.proton_image,1)/size(handles.d.carbon_recon.image,1);
        proton_carbon_scaling_y = size(handles.d.proton_image,2)/size(handles.d.carbon_recon.image,2);
        proton_carbon_scaling_x = proton_carbon_scaling_x / factor;
        proton_carbon_scaling_y = proton_carbon_scaling_y / factor;
        line(((handles.p.roi_xi-0.5) / proton_carbon_scaling_x) + 0.5, ...
             ((handles.p.roi_yi-0.5) / proton_carbon_scaling_y) + 0.5, 'Color', 'w');

%         line(((handles.p.roi_xi(24:26)-0.5) / proton_carbon_scaling_x) + 0.5, ...                   % these lines might be helpful if you want to draw only parts of the roi
%                      ((handles.p.roi_yi(24:26)-0.5) / proton_carbon_scaling_y) + 0.5, 'Color', 'w');
%         line(((handles.p.roi_xi(1:10)-0.5) / proton_carbon_scaling_x) + 0.5, ...
%                      ((handles.p.roi_yi(1:10)-0.5) / proton_carbon_scaling_y) + 0.5, 'Color', 'w');
%         line(((handles.p.roi_xi(11:23)-0.5) / proton_carbon_scaling_x) + 0.5, ...
%              ((handles.p.roi_yi(11:23)-0.5) / proton_carbon_scaling_y) + 0.5, 'Color', 'w');
         
%         loaded_rois_2 = load(['C:\Users\Martin Grashei\Desktop\Promotion MRI\Experimental Data\2019.07.25 - Schilling - A2.7 - EL4 ZA CSI + Gel\' 'Tumor Small ROI.mat']); %delete after single usage again!!!!
%         line(((loaded_rois_2.xi-0.5) / proton_carbon_scaling_x) + 0.5, ...
%              ((loaded_rois_2.yi-0.5) / proton_carbon_scaling_y) + 0.5, 'Color', 'y'); %delete after single usage again!!!!
                 

    elseif (handles.p.specandtime_roi == 0) && isprop(handles.p,'pointer2d')
        % draw a horizontal and vertical line to mark the selected pixel
        line([handles.p.pointer2d(1) handles.p.pointer2d(1)], [0.5 size(metab_image,2)+0.5],'Color','w');
        line([0.5 size(metab_image,1)+0.5], [handles.p.pointer2d(2) handles.p.pointer2d(2)],'Color','w');
    end


    % define which function to call when the carbon image is clicked on

    subplot_carbon_bdf = @(m,n) subplot_carbon_image_ButtonDownFcn(m, n, handles);
    set(allchild(gca), 'ButtonDownFcn', subplot_carbon_bdf);

    figure_buf = @(m,n) figure_ButtonUpFcn(m, n, handles);
    set(gcf, 'WindowButtonUpFcn', figure_buf);

    figure_bmf = @(m,n) handle_windowing_drag(m, n, handles);
    set(gcf, 'WindowButtonMotionFcn', figure_bmf);

end

function DisplayResult(handles)
    handles.edit_output_value.String = num2str(GetResultValue(handles));
    
% inserted section (2020.04.17 - Martin G. - get number of pixels in ROI)
    if isempty(handles.p.roi_mask) || max(max(handles.p.roi_mask)) == 0
    % have no mask
        if isprop(handles.p, 'pointer2d')
            handles.edit_ROI_Px_13C.String = '1';
            handles.edit_ROI_Px_1H.String = '1';
        else
            handles.edit_ROI_Px_13C.String = '0';
            handles.edit_ROI_Px_1H.String = '0';
      
        end        
    else
        % get number of voxels in ROI
        metab_image = GetMetabImage(handles);
        if isfield(handles,'d') && isfield(handles.d,'proton_image')  
            if max(size(metab_image)) ~= max(size(handles.p.roi_mask))
                disp('plot4d_plot: DisplayResult-Funtion: probably no metabolic image to plot?!')
                return
            end
        end
        if handles.p.option_plot_pH_map == 1
            if handles.p.option_plot_pH_map_compartment == 1
                metab_image = max(metab_image,3);
                masked_metab_slice_vals = metab_image(handles.p.roi_mask == 1);
                if isfield(handles,'d') && isfield(handles.d,'proton_image')   
                    proton_image = max(handles.d.proton_image,3);
                    masked_proton_slice_vals = proton_image(handles.p.roi_mask_1H == 1);
                end
            else
                masked_metab_slice_vals = metab_image(handles.p.roi_mask == 1);
                if isfield(handles,'d') && isfield(handles.d,'proton_image')   
                    proton_image = max(handles.d.proton_image,3);
                    masked_proton_slice_vals = proton_image(handles.p.roi_mask_1H == 1);
                end
            end
        else
                masked_metab_slice_vals = metab_image(handles.p.roi_mask == 1);
                if isfield(handles,'d') && isfield(handles.d,'proton_image')   
                    proton_image = max(handles.d.proton_image,3);
                    masked_proton_slice_vals = proton_image(handles.p.roi_mask_1H == 1);
                end
        end
        if ~isempty(masked_metab_slice_vals)                          
            count = length(masked_metab_slice_vals);
            handles.edit_ROI_Px_13C.String = num2str(count);
            handles.edit_ROI_Px_13C.Value = count;
        else
            handles.edit_ROI_Px_13C.String = '0';
            handles.edit_ROI_Px_13C.Value = '0';
        end
        if ~isempty(masked_proton_slice_vals)                          
            count_1H = length(masked_proton_slice_vals);
            handles.edit_ROI_Px_1H.String = num2str(count_1H);
            handles.edit_ROI_Px_1H.Value = count_1H;
            Update_Area(handles);
            
        else
            handles.edit_ROI_Px_1H.String = '0';
            handles.edit_ROI_Px_1H.Value = '0';
            Update_Area(handles);
        end
    end
    %end inserted section
end

function PlotSpectrum(handles)
    subplot = @(m,n,p) subtightplot(m, n, p, [0.10 0.08], [0.10 0.03], [0.08 0.05]);
    sp_spec = subplot(2,2,3);
    %warning('off','MATLAB:hg:uicontrol:SingleLineEditCannotHaveMultiLineText') %%%%%%%%%%%%%%%%%%% 22.10.2019. Turn off warning that somewhere a multiline string is produced in a singleline environment
    axes(sp_spec);

    if ~isfield(handles,'d') || ~isfield(handles.d,'carbon_recon') || ~isfield(handles.d.carbon_recon,'image')
        return
    end

    [spectrum, complex_spectrum] = GetMetabSpectrum(handles);
    if handles.p.option_plot_pH_map == 1 && ~(handles.p.fit_current_spectrum)
            Spectral_fit_pH = MetabDataIndexedByPosition(handles.p.peak_fit_spectrum,handles);
            Spectral_fit_pH = squeeze(Spectral_fit_pH);
    elseif (handles.p.fit_current_spectrum)
            Spectral_fit_pH = handles.p.spec_peak_fit_spectrum;
            Spectral_fit_pH = squeeze(Spectral_fit_pH);
    end
    


    if (handles.p.option_freq_as_ppm)
        if handles.p.option_plot_pH_map == 1 && isfield(handles.d.carbon_recon,'volume') && ~(handles.p.option_plot_intensity) && ~(handles.p.option_plot_real)
            
            freq_axis = handles.d.carbon_recon.ppm_padded;
        else    
            freq_axis = handles.p.ppm;
        end
    else
        if handles.p.option_plot_pH_map == 1 && isfield(handles.d.carbon_recon,'volume') && ~(handles.p.option_plot_intensity) && ~(handles.p.option_plot_real)
            freq_axis = handles.d.carbon_recon.hz_padded;
        else
            freq_axis = handles.p.hz;
        end
    end

    fit_params = []; % possibly replaced in following...
    param_names = [];
    if (handles.p.option_plot_complex && ~handles.p.option_carbon_rms)

        if (handles.p.lorentz_fit_desired)
            % fit lorentzian peaks + background to spectrum being plotted
            [fit_params, param_names] = FitToSpectrum(real(complex_spectrum), handles, true);
            fit_z = multi_lorentzian(fit_params, handles.p.hz);

            % plot real, imag parts, and fit to real
            plot(freq_axis, real(complex_spectrum), '-k', ...
                 freq_axis, imag(complex_spectrum), '-r', ...
                 freq_axis, fit_z,                  '-b');
            legend('real', 'imag', 'real fit', 'Location', 'best')

        else
            plot(freq_axis, real(complex_spectrum), '-k', ...
                 freq_axis, imag(complex_spectrum), '-r');
            legend('real', 'imag', 'Location', 'best')
        end   

    elseif (handles.p.option_plot_real && ~handles.p.option_carbon_rms)

        if (handles.p.lorentz_fit_desired)    
            % fit lorentzian peaks + background to spectrum being plotted
            [fit_params, param_names] = FitToSpectrum(real(complex_spectrum), handles, true);
            fit_z = multi_lorentzian(fit_params, handles.p.hz);

            % plot real, imag parts, and fit to real
            plot(freq_axis, real(complex_spectrum), '-k', ...
                 freq_axis, fit_z,                  '-b');
            legend('real', 'real fit', 'Location', 'best')
        elseif exist('Spectral_fit_pH','var')
            plot(freq_axis, real(complex_spectrum), '-k');
            if handles.p.option_plot_pH_map == 1 && max(size(freq_axis)) == max(size(Spectral_fit_pH))
                hold on
                plot(freq_axis,Spectral_fit_pH,'r')
                if ~(handles.p.fit_current_spectrum)
                    idx1 = min(max(1, handles.p.pointer2d(1)), size(handles.d.carbon_recon.volume,1));
                    idx2 = min(max(1, handles.p.pointer2d(2)), size(handles.d.carbon_recon.volume,2));   
                end
                average_over_roi = (handles.p.specandtime_roi == 1);
                if (average_over_roi) && ~(handles.p.fit_current_spectrum)
                    ROI_peak_pos = MetabDataIndexedByPosition(handles.p.peak_pos,handles);
                    ROI_peak_pos = round(ROI_peak_pos);
                    ROI_peak_pos = squeeze(ROI_peak_pos);
                    if (size(ROI_peak_pos,1) > 3 && ROI_peak_pos( 4) > 0), plot(freq_axis(ROI_peak_pos( 4)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(4))),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA5 pH~6.5
                    if (size(ROI_peak_pos,1) > 4 && ROI_peak_pos( 5) > 0), plot(freq_axis(ROI_peak_pos( 5)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(5))),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA1 pH~6.5
                    if (size(ROI_peak_pos,1) > 5 && ROI_peak_pos( 6) > 0), plot(freq_axis(ROI_peak_pos( 6)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(6))),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA5 pH~7.0
                    if (size(ROI_peak_pos,1) > 6 && ROI_peak_pos( 7) > 0), plot(freq_axis(ROI_peak_pos( 7)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(7))),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA1 pH~7.0
                    if (size(ROI_peak_pos,1) > 7 && ROI_peak_pos( 8) > 0), plot(freq_axis(ROI_peak_pos( 8)), 1.25*spectrum(ROI_peak_pos(8)),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA5 pH~7.4
                    if (size(ROI_peak_pos,1) > 8 && ROI_peak_pos( 9) > 0), plot(freq_axis(ROI_peak_pos( 9)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(9))),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA1 pH~7.4
                    if (size(ROI_peak_pos,1) > 9 && ROI_peak_pos(10) > 0), plot(freq_axis(ROI_peak_pos(10)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(10))),'*m','Markersize',12,'MarkerFaceColor','m'); end % PPH5
                    %disp('Fit and Peak Positions are averaged from single voxel data of ROI! Consider refitting with "Fit Current Spectrum"!')
                elseif (handles.p.fit_current_spectrum)
                    if (size(handles.p.spec_peak_pos,2) > 3 && handles.p.spec_peak_pos( 4) > 0), plot(freq_axis(handles.p.spec_peak_pos( 4)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(4)),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA5 pH~6.5
                    if (size(handles.p.spec_peak_pos,2) > 4 && handles.p.spec_peak_pos( 5) > 0), plot(freq_axis(handles.p.spec_peak_pos( 5)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(5)),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA1 pH~6.5
                    if (size(handles.p.spec_peak_pos,2) > 5 && handles.p.spec_peak_pos( 6) > 0), plot(freq_axis(handles.p.spec_peak_pos( 6)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(6)),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA5 pH~7.0
                    if (size(handles.p.spec_peak_pos,2) > 6 && handles.p.spec_peak_pos( 7) > 0), plot(freq_axis(handles.p.spec_peak_pos( 7)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(7)),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA1 pH~7.0
                    if (size(handles.p.spec_peak_pos,2) > 7 && handles.p.spec_peak_pos( 8) > 0), plot(freq_axis(handles.p.spec_peak_pos( 8)), 1.25*handles.p.spec_peak_val(8),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA5 pH~7.4
                    if (size(handles.p.spec_peak_pos,2) > 8 && handles.p.spec_peak_pos( 9) > 0), plot(freq_axis(handles.p.spec_peak_pos( 9)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(9)),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA1 pH~7.4
                    if (size(handles.p.spec_peak_pos,2) > 9 && handles.p.spec_peak_pos(10) > 0), plot(freq_axis(handles.p.spec_peak_pos(10)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(10)),'*m','Markersize',12,'MarkerFaceColor','m'); end % PPH5
                else
                    if (size(handles.p.peak_pos,3) > 3 && handles.p.peak_pos(idx1,idx2, 4) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 4)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 4)),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA5 pH~6.5
                    if (size(handles.p.peak_pos,3) > 4 && handles.p.peak_pos(idx1,idx2, 5) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 5)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 5)),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA1 pH~6.5
                    if (size(handles.p.peak_pos,3) > 5 && handles.p.peak_pos(idx1,idx2, 6) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 6)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 6)),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA5 pH~7.0
                    if (size(handles.p.peak_pos,3) > 6 && handles.p.peak_pos(idx1,idx2, 7) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 7)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 7)),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA1 pH~7.0
                    if (size(handles.p.peak_pos,3) > 7 && handles.p.peak_pos(idx1,idx2, 8) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 8)), 1.25*handles.p.peak_val(idx1,idx2, 8),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA5 pH~7.4
                    if (size(handles.p.peak_pos,3) > 8 && handles.p.peak_pos(idx1,idx2, 9) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 9)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 9)),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA1 pH~7.4
                    if (size(handles.p.peak_pos,3) > 9 && handles.p.peak_pos(idx1,idx2,10) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2,10)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 10)),'*m','Markersize',12,'MarkerFaceColor','m'); end % PPH5
                end
            end
        else
            plot(freq_axis, real(complex_spectrum), '-k');
        end    

    else
        if (handles.p.lorentz_fit_desired)    
            % fit lorentzian peaks + background to spectrum being plotted
            [fit_params, param_names] = FitToSpectrum(spectrum, handles, true);
            fit_z = multi_lorentzian(fit_params, handles.p.hz);

            % plot real, imag parts, and fit to real
            plot(freq_axis, spectrum, '-k', ...
                 freq_axis, fit_z,    '-b');
            legend('magnitude', 'magnitude fit', 'Location', 'best')

        elseif exist('Spectral_fit_pH','var')
            plot(freq_axis, abs(spectrum), '-k');
            if handles.p.option_plot_pH_map == 1 && max(size(freq_axis)) == max(size(Spectral_fit_pH))
                hold on
                plot(freq_axis,Spectral_fit_pH,'r')
                if ~(handles.p.fit_current_spectrum)
                    idx1 = min(max(1, handles.p.pointer2d(1)), size(handles.d.carbon_recon.volume,1));
                    idx2 = min(max(1, handles.p.pointer2d(2)), size(handles.d.carbon_recon.volume,2));   
                end
                average_over_roi = (handles.p.specandtime_roi == 1);
                if (average_over_roi) && ~(handles.p.fit_current_spectrum)
                    ROI_peak_pos = MetabDataIndexedByPosition(handles.p.peak_pos,handles);
                    ROI_peak_pos = round(ROI_peak_pos);
                    ROI_peak_pos = squeeze(ROI_peak_pos);
                    if (size(ROI_peak_pos,1) > 3 && ROI_peak_pos( 4) > 0), plot(freq_axis(ROI_peak_pos( 4)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(4))),'vb','Markersize',8); end % ZA5 pH~6.5
                    if (size(ROI_peak_pos,1) > 4 && ROI_peak_pos( 5) > 0), plot(freq_axis(ROI_peak_pos( 5)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(5))),'vb','Markersize',8); end % ZA1 pH~6.5
                    if (size(ROI_peak_pos,1) > 5 && ROI_peak_pos( 6) > 0), plot(freq_axis(ROI_peak_pos( 6)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(6))),'dg','Markersize',8); end % ZA5 pH~7.0
                    if (size(ROI_peak_pos,1) > 6 && ROI_peak_pos( 7) > 0), plot(freq_axis(ROI_peak_pos( 7)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(7))),'dg','Markersize',8); end % ZA1 pH~7.0
                    if (size(ROI_peak_pos,1) > 7 && ROI_peak_pos( 8) > 0), plot(freq_axis(ROI_peak_pos( 8)), 1.25*spectrum(ROI_peak_pos(8)),'hr','Markersize',8); end % ZA5 pH~7.4
                    if (size(ROI_peak_pos,1) > 8 && ROI_peak_pos( 9) > 0), plot(freq_axis(ROI_peak_pos( 9)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(9))),'hr','Markersize',8); end % ZA1 pH~7.4
                    if (size(ROI_peak_pos,1) > 9 && ROI_peak_pos(10) > 0), plot(freq_axis(ROI_peak_pos(10)), 1.25*max(spectrum(ROI_peak_pos(8)),spectrum(ROI_peak_pos(10))),'*m','Markersize',8); end % PPH5
                    %disp('Fit and Peak Positions are averaged from single voxel data of ROI! Consider refitting with "Fit Current Spectrum"!')
                elseif (handles.p.fit_current_spectrum)
                    if (size(handles.p.spec_peak_pos,2) > 3 && handles.p.spec_peak_pos( 4) > 0), plot(freq_axis(handles.p.spec_peak_pos( 4)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(4)),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA5 pH~6.5
                    if (size(handles.p.spec_peak_pos,2) > 4 && handles.p.spec_peak_pos( 5) > 0), plot(freq_axis(handles.p.spec_peak_pos( 5)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(5)),'vb','Markersize',12,'MarkerFaceColor','b'); end % ZA1 pH~6.5
                    if (size(handles.p.spec_peak_pos,2) > 5 && handles.p.spec_peak_pos( 6) > 0), plot(freq_axis(handles.p.spec_peak_pos( 6)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(6)),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA5 pH~7.0
                    if (size(handles.p.spec_peak_pos,2) > 6 && handles.p.spec_peak_pos( 7) > 0), plot(freq_axis(handles.p.spec_peak_pos( 7)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(7)),'dg','Markersize',12,'MarkerFaceColor','g'); end % ZA1 pH~7.0
                    if (size(handles.p.spec_peak_pos,2) > 7 && handles.p.spec_peak_pos( 8) > 0), plot(freq_axis(handles.p.spec_peak_pos( 8)), 1.25*handles.p.spec_peak_val(8),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA5 pH~7.4
                    if (size(handles.p.spec_peak_pos,2) > 8 && handles.p.spec_peak_pos( 9) > 0), plot(freq_axis(handles.p.spec_peak_pos( 9)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(9)),'hr','Markersize',12,'MarkerFaceColor','r'); end % ZA1 pH~7.4
                    if (size(handles.p.spec_peak_pos,2) > 9 && handles.p.spec_peak_pos(10) > 0), plot(freq_axis(handles.p.spec_peak_pos(10)), 1.25*max(handles.p.spec_peak_val(8),handles.p.spec_peak_val(10)),'*m','Markersize',12,'MarkerFaceColor','m'); end % PPH5
                else
                    if (size(handles.p.peak_pos,3) > 3 && handles.p.peak_pos(idx1,idx2, 4) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 4)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 4)),'vb','Markersize',8); end % ZA5 pH~6.5
                    if (size(handles.p.peak_pos,3) > 4 && handles.p.peak_pos(idx1,idx2, 5) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 5)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 5)),'vb','Markersize',8); end % ZA1 pH~6.5
                    if (size(handles.p.peak_pos,3) > 5 && handles.p.peak_pos(idx1,idx2, 6) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 6)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 6)),'dg','Markersize',8); end % ZA5 pH~7.0
                    if (size(handles.p.peak_pos,3) > 6 && handles.p.peak_pos(idx1,idx2, 7) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 7)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 7)),'dg','Markersize',8); end % ZA1 pH~7.0
                    if (size(handles.p.peak_pos,3) > 7 && handles.p.peak_pos(idx1,idx2, 8) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 8)), 1.25*handles.p.peak_val(idx1,idx2, 8),'hr','Markersize',8); end % ZA5 pH~7.4
                    if (size(handles.p.peak_pos,3) > 8 && handles.p.peak_pos(idx1,idx2, 9) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2, 9)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 9)),'hr','Markersize',8); end % ZA1 pH~7.4
                    if (size(handles.p.peak_pos,3) > 9 && handles.p.peak_pos(idx1,idx2,10) > 0), plot(freq_axis(handles.p.peak_pos(idx1,idx2,10)), 1.25*max(handles.p.peak_val(idx1,idx2, 8),handles.p.peak_val(idx1,idx2, 10)),'*m','Markersize',8); end % PPH5
                end
            end
        else
            plot(freq_axis, spectrum, '-k');    
        end
    end


    if ~isempty(fit_params) && ~isempty(param_names)
        % display fit results in output text box
        for n = 1:min(length(fit_params), length(param_names))
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                    param_names{n} ': ' num2str(fit_params(n)) ];
        end
        handles.edit_plotted_spectrum_as_text.String = [ ...
            handles.edit_plotted_spectrum_as_text.String; ' ']; % blank line
    end


    if (handles.p.option_freq_as_ppm)
        % flip frequency axis direction
        set(gca, 'xdir', 'reverse')
    end


    % label the axis
    if (handles.p.option_freq_as_ppm)
        xlabel('frequency [ppm]')
    else
        xlabel('frequency [Hz]')
    end

    ylabel('signal [a.u.]')

    % define the limits of the spectrum in vertical / intensity direction
    if (handles.p.option_plot_phase)
        spec_ylims = [-pi*1.1 pi*1.1];
    elseif (handles.p.window_auto)
        plot_auto_axes = axis;
        if (handles.p.option_carbon_rms || handles.p.option_plot_intensity)
            spec_ylims = [handles.p.intensity_offset plot_auto_axes(4)];
        elseif (handles.p.option_plot_complex || handles.p.option_plot_real)
            rng = max(abs(plot_auto_axes(3:4)));
            spec_ylims = [-rng rng];
        else
            spec_ylims = plot_auto_axes(3:4);
        end
    else
        spec_ylims = [handles.p.window_val handles.p.window_val + handles.p.window_length];
    end

    ylim(spec_ylims);


    % define shown limits of spectrum in frequency direction, based on UI
    % settings
    if (handles.p.option_freq_as_ppm)
        low = handles.p.freq_min / handles.p.reference_freq + handles.p.working_freq_ppm;
        high = handles.p.freq_max / handles.p.reference_freq + handles.p.working_freq_ppm;
    else
        low = handles.p.freq_min;
        high = handles.p.freq_max;
    end
    if (low == high)
        low = low - 1;
        high = high + 1;
    end    
    xlim([low high])


    % draw the four vertical metabolite frequency lines + the fifth one from the image
    hold all
        % lower and upper bounds of click freq range
        if (handles.p.option_freq_as_ppm)
            low = handles.p.freq_val / handles.p.reference_freq + handles.p.working_freq_ppm;
            high = (handles.p.freq_val + handles.p.freq_length) / handles.p.reference_freq + handles.p.working_freq_ppm;
        else
            low = handles.p.freq_val;
            high = (handles.p.freq_val + handles.p.freq_length);
        end
        line([low low],     spec_ylims, 'LineStyle', '-', 'Color', 0.5*[1 1 1]);
        line([high high],   spec_ylims, 'LineStyle', '-', 'Color', 0.5*[1 1 1]);

        % metabolite frequency lines
        if (handles.p.option_show_f1)
            if (handles.p.option_freq_as_ppm)
                freq1 = handles.p.f1_val / handles.p.reference_freq + handles.p.working_freq_ppm;
            else
                freq1 = handles.p.f1_val;
            end
            line([freq1 freq1], spec_ylims, 'LineStyle', '--', 'Color', 'r');
        end

        if (handles.p.option_show_f2)
            if (handles.p.option_freq_as_ppm)
                freq2 = handles.p.f2_val / handles.p.reference_freq + handles.p.working_freq_ppm;
            else
                freq2 = handles.p.f2_val;
            end
            line([freq2 freq2], spec_ylims, 'LineStyle', '--', 'Color', 'b');
        end

        if (handles.p.option_show_f3)
            if (handles.p.option_freq_as_ppm)
                freq3 = handles.p.f3_val / handles.p.reference_freq + handles.p.working_freq_ppm;
            else
                freq3 = handles.p.f3_val;
            end
            line([freq3 freq3], spec_ylims, 'LineStyle', '--', 'Color', 'm');
        end

        if (handles.p.option_show_f4)
            if (handles.p.option_freq_as_ppm)
                freq4 = handles.p.f4_val / handles.p.reference_freq + handles.p.working_freq_ppm;
            else
                freq4 = handles.p.f4_val;
            end
            line([freq4 freq4], spec_ylims, 'LineStyle', '--', 'Color', 'k');
        end
    hold off

    % label the four vertical frequency lines    
    %text(handles.p.hz(handles.p.freq_val), spec_ymax,' F','Color',0.5*[1 1 1],'VerticalAlignment','top')
    if (handles.p.option_show_f1)
        text(freq1, spec_ylims(2),' F1','Color','r','VerticalAlignment','top')
    end
    if (handles.p.option_show_f2)
        text(freq2, spec_ylims(2),' F2','Color','b','VerticalAlignment','top')
    end
    if (handles.p.option_show_f3)
        text(freq3, spec_ylims(2),' F3','Color','m','VerticalAlignment','top')
    end
    if (handles.p.option_show_f4)
        text(freq4, spec_ylims(2),' F4','Color','k','VerticalAlignment','top')
    end


    % define which function to call when the carbon image is clicked on

    warning('off','MATLAB:modes:mode:InvalidPropertySet')
        subplot_spectrum_bdf = @(m,n) subplot_spectrum_ButtonDownFcn(m, n, handles);
        set(sp_spec,'ButtonDownFcn',            subplot_spectrum_bdf);  % empty space
        set(allchild(sp_spec), 'ButtonDownFcn', subplot_spectrum_bdf);  % all objects in figure

        figure_buf = @(m,n) figure_ButtonUpFcn(m, n, handles);
        set(gcf, 'WindowButtonUpFcn', figure_buf);

        figure_bmf = @(m,n) handle_phasing_drag(m, n, handles);
        set(gcf, 'WindowButtonMotionFcn', figure_bmf);
    warning('on','MATLAB:modes:mode:InvalidPropertySet')
end

function PlotTime(handles)              %whole function modified by Martin G. on 26.11.2018 @ 17:19
    subplot = @(m,n,p) subtightplot(m, n, p, [0.10 0.08], [0.10 0.03], [0.08 0.05]);
    sp_time = subplot(2,2,4);
    %axes(sp_time);                     %2020.11.06: Martin G.: Commented
    %out for reasons of runtime optimization (not obvious changes)

    if ~isfield(handles,'d') || ~isfield(handles.d,'carbon_recon') || ~isfield(handles.d.carbon_recon,'image')
        return
    end

    legend_entries = cell(0);
    [timeseries, complex_timeseries, title_text] = GetMetabTimeSeries(handles);
    
    [spectrum, complex_spectrum] = GetMetabSpectrum(handles); %Inserted by Martin G. on 26.11.18  @16:18
    freq_ppm = handles.p.ppm.';
    %     disp(['Click Timeseries: ' num2str(timeseries.')])

    plot_symbol = '-';
    plot_line_format = '--';
    if (length(handles.p.timeaxis) == 1)
        plot_symbol = '*';
        plot_line_format = '*';
    end


    % plot the time courses of the desired frequencies
    if (handles.p.option_plot_complex && ~handles.p.option_carbon_rms)
        plot(handles.p.timeaxis, real(complex_timeseries), [plot_symbol 'b'], ...
             handles.p.timeaxis, imag(complex_timeseries), [plot_symbol 'r']);
        legend_entries{end + 1} = ['real ' num2str(round(handles.p.freq_val)) ' to ' ...
                                   num2str(round(handles.p.freq_val + handles.p.freq_length)) ' Hz'];
        legend_entries{end + 1} = ['imag ' num2str(round(handles.p.freq_val)) ' to ' ...
                                   num2str(round(handles.p.freq_val + handles.p.freq_length)) ' Hz'];

        plotted_times = handles.p.timeaxis;

        if (handles.p.t1_fit_desired)
            plotted_vals = real(complex_timeseries);
            T1_real = FitT1(plotted_times, plotted_vals, handles);
            plotted_vals = imag(complex_timeseries);
            T1_imag = FitT1(plotted_times, plotted_vals, handles);
        else
            T1_real = 0;
            T1_imag = 0;
        end
        

        plotted_vals = [real(complex_timeseries) imag(complex_timeseries)];

        if (handles.p.plot_spectral_data)
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ['At ' num2str(handles.p.freq_val) ' to ' num2str(handles.p.freq_val + handles.p.freq_length) ' Hz ']; ...
                ['fit real T1: ' num2str(T1_real) ' s']; ...
                ['fit imag T1: ' num2str(T1_imag) ' s']; ...
                '  '; ...
                ' Spectral data: '; ...
                num2str([freq_ppm complex_spectrum]); ...
            ];
        else
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ['At ' num2str(handles.p.freq_val) ' to ' num2str(handles.p.freq_val + handles.p.freq_length) ' Hz ']; ...
                ['fit real T1: ' num2str(T1_real) ' s']; ...
                ['fit imag T1: ' num2str(T1_imag) ' s']; ...
                '  '; ...
                ' Timeseries: '; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        end
            

    elseif (handles.p.option_plot_real && ~handles.p.option_carbon_rms) && (~handles.p.fit_current_spectrum)
        plot(handles.p.timeaxis, real(complex_timeseries), [plot_symbol 'k']);
        legend_entries{end + 1} = [num2str(round(handles.p.freq_val)) ' to ' ...
                                   num2str(round(handles.p.freq_val + handles.p.freq_length)) ' Hz'];

        plotted_times = handles.p.timeaxis;
        plotted_vals =  real(complex_timeseries);
        if (handles.p.t1_fit_desired)
            T1 = FitT1(plotted_times, plotted_vals, handles);
        else
            T1 = 0;
        end        
        
        if (handles.p.plot_spectral_data)
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ['At ' num2str(handles.p.freq_val) ' to ' num2str(handles.p.freq_val + handles.p.freq_length) ' Hz ']; ...
                ['fit real T1: ' num2str(T1) ' s']; ...
                '  '; ...
                ' Spectral data: '; ...
                num2str([freq_ppm real(complex_spectrum)]); ...
                ' '
            ];
        else    
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ['At ' num2str(handles.p.freq_val) ' to ' num2str(handles.p.freq_val + handles.p.freq_length) ' Hz ']; ...
                ['fit real T1: ' num2str(T1) ' s']; ...
                '  '; ...
                ' Timeseries: '; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        end

    elseif (handles.p.option_plot_intensity)
        plot(handles.p.timeaxis, timeseries, [plot_symbol 'k']);
        legend_entries{end + 1} = [num2str(round(handles.p.freq_val)) ' to ' ...
                                   num2str(round(handles.p.freq_val + handles.p.freq_length)) ' Hz'];

        plotted_times = handles.p.timeaxis;
        plotted_vals =  timeseries;
        if (handles.p.t1_fit_desired)
            T1 = FitT1(plotted_times, plotted_vals, handles);
        else
            T1 = 0;
        end

        if (handles.p.plot_spectral_data)
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ['At ' num2str(handles.p.freq_val) ' to ' num2str(handles.p.freq_val + handles.p.freq_length) ' Hz ']; ...
                ['fit magnitude T1: ' num2str(T1) ' s']; ...
                ['fit magnitude R1: ' num2str(1/T1) ' /s']; ...
                '  '; ...
                ' Spectral data: '; ...
                num2str([freq_ppm spectrum]); ...
                ' '
            ];
        else
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ['At ' num2str(handles.p.freq_val) ' to ' num2str(handles.p.freq_val + handles.p.freq_length) ' Hz ']; ...
                ['fit magnitude T1: ' num2str(T1) ' s']; ...
                ['fit magnitude R1: ' num2str(1/T1) ' /s']; ...
                '  '; ...
                ' Timeseries: '; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        end

    elseif (handles.p.option_plot_lac_pyr)
        plot(handles.p.timeaxis, timeseries, [plot_symbol 'k']);
        legend_entries{end + 1} = 'F4 / F1';
        
        plotted_times = handles.p.timeaxis;
        plotted_vals =  timeseries;
        
        if (handles.p.option_cumsum)
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ' Sum(F4, 0..t) / Sum(F1, 0..t) Timeseries: '; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        else
            handles.edit_plotted_spectrum_as_text.String = [ ...
                handles.edit_plotted_spectrum_as_text.String; ...
                ' F4(t) / F1(t) Timeseries: '; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        end
    elseif (handles.p.option_plot_pH_map)
        plotted_times = handles.p.timeaxis;
        plotted_vals =  timeseries;
%         if max(size(plotted_times)) ~= max(size(plotted_vals)) %If-loop inserted 2020.04.27 - Martin G. - also needs to be worked on in case multi-time-step pH-maps are generated!
%             plotted_times = plotted_times(1:max(size(plotted_vals)));
%         end
        if max(size(handles.p.timeaxis)) > 0
            timeaxis = handles.p.timeaxis(1);
            plot(timeaxis, timeseries, [plot_symbol 'k']);
        else
            plot(handles.p.timeaxis, timeseries, [plot_symbol 'k']);
        end
        legend_entries{end + 1} = [num2str(round(handles.p.freq_val)) ' to ' ...
                                   num2str(round(handles.p.freq_val + handles.p.freq_length)) ' Hz'];
        if (handles.p.option_plot_pH_map_mean) 
            handles.edit_Display_pH_value.String = [ ...
                handles.edit_Display_pH_value.String; ...
                'pH Map mean: '; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        elseif (handles.p.option_plot_pH_map_main) 
            handles.edit_Display_pH_value.String = [ ...
                handles.edit_Display_pH_value.String; ...
                'pH Map main: '; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        elseif (handles.p.option_plot_pH_map_compartment)  
            plotted_times = [1 2 3];
            plotted_vals = round(reshape(plotted_vals,3,2),3);
            handles.edit_Display_pH_value.String = [ ...
                handles.edit_Display_pH_value.String; ...
                'pH Map comp: [#, pH, pH1-5]'; ...
                num2str([plotted_times' plotted_vals]); ...
                ' '
            ];
        end
        
    else
        plot(handles.p.timeaxis, timeseries, [plot_symbol 'k']);
        legend_entries{end + 1} = [num2str(round(handles.p.freq_val)) ' to ' ...
                                   num2str(round(handles.p.freq_val + handles.p.freq_length)) ' Hz'];
    end



    % only show metabolites if plotting values, not for phase or frequency
    % offsets or ratios of values for which single metabolite frequencies don't
    % necessarily make any sense.
    show_metabolite_timeseries = 0;
    if (handles.p.option_plot_intensity || handles.p.option_plot_complex || handles.p.option_plot_real)
        show_metabolite_timeseries = 1;
    end


    hold on
    if (handles.p.option_show_f1 && show_metabolite_timeseries)
        freq1_idx = FreqToSliderIdx(handles.p.f1_val, handles);
        f1_timeseries = squeeze(GetMetabTimeSeriesFreq(freq1_idx, handles)) ./ handles.p.downscale_f1;

%         disp(['F1 Timeseries: ' num2str(f1_timeseries.')])
        
        % plot the time courses of the desired frequency
        if (handles.p.option_plot_complex && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f1_timeseries), ['r' plot_line_format], ...
                 handles.p.timeaxis, imag(f1_timeseries), ['r' plot_line_format]);
            legend_entries{end + 1} = ['F1 real: ' num2str(round(handles.p.f1_val)) ' Hz'];
            legend_entries{end + 1} = ['F1 imag: ' num2str(round(handles.p.f1_val)) ' Hz'];

        elseif (handles.p.option_plot_real && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f1_timeseries), ['r' plot_line_format]);
            legend_entries{end + 1} = ['F1: ' num2str(round(handles.p.f1_val)) ' Hz'];

        else
            plot(handles.p.timeaxis, abs(f1_timeseries), ['r' plot_line_format]);
            legend_entries{end + 1} = ['F1: ' num2str(round(handles.p.f1_val)) ' Hz'];
        end
    end

    if (handles.p.option_show_f2 && show_metabolite_timeseries)
        freq2_idx = FreqToSliderIdx(handles.p.f2_val, handles);
        f2_timeseries = squeeze(GetMetabTimeSeriesFreq(freq2_idx, handles));

        % plot the time courses of the desired frequency
        if (handles.p.option_plot_complex && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f2_timeseries), ['b' plot_line_format], ...
                 handles.p.timeaxis, imag(f2_timeseries), ['b' plot_line_format]);
            legend_entries{end + 1} = ['F2 real: ' num2str(round(handles.p.f2_val)) ' Hz'];
            legend_entries{end + 1} = ['F2 imag: ' num2str(round(handles.p.f2_val)) ' Hz'];

        elseif (handles.p.option_plot_real && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f2_timeseries), ['b' plot_line_format]);
            legend_entries{end + 1} = ['F2: ' num2str(round(handles.p.f2_val)) ' Hz'];
        else
            plot(handles.p.timeaxis, abs(f2_timeseries), ['b' plot_line_format]);
            legend_entries{end + 1} = ['F2: ' num2str(round(handles.p.f2_val)) ' Hz'];
        end
    end

    if (handles.p.option_show_f3 && show_metabolite_timeseries)
        freq3_idx = FreqToSliderIdx(handles.p.f3_val, handles);
        f3_timeseries = squeeze(GetMetabTimeSeriesFreq(freq3_idx, handles));

        % plot the time courses of the desired frequency
        if (handles.p.option_plot_complex && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f3_timeseries), ['m' plot_line_format], ...
                 handles.p.timeaxis, imag(f3_timeseries), ['m' plot_line_format]);
            legend_entries{end + 1} = ['F3 real: ' num2str(round(handles.p.f3_val)) ' Hz'];
            legend_entries{end + 1} = ['F3 imag: ' num2str(round(handles.p.f3_val)) ' Hz'];

        elseif (handles.p.option_plot_real && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f3_timeseries), ['m' plot_line_format]);
            legend_entries{end + 1} = ['F3: ' num2str(round(handles.p.f3_val)) ' Hz'];
        else
            plot(handles.p.timeaxis, abs(f3_timeseries), ['m' plot_line_format]);
            legend_entries{end + 1} = ['F3: ' num2str(round(handles.p.f3_val)) ' Hz'];
        end
    end

    if (handles.p.option_show_f4 && show_metabolite_timeseries)
        freq4_idx = FreqToSliderIdx(handles.p.f4_val, handles);
        f4_timeseries = squeeze(GetMetabTimeSeriesFreq(freq4_idx, handles));

        % plot the time courses of the desired frequency
        if (handles.p.option_plot_complex && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f4_timeseries), ['k' plot_line_format], ...
                 handles.p.timeaxis, imag(f4_timeseries), ['k' plot_line_format]);
            legend_entries{end + 1} = ['F4 real: ' num2str(round(handles.p.f4_val)) ' Hz'];
            legend_entries{end + 1} = ['F4 imag: ' num2str(round(handles.p.f4_val)) ' Hz'];

        elseif (handles.p.option_plot_real && ~handles.p.option_carbon_rms)
            plot(handles.p.timeaxis, real(f4_timeseries), ['k' plot_line_format]);
            legend_entries{end + 1} = ['F4: ' num2str(round(handles.p.f4_val)) ' Hz'];
        else
            plot(handles.p.timeaxis, abs(f4_timeseries), ['k' plot_line_format]);
            legend_entries{end + 1} = ['F4: ' num2str(round(handles.p.f4_val)) ' Hz'];
        end
    end
    hold off


    % title the plot
    title_text = [title_text ' Time Series'];
    title(title_text, 'FontSize', 8)
    xlabel('time [s]')


    % define the time limits
    if length(handles.p.timeaxis) > 1
        time_xlims = [0 handles.p.timeaxis(end)];
    else
        time_xlims = [0 2*handles.p.timeaxis(end)];
    end
    xlim(time_xlims)


    % label metabolites / legend
    % legend(legend_entries);
    % text(time_xlims(2), timeseries(end),' F1','Color','r','VerticalAlignment','top')
    if (handles.p.option_show_f1 && show_metabolite_timeseries)
        text(time_xlims(2), f1_timeseries(end),' F1','Color','r','VerticalAlignment','top')
    end
    if (handles.p.option_show_f2 && show_metabolite_timeseries)
        text(time_xlims(2), f2_timeseries(end),' F2','Color','b','VerticalAlignment','top')
    end
    if (handles.p.option_show_f3 && show_metabolite_timeseries)
        text(time_xlims(2), f3_timeseries(end),' F3','Color','m','VerticalAlignment','top')
    end
    if (handles.p.option_show_f4 && show_metabolite_timeseries)
        text(time_xlims(2), f4_timeseries(end),' F4','Color','k','VerticalAlignment','top')
    end



    % set y-axis limits
    if (handles.p.option_plot_phase)
        time_ylims = [-pi pi];
        ylabel('Phase [rad]')

    elseif (handles.p.window_auto)
        plot_auto_axes = axis;
        time_ylims = [plot_auto_axes(3) plot_auto_axes(4)];
        ylabel('signal [a.u.]')

    else
        time_ylims = [handles.p.window_val handles.p.window_val + handles.p.window_length];
        ylabel('signal [a.u.]')

    end
    if (handles.p.option_plot_pH_map)
        if (handles.p.pH_window_auto)
            plot_auto_axes = axis;
            time_ylims = [plot_auto_axes(3) plot_auto_axes(4)];
            ylabel('pH')
        else
            time_ylims = [handles.p.pH_window_val handles.p.pH_window_val + handles.p.pH_window_length];
            ylabel('pH')
        end
    end
    ylim(time_ylims);



    % draw vertical line about which timestep is shown in the carbon image
    % and for sum min and max

    timestep_start = min(max(1, handles.p.timestep_val), length(handles.p.timeaxis));
    timestep_end = min(timestep_start + handles.p.timestep_length - 1, length(handles.p.timeaxis));
    if timestep_end < timestep_start
        timestep_end = timestep_start;
    end

    line(handles.p.timeaxis(timestep_start)*[1 1],  time_ylims,'LineStyle','--','Color',0.5*[1 1 1]);
    line(handles.p.timeaxis(timestep_end)*[1 1],    time_ylims,'LineStyle','--','Color',0.5*[1 1 1]);

    legend(legend_entries, 'Location', 'northeast')


    % define which function to call when the carbon image is clicked on
    subplot_time_bdf = @(m,n) subplot_time_ButtonDownFcn(m, n, handles);
    set(sp_time,'ButtonDownFcn',            subplot_time_bdf);  % empty space
    set(allchild(sp_time),'ButtonDownFcn',  subplot_time_bdf);  % all objects in figure
end

function T1 = FitT1(times, Y, handles)
    if (max(Y) > 0)
        Y = Y / max(Y);
    end
    
    idx_low = handles.p.timestep_val;
    if (idx_low < 1)
        idx_low = 1;
    elseif (idx_low > length(handles.p.timeaxis))
        idx_low = length(handles.p.timeaxis);
    end
    idx_high = idx_low + handles.p.timestep_length - 1;
    if (idx_high > length(handles.p.timeaxis))
        idx_high = length(handles.p.timeaxis);
    end
    
    times = times(idx_low:idx_high);
    Y = Y(idx_low:idx_high);
    
    best_SS = Inf;
    best_T1 = 0;
    
    warning('off', 'MATLAB:rankDeficientMatrix');
    for T1 = 0.01 : 0.01 : 40              %changed by Martin on 15.10.2018   begin 10 to 1
        X = [ones(size(times)).' exp(-times .' ./ T1)];
        fit_vals = X \ Y;
        fit_Y = X * fit_vals;
        SS = sum((Y - fit_Y).^2);
        
        if (SS < best_SS)
            best_SS = SS;
            best_T1 = T1;
            best_offset = fit_vals(1);
            best_amp = fit_vals(2);
        end
        
%         plot(times, Y, '.', times, fit_Y, '-')
%         title(['SS: ' num2str(SS) '  T1: ' num2str(T1) '  best T1: ' num2str(best_T1)])
%         drawnow
    end
%     pause
    warning('on', 'MATLAB:rankDeficientMatrix');
    
    T1 = best_T1;
    FitOpt = fitoptions('Method','NonlinearLeastSquares','Lower',[T1,0.95*best_amp,best_offset],'Upper',[T1,1.05*best_amp,best_offset],'StartPoint',[T1, best_amp,best_offset]);
    FitFunc = fittype(@(T1,M0,c,t) c + M0*exp(-t/T1),'coefficients',{'T1','M0','c'},'independent','t','options',FitOpt);
    [T2Fit,a,~] = fit(times.',Y,FitFunc);
    display(strcat('R2 (COD) of the displayed fit: ', num2str(a.rsquare)))
end
   
function PlotTimeSpectrumSurface(handles)

if ~handles.p.option_plot_surface
    return
end

figure(82353)
xpos = handles.p.pointer2d(1);
ypos = handles.p.pointer2d(2);
slice = handles.p.slice_carbon_val;
coil = handles.p.coil_carbon_val;

metab_data =  ApplyFlipAngleCorrectionFactors(handles.d.carbon_recon.image, handles);

data = squeeze(abs(metab_data(xpos,ypos,:,slice,coil,:)));
x = linspace(0, handles.p.timeaxis(end), 5);
y = linspace(min(handles.p.hz), max(handles.p.hz), 5);
imagesc(x,y,data);
colorbar
colormap default

title(['spectral-temporal surface at pixel (x=' num2str(xpos) ',y=' num2str(ypos) ')'])
xlabel('time [s]')
ylabel('frequency [Hz]')

end

function DebugOutput(handles)
if ~isfield(handles,'d') || ~isfield(handles.d,'carbon_recon') || ~isfield(handles.d.carbon_recon,'image')
    return
end

num_timesteps = size(handles.d.carbon_recon.image,6);
timestep_start = min(num_timesteps, max(1, handles.p.timestep_val));
time_length = max(1, handles.p.timestep_length);
timestep_end = min(num_timesteps, timestep_start + time_length - 1);

idx1 = min(max(1, handles.p.pointer2d(1)), size(handles.d.carbon_recon.image,1));
idx2 = min(max(1, handles.p.pointer2d(2)), size(handles.d.carbon_recon.image,2));

partly_indexed_data = squeeze(sum(abs(handles.d.carbon_recon.image(idx1, idx2, :, ...
                                                                   handles.p.slice_carbon_val, handles.p.coil_carbon_val, ...
                                                                   timestep_start:timestep_end)),6));
f1 = partly_indexed_data(FreqToSliderIdx(handles.p.f1_val, handles));
f2 = partly_indexed_data(FreqToSliderIdx(handles.p.f2_val, handles));
f3 = partly_indexed_data(FreqToSliderIdx(handles.p.f3_val, handles));
f4 = partly_indexed_data(FreqToSliderIdx(handles.p.f4_val, handles));

% fprintf('(x=%d, y=%d, time=%.0f-%.0fs): ', handles.p.pointer2d(1), handles.p.pointer2d(2), ...
%                                            handles.p.timeaxis(timestep_start), handles.p.timeaxis(timestep_end));
% fprintf('F1=%.2e, ', f1);
% fprintf('F2=%.2e, ', f2);
% fprintf('F3=%.2e, ', f3);
% fprintf('F4=%.2e, ', f4);
% % fprintf('R_eff_met=%.2e',handles.p.R_eff_met);
% disp(' '); % newline
end

function subplot_carbon_image_ButtonDownFcn(src, eventdata, handles)
    if (eventdata.Button == 1)
        % get coordiantes of the mouse pointer
        pointer = get(gca,'currentpoint');
        handles.p.pointer2d = clippointer2d(round(pointer(1,1:2)), handles);
        
    elseif (eventdata.Button == 3)
        start_windowing_drag(src, eventdata, handles);
    end

    % Update handles structure and update display
    guidata(handles.plot4d_control, handles);
    plot4d_plot(handles)
end

function figure_ButtonUpFcn(src, eventdata, handles)
    end_windowing_drag(src, eventdata, handles);
    end_phasing_drag(src, eventdata, handles);
end

function subplot_proton_ButtonDownFcn(src, eventdata, handles)
    if (eventdata.Button == 1)
        % get coordiantes of the mouse pointer
        pointer = get(gca,'currentpoint');

        % compensate for different image resolutions of proton and carbon image
        proton_carbon_scaling_x = size(handles.d.proton_image,1)/size(handles.d.carbon_recon.image,1);
        proton_carbon_scaling_y = size(handles.d.proton_image,2)/size(handles.d.carbon_recon.image,2);
        handles.p.pointer2d = clippointer2d(round([pointer(1,1)/proton_carbon_scaling_x   pointer(1,2)/proton_carbon_scaling_y]), handles);    
    elseif (eventdata.Button == 3)
        start_windowing_drag(src, eventdata, handles);
    end

    % Update handles structure and update display
    guidata(handles.plot4d_control, handles);
    plot4d_plot(handles)
end

function subplot_spectrum_ButtonDownFcn(src, eventdata, handles)
    if (eventdata.Button == 1)
        % get coordiantes of the mouse pointer
        pointer = get(gca,'currentpoint');
        freq_desired = pointer(1,1);
        if (handles.p.option_freq_as_ppm)
            freq_desired = (freq_desired - handles.p.working_freq_ppm) * handles.p.reference_freq;
        end
        % find available frequency closest to the desired one
        [~,freq_index] = min(abs(handles.p.hz - freq_desired));
        handles.p.freq_val = handles.p.hz(freq_index) - handles.p.freq_length / 2;
        
    elseif (eventdata.Button == 3)
        start_phasing_drag(src, eventdata, handles);
    end

    % Update handles structure and update display
    guidata(handles.plot4d_control, handles);
    plot4d_plot(handles)
end

function subplot_time_ButtonDownFcn(src, eventdata, handles)
    if (eventdata.Button == 1)
        % get coordiantes of the mouse pointer
        pointer = get(gca,'currentpoint');
        time_desired = pointer(1,1);

        % find available time closest to the desired one
        [~,time_index] = min(abs(handles.p.timeaxis - time_desired));
        handles.p.timestep_val = time_index;
        
    elseif (eventdata.Button == 3)
        start_windowing_drag(src, eventdata, handles);        
    end

    % Update handles structure and update display
    guidata(handles.plot4d_control, handles);
    plot4d_plot(handles)
end

function pointer2d_out = clippointer2d(pointer2d_in, handles)
    if ~isfield(handles, 'd') || ~isfield(handles.d, 'carbon_recon')
        pointer2d_out = pointer2d_in;
        return
    end
    pointer2d_out = pointer2d_in;
    for p_id=1:2
        if (pointer2d_in(p_id) > size(handles.d.carbon_recon.image,p_id))
            pointer2d_out(p_id) = size(handles.d.carbon_recon.image,p_id);
        end
        if (pointer2d_in(p_id) < 1)
            pointer2d_out(p_id) = 1;
        end
    end
end

function start_windowing_drag(~, ~, handles)
    handles.p.actively_window_level_dragging = 1;
    handles.p.drag_start_pointer_pos2d = get(gcf,'currentpoint');
end

function end_windowing_drag(~, ~, handles)
    handles.p.actively_window_level_dragging = 0;
end

function handle_windowing_drag(~, ~, handles)
    if ~handles.p.actively_window_level_dragging
        return
    end
    if handles.p.window_auto
%         disp('ignoring windowing dragging while in auto window level mode')
        return
    end

    pointer_pos2d = get(gcf,'currentpoint');
    drag_delta = pointer_pos2d - handles.p.drag_start_pointer_pos2d;
    handles.p.drag_start_pointer_pos2d = pointer_pos2d;
    
    abs_level = max(abs(handles.p.window_val), abs(handles.p.window_length));
    abs_width = abs(handles.p.window_length);
    
    handles.p.window_val = handles.p.window_val - (abs_level * 0.002 * drag_delta(2));
    handles.p.window_length = handles.p.window_length - (abs_width * 0.002 * drag_delta(1));
    
    % Update handles structure and update display
    guidata(handles.plot4d_control, handles);
    plot4d_plot(handles)
end

function start_phasing_drag(~, ~, handles)
    handles.p.actively_phasing_dragging = 1;
    handles.p.drag_start_pointer_pos2d = get(gcf,'currentpoint');
end

function end_phasing_drag(~, ~, handles)
    handles.p.actively_phasing_dragging = 0;
end

function handle_phasing_drag(~, ~, handles)
    if ~handles.p.actively_phasing_dragging
        return
    end
    if ~handles.p.option_plot_real && ~handles.p.option_plot_complex
%         disp('ignoring phasing dragging while not in real or complex plot mode')
        return
    end

    pointer_pos2d = get(gcf, 'currentpoint');
    drag_delta = pointer_pos2d - handles.p.drag_start_pointer_pos2d;
    handles.p.drag_start_pointer_pos2d = pointer_pos2d;
    
    handles.p.spectrum_phase0 = handles.p.spectrum_phase0 - drag_delta(1);
    handles.p.spectrum_phase1 = handles.p.spectrum_phase1 - drag_delta(2);
    
    % Update handles structure and update display
    guidata(handles.plot4d_control, handles);
    plot4d_plot(handles)
end

function have_siemens = HaveSiemensData(handles)
    have_siemens = isfield(handles.p.carbon_header, 'Config');
end
    
function have_ge = HaveGEData(handles)
    have_ge = isfield(handles.d, 'carbon_recon') && isfield(handles.d.carbon_recon, 'fid');
end 
    
function have_bruker = HaveBrukerData(handles)
    have_bruker = isfield(handles.p.carbon_header, 'ACQ_method');
end

function FigureReadyforPPT
    set(gcf,'color','w');
    set(findall(gcf, 'Type', 'Line'),'LineWidth',1.5);
    set(findall(gcf,'-property','FontSize'),'FontSize',12)
    set(findobj(gcf,'type','axes'),'FontName','Arial','FontSize',12,'FontWeight','Bold', 'LineWidth', 1.5);
    set(gcf,'Position',[962 42 958 954]);
end

function Update_Area(handles)    
    handles.edit_Area.Value = handles.edit_ROI_Px_1H.Value * handles.p.Vox_Sz * handles.p.Vox_Sz;
    handles.edit_Area.String = num2str(round(handles.edit_Area.Value,2));
end